# Aletvia Impact — Next Development Sequence

## Gate 1 — Canonicalize and deploy the existing product
1. Keep this package as the canonical engineering baseline.
2. Create a hosted staging environment.
3. Apply the existing Supabase/PostgreSQL migrations in order.
4. Configure server-side AI credentials and run the exact production-provider smoke test.
5. Run the full 53-test suite and Step-6 E2E against staging-compatible configuration.

## Gate 2 — Production data handling
1. Store original PDFs in a private object-storage bucket.
2. Persist storage path, source hash, extraction status and provenance.
3. Add malware/file-type/size controls appropriate to institutional uploads.
4. Add section-aware long-document chunking; do not silently truncate research evidence.

## Gate 3 — Pilot-operational hardening
1. Add environment/health diagnostics.
2. Add structured application logs and request correlation IDs.
3. Add rate limiting and abuse controls.
4. Add database backup/restore procedure.
5. Add tenant export/deletion and pilot-data retention procedures.
6. Add reviewer/admin onboarding controls.

## Gate 4 — Rendering connectors
Preserve the frozen scientific schemas. Add renderers downstream:
- visual specification → production graphical asset
- video storyboard → rendered MP4

Rendered media should receive a post-render verification pass before activation.

## Gate 5 — Founding design-partner pilot
Use the existing Step-8 package. The first pilot should validate:
- researcher trust and correction rate
- researcher review burden
- communications/research-office preparation-time reduction
- governance fit
- artifact usefulness
- institutional ownership and procurement path
- willingness to convert to annual subscription

The product should not broaden into automatic external publishing or deep integrations before pilot evidence shows those are the binding constraints.
