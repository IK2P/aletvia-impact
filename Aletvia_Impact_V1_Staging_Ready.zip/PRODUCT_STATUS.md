# Aletvia Impact — Canonical Product Status

## Current maturity
Aletvia Impact is a **working institutional MVP / controlled-pilot candidate**, not a production-complete SaaS.

## Executable product — implemented
1. Research Intelligence Engine.
2. Server-side authentication and sessions.
3. Institutional multi-tenancy and role-based authorization.
4. Persistent SQLite-backed local runtime.
5. DOI ingestion with Crossref adapter architecture.
6. PDF full-text extraction and provenance hashing.
7. ORCID works ingestion/fallback architecture.
8. Canonical Research Object and DOI-first deduplication.
9. Research, Communication & Content Studio.
10. Text, visual-specification, motion-production and learning artifact families.
11. Research Content Packs.
12. Immutable content-asset version history.
13. Independent multimodal Scientific Fidelity Engine.
14. Version-bound researcher and institutional governance.
15. Standard and Enhanced review modes.
16. IP/disclosure and embargo hard gates.
17. Participant-visible and institution-internal comments.
18. Audit history.
19. Ready-for-Activation state.
20. Live tenant dashboard and polished 10-route demo shell.
21. Production-target Supabase/PostgreSQL migrations through Step 6.

## Verified engineering evidence
- 53/53 frozen automated regression tests pass on Node 22.
- Step-6 end-to-end flow reaches Ready for Activation with zero final blockers.
- Prior integrated UI QA covered all ten routes and 390px mobile behavior.

## Scientific validation evidence
Step 7 contains 30 real published papers:
- 20-paper architecture/safety corpus.
- 10-paper fresh holdout.

The frozen holdout report records:
- field/domain classification: 100%
- evidence-maturity classification: 100%
- sensitive-routing accuracy: 100%
- primary-opportunity accuracy: 90%
- mean paper-specific term coverage: 93.4%
- baseline zero-unsupported rate: 100%
- injected-overclaim detection: 100%
- mean review flags/paper: 0.2

This is internal qualification, not an independent blinded third-party benchmark.

## Design-partner validation package
Step 8 is prepared for a controlled 90-day founding university design-partner program. The archived package includes target accounts, pilot scope, outreach drafts, onboarding runbook, scorecard and commercial-validation criteria.

## Deliberately not claimed as production-complete
- Live production Responses-API smoke test with a deployment API key.
- Hosted PostgreSQL/Supabase deployment and production RLS verification.
- Private production object storage for original PDFs.
- Section-aware chunking/retrieval for very long papers.
- Enterprise SSO/SAML.
- Production-grade observability, backups, rate limiting and incident operations.
- Final pixel-level generative image rendering.
- Final MP4 rendering.
- Automatic external social publishing or stakeholder outreach.
- Production CRIS/PURE/Scopus/Web of Science integrations.
- Independent external scientific validation.
- Real university willingness-to-pay validation.

## Canonical engineering rule
Do not rebuild frozen Steps 1–6 from scratch. Extend this integrated codebase and preserve its contracts unless a measured pilot finding justifies a versioned change.
