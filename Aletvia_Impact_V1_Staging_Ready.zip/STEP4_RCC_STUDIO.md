# Step 4 — Research, Communication & Content Studio

## Status

**Implemented and validated; ready for user freeze.**

Steps 1, 2 and 3 remain frozen and pass unchanged regression tests.

## 1. Why the name changed

“Communication Studio” was too narrow because Aletvia now does three distinct jobs:

1. **Research** — inherit the scientific meaning, evidence maturity, findings, limitations and uncertainty from Step 1.
2. **Communication** — select audience, framing, pathway and appropriate format.
3. **Content** — generate the usable artifact: summary, brief, poster, WhatsApp card, diagram, slide, learning set or video package.

Hence the product surface is frozen conceptually as **Research, Communication & Content Studio (RCC Studio)**.

## 2. Artifact families

### Text
Research summary; Plain-language summary; Executive summary; Institutional research story; LinkedIn post; Media pitch; Industry brief; Policy brief; Clinical evidence summary; Collaboration summary; Researcher Q&A.

### Visual
Graphical abstract; Scientific diagram; Research poster; Public research poster; WhatsApp share card; WhatsApp status / wallpaper; Social media card; Carousel; Presentation slide.

Visual artifacts include structured layout blocks, aspect ratio, recommended dimensions, alt text and diagram semantics. If source data do not support a numeric chart, RCC Studio is instructed to create conceptual/process visuals rather than fabricate data.

### Motion
Research Flash (20–30 s); Video Abstract (60–90 s); Research Explainer (120–180 s).

Motion outputs are production packages containing storyboard scenes, scene timing, visual direction, narration, captions and evidence-role metadata. Final video rendering is intentionally deferred.

### Learning
Flashcards; Key takeaways; FAQ; Glossary; Myth vs Evidence; Journal club questions.

## 3. One-click Research Content Packs

### Quick Share Pack
Research summary + WhatsApp share card + LinkedIn post + presentation slide.

### Public Impact Pack
Plain-language summary + graphical abstract + WhatsApp status/wallpaper + carousel + Video Abstract.

### Industry Pack
Executive summary + industry brief + scientific diagram + presentation slide + LinkedIn post.

### Policy Pack
Research summary + policy brief + graphical abstract + presentation slide.

### Academic Pack
Research summary + graphical abstract + presentation slide + flashcards + collaboration summary.

### Media Pack
Institutional research story + media pitch + researcher Q&A + social media card + Video Abstract.

## 4. Branding and organic Aletvia distribution

Every asset carries a `branding_spec`:

- primary institution brand
- department line
- Aletvia attribution
- logo placement guidance
- QR target
- watermark mode: `visible`, `subtle` or `white_label`
- asset identity label

Default enterprise behavior is **institution-first branding** with subtle `Powered by Aletvia` attribution. White-label mode is structurally supported for future plan differentiation.

## 5. QR/DOI linking

Where a DOI exists, shareable assets point to the normalized `https://doi.org/...` target. Otherwise, the schema instructs the renderer to use an institutional research page. Final QR pixel generation can be handled by the future rendering connector.

## 6. Multimodal scientific governance

Scientific integrity applies to more than prose. Step 4 treats these as potential claims:

- poster headlines
- visual labels
- diagram arrows
- chart values
- carousel text
- slide claims
- video narration
- on-screen captions
- flashcard answers

The claim ledger therefore survives across all artifact families. Step 5 will independently verify them rather than trusting Step-4 provenance labels.

## 7. Visual semantics rule

RCC Studio instructs generation to:

- use solid arrows only for directly supported relationships;
- use dashed/inferred semantics for hypotheses or possible relevance;
- avoid fabricated quantitative charts;
- preserve evidence maturity and uncertainty inside the visual itself.

## 8. Video boundary

Step 4 does **not** claim to render completed video. It creates a scientifically governed production package. This keeps the architecture modular and prevents expensive rendering infrastructure from blocking SaaS validation.

## 9. Versioning

Every artifact still supports:

- AI-generated V1
- human-edited V2
- AI-revised V3+
- provider/model metadata
- prompt version
- source fingerprint
- context fingerprint
- revision instruction
- audit trail

Editing an approved artifact returns it to Draft so Step 5 and approvals can run again.

## 10. Content packs in the database

A `content_packs` entity now groups multiple artifacts belonging to one research output. Individual assets retain independent version history and approval state.

## 11. API additions

- `GET /api/communication/capabilities` — now returns RCC name, artifact families and pack catalog.
- `POST /api/communication/generate` — accepts audience, artifact family, artifact type and branding.
- `GET /api/content-packs`
- `GET /api/content-packs/:id`
- `POST /api/content-packs/generate`

Existing versioning/revision/approval endpoints remain compatible.

## 12. Validation

Automated suite: **37 / 37 passing**.

New validations include:

- WhatsApp share card structured visual specification
- institution-first branding
- `Powered by Aletvia` attribution
- DOI QR target
- 1:1 WhatsApp aspect ratio
- Video Abstract duration/storyboard
- explicit non-rendering boundary
- evidence-grounded flashcards
- coordinated multi-family Public Impact Pack
- persisted HTTP-generated Content Pack
- Steps 1–3 regression suite unchanged

An end-to-end HTTP run also verified:

`login → real PDF ingestion → frozen Step 1 analysis → Public Impact Pack → 5 assets → graphical abstract + Video Abstract`.

## 13. Acceptance criteria

Step 4 revised can be frozen when the product owner accepts that:

- the permanent name is **Research, Communication & Content Studio**;
- the four artifact families are Text, Visual, Motion and Learning;
- WhatsApp card/status, poster, graphical abstract, scientific diagram, slide, flashcards and video packages are first-class artifacts;
- Research Content Packs are first-class product objects;
- institution branding remains primary and Aletvia attribution is configurable;
- final image/video rendering may be attached later without redesigning the scientific data model;
- Step 5 becomes a multimodal Scientific Fidelity Engine.
