import { readFile } from 'node:fs/promises';
import { analyzeResearch } from './engine/research-intelligence-engine.js';
const file=process.argv[2] || './fixtures/sample-input.json';
const input=JSON.parse(await readFile(file,'utf8'));
const out=await analyzeResearch(input);
console.log(JSON.stringify(out,null,2));
