import http from 'node:http';
import fs from 'node:fs';
import {createAppServer} from './server.js';
function req(port,method,url,body,cookie){return new Promise((resolve,reject)=>{const data=body?JSON.stringify(body):null;const r=http.request({hostname:'127.0.0.1',port,path:url,method,headers:{...(data?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}:{}),...(cookie?{Cookie:cookie}:{})}},res=>{let raw='';res.setEncoding('utf8');res.on('data',d=>raw+=d);res.on('end',()=>{let json={};try{json=JSON.parse(raw)}catch{}resolve({status:res.statusCode,headers:res.headers,json})})});r.on('error',reject);if(data)r.write(data);r.end()})}
async function login(port,email){const r=await req(port,'POST','/api/auth/login',{email,password:'DemoPass!2026'});return String(r.headers['set-cookie'][0]).split(';')[0]}
const server=createAppServer(':memory:');await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
try{
 const researcher=await login(port,'researcher@northstar.edu');
 const admin=await login(port,'admin@northstar.edu');
 const comm=await login(port,'communications@northstar.edu');
 const pdf=fs.readFileSync('./fixtures/step3/sample-paper.pdf');
 const ing=await req(port,'POST','/api/ingest/pdf',{filename:'sample-paper.pdf',content_base64:pdf.toString('base64'),analyze:true},researcher);
 const gen=await req(port,'POST','/api/communication/generate',{research_output_id:ing.json.research_output_id,audience:'Industry',asset_type:'Industry brief'},researcher);
 await req(port,'POST',`/api/communication-assets/${gen.json.id}/submit`,{},researcher);
 let cases=await req(port,'GET','/api/approval-cases',null,admin);let c=cases.json.cases.find(x=>x.asset_id===gen.json.id);
 const afterSubmit=c.status;
 const future=new Date(Date.now()+5*86400000).toISOString();
 await req(port,'PATCH',`/api/approval-cases/${c.id}/governance`,{ip_review_required:true,embargo_until:future},admin);
 const fidelity=await req(port,'POST','/api/fidelity/verify',{asset_id:gen.json.id},admin);
 await req(port,'POST',`/api/approval-cases/${c.id}/decisions`,{review_type:'communications',decision:'approve',comment:'Communications review complete.'},comm);
 c=(await req(port,'GET',`/api/approval-cases/${c.id}`,null,admin)).json;const afterComm=c.status;
 await req(port,'POST',`/api/approval-cases/${c.id}/decisions`,{review_type:'ip',decision:'clear',comment:'IP clearance complete.'},admin);
 c=(await req(port,'GET',`/api/approval-cases/${c.id}`,null,admin)).json;const afterIp=c.status;
 const released=await req(port,'PATCH',`/api/approval-cases/${c.id}/governance`,{release_embargo:true},admin);
 const research=await req(port,'GET',`/api/research/${ing.json.research_output_id}`,null,admin);
 console.log(JSON.stringify({research_output_id:ing.json.research_output_id,asset_id:gen.json.id,approval_case_id:c.id,after_researcher_submit:afterSubmit,fidelity_status:fidelity.json.overall_status,fidelity_eligible:fidelity.json.approval_eligible,after_communications_review:afterComm,after_ip_clearance:afterIp,after_embargo_release:released.json.status,ready:released.json.ready,research_workflow:research.json.workflow,blockers:released.json.blockers},null,2));
}finally{server.close()}
