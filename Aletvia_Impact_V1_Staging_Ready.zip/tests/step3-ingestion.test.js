import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, createSession, sessionFromToken } from '../backend-db.js';
import { ensureStep3Schema, normalizeDoi, normalizeOrcid, isValidOrcid, crossrefToCanonical, fetchCrossrefWork, fetchCrossrefWorksByOrcid, extractPdfText, pdfToCanonical, ingestCanonical, ingestPdf } from '../ingestion/research-ingestion.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
function northstarSession(db,user='u_n_research'){const token=createSession(db,user,'inst_northstar');return sessionFromToken(db,token)}
const mockWork={
  DOI:'10.5555/ALETVIA.STEP3.001',title:['A Real DOI-Ingested Environmental Research Paper'],
  author:[{given:'Anika',family:'Rao'},{given:'Mina',family:'Patel'}],
  'container-title':['Journal of Demonstration Research'],type:'journal-article',
  'published-online':{'date-parts':[[2026,9,20]]},
  abstract:'<jats:p>This experimental laboratory study evaluated a modified material for water treatment. The modified material showed higher adsorption under tested laboratory conditions. Field effectiveness, long-term performance and commercial economics were not established.</jats:p>'
};
function mockFetchForCrossref(payload=mockWork){return async url=>({ok:true,status:200,json:async()=>String(url).includes('/works?')?{message:{items:[payload]}}:{message:payload}})}

test('DOI normalization accepts URL and prefix forms',()=>{
  assert.equal(normalizeDoi('https://doi.org/10.5555/ABC.123'),'10.5555/abc.123');
  assert.equal(normalizeDoi('doi: 10.5555/ABC.123'),'10.5555/abc.123');
});
test('ORCID normalization and checksum validation',()=>{
  assert.equal(normalizeOrcid('https://orcid.org/0000-0002-1825-0097'),'0000-0002-1825-0097');
  assert.equal(isValidOrcid('0000-0002-1825-0097'),true);
  assert.equal(isValidOrcid('0000-0002-1825-0098'),false);
});
test('Crossref adapter creates canonical research object',async()=>{
  const m=await fetchCrossrefWork('10.5555/ALETVIA.STEP3.001',{fetchFn:mockFetchForCrossref()});
  const c=crossrefToCanonical(m);
  assert.equal(c.doi,'10.5555/aletvia.step3.001');assert.equal(c.evidence_depth,'abstract');assert.match(c.authors,/Anika Rao/);assert.match(c.source_text,/laboratory study/);
});
test('ORCID Crossref fallback fetches ORCID-indexed works',async()=>{
  const items=await fetchCrossrefWorksByOrcid('0000-0002-1825-0097',{fetchFn:mockFetchForCrossref(),limit:10});assert.equal(items.length,1);assert.equal(items[0].DOI,mockWork.DOI);
});
test('real PDF extraction returns full research text and detects DOI',async()=>{
  const b=fs.readFileSync(path.join(__dirname,'../fixtures/step3/sample-paper.pdf'));const text=await extractPdfText(b);assert.match(text,/pharmaceutical\s+micropollutants/i);const c=pdfToCanonical(text,'sample-paper.pdf');assert.equal(c.evidence_depth,'full_text');assert.equal(c.doi,'10.5555/aletvia.step3.001');assert.match(c.title,/Aletvia Demonstration Paper/);
});
test('PDF extractor rejects non-PDF payload',async()=>{await assert.rejects(()=>extractPdfText(Buffer.from('not a pdf')),/not a valid PDF/i)});
test('canonical ingestion persists analysis and deduplicates DOI within tenant',async()=>{
  const db=openDb(':memory:');ensureStep3Schema(db);const s=northstarSession(db);const c=crossrefToCanonical(mockWork);
  const first=await ingestCanonical(db,s,c,{analyze:true});assert.equal(first.created,true);assert.equal(first.analyzed,true);
  const second=await ingestCanonical(db,s,{...c,source_type:'orcid',source_identifier:'0000-0002-1825-0097:'+c.doi},{analyze:false,source_type_override:'orcid'});
  assert.equal(second.created,false);assert.equal(second.deduplicated,true);assert.equal(second.research_output_id,first.research_output_id);
  assert.equal(db.prepare('SELECT count(*) c FROM research_outputs WHERE institution_id=? AND lower(doi)=?').get('inst_northstar',c.doi).c,1);
  assert.equal(db.prepare('SELECT count(*) c FROM ingestion_sources WHERE research_output_id=?').get(first.research_output_id).c,2);
  assert.equal(db.prepare('SELECT count(*) c FROM research_intelligence_records WHERE research_output_id=?').get(first.research_output_id).c,1);
});
test('researcher cannot assign imported research to another tenant user',async()=>{
  const db=openDb(':memory:');ensureStep3Schema(db);const s=northstarSession(db);const c=crossrefToCanonical(mockWork);
  await assert.rejects(()=>ingestCanonical(db,s,c,{owner_user_id:'u_m_research'}),/selected research owner|cannot import|member|own profile/i);
});
test('PDF ingestion automatically hands extracted full text to frozen Step 1',async()=>{
  const db=openDb(':memory:');ensureStep3Schema(db);const s=northstarSession(db);const b=fs.readFileSync(path.join(__dirname,'../fixtures/step3/sample-paper.pdf'));
  const r=await ingestPdf(db,s,{filename:'sample-paper.pdf',content_base64:b.toString('base64'),analyze:true});assert.equal(r.analyzed,true);assert.equal(r.canonical.evidence_depth,'full_text');assert.ok(r.canonical.extracted_characters>200);const row=db.prepare('SELECT ingestion_status,evidence_maturity FROM research_outputs WHERE id=?').get(r.research_output_id);assert.equal(row.ingestion_status,'analyzed');assert.notEqual(row.evidence_maturity,'Not yet analyzed');
});
