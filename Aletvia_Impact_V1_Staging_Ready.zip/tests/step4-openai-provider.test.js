import test from 'node:test';
import assert from 'node:assert/strict';
import { generateWithOpenAI } from '../communication/openai-provider.js';

const asset={audience:'Industry',asset_type:'Industry brief',headline:'Test',dek:'Dek',body_markdown:'This is a sufficiently long evidence-grounded draft body for a technical industry audience, preserving limitations and avoiding unsupported claims.',key_messages:['One'],evidence_boundary:'Laboratory evidence only.',suggested_call_to_action:'Technical review.',claim_ledger:[{claim:'A result was observed.',basis_type:'paper_supported',basis_reference:'extraction.findings[0]',risk_note:'Keep context.'}],generation_notes:[]};
const ctx={research:{id:'r',title:'T'},intelligence:{schema_version:'1',provenance:{}},audience:'Industry',asset_type:'Industry brief'};

test('OpenAI communication provider uses Responses API, store:false and strict JSON schema',async()=>{const old=globalThis.fetch;let captured;globalThis.fetch=async(url,opts)=>{captured={url,body:JSON.parse(opts.body)};return {ok:true,status:200,json:async()=>({status:'completed',output_text:JSON.stringify(asset)})}};try{const r=await generateWithOpenAI(ctx,{apiKey:'test',model:'gpt-test'});assert.equal(r.provider,'openai');assert.equal(captured.url,'https://api.openai.com/v1/responses');assert.equal(captured.body.store,false);assert.equal(captured.body.text.format.type,'json_schema');assert.equal(captured.body.text.format.strict,true);assert.equal(captured.body.model,'gpt-test')}finally{globalThis.fetch=old}});
