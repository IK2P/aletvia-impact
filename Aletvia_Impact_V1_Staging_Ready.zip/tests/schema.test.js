import test from 'node:test';
import assert from 'node:assert/strict';
import { scientificExtractionSchema, opportunityAssessmentSchema } from '../engine/schemas.js';

function lintObjectSchema(schema,path='root'){
  if(schema.type==='object'){
    assert.equal(schema.additionalProperties,false,`${path} must disable additionalProperties`);
    const props=Object.keys(schema.properties||{});
    const req=schema.required||[];
    assert.deepEqual([...req].sort(),[...props].sort(),`${path} must require every declared property for strict Structured Outputs`);
    for(const [k,v] of Object.entries(schema.properties||{})) lintObjectSchema(v,`${path}.${k}`);
  }
  if(schema.type==='array' && schema.items) lintObjectSchema(schema.items,`${path}[]`);
}

test('scientific extraction schema is strict-object safe',()=>lintObjectSchema(scientificExtractionSchema));
test('opportunity schema is strict-object safe',()=>lintObjectSchema(opportunityAssessmentSchema));
