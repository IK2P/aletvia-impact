import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeWithLocalDemo } from '../engine/local-demo-provider.js';
import { analyzeWithOpenAI } from '../engine/openai-provider.js';

const sample=JSON.parse(await readFile(new URL('../fixtures/sample-input.json',import.meta.url),'utf8'));

test('OpenAI provider performs two strict Structured Outputs calls', async()=>{
  const demo=await analyzeWithLocalDemo(sample);
  const originalFetch=globalThis.fetch;
  const calls=[];
  globalThis.fetch=async(url,options)=>{
    calls.push({url,body:JSON.parse(options.body)});
    const payload=calls.length===1?demo.extraction:demo.opportunity;
    return {
      ok:true,
      status:200,
      async json(){ return {status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(payload)}]}]}; }
    };
  };
  try{
    const result=await analyzeWithOpenAI(sample,{apiKey:'test-key',model:'test-model'});
    assert.equal(calls.length,2);
    assert.equal(calls[0].url,'https://api.openai.com/v1/responses');
    assert.equal(calls[0].body.text.format.type,'json_schema');
    assert.equal(calls[0].body.text.format.strict,true);
    assert.equal(calls[0].body.text.format.name,'aletvia_scientific_extraction');
    assert.equal(calls[1].body.text.format.name,'aletvia_opportunity_assessment');
    assert.equal(result.provider,'openai');
    assert.equal(result.model,'test-model');
    const secondPrompt=calls[1].body.input[1].content[0].text;
    assert.match(secondPrompt,/Scientific Extraction Record/);
    assert.match(secondPrompt,/Laboratory/);
  }finally{ globalThis.fetch=originalFetch; }
});
