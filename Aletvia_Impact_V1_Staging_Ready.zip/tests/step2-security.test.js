import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createAppServer } from '../server.js';

const tmp=path.join(os.tmpdir(),`aletvia-step2-${process.pid}.sqlite`); try{fs.unlinkSync(tmp)}catch{}
const server=createAppServer(tmp); await new Promise(r=>server.listen(0,'127.0.0.1',r)); const base=`http://127.0.0.1:${server.address().port}`;
async function login(email){const r=await fetch(base+'/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,password:'DemoPass!2026'})}); assert.equal(r.status,200);return {cookie:r.headers.get('set-cookie').split(';')[0],data:await r.json()}}
async function api(pathname,{cookie,method='GET',body}={}){return fetch(base+pathname,{method,headers:{...(cookie?{cookie}:{}),...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined})}

test('Northstar admin sees only Northstar research',async()=>{const {cookie}=await login('admin@northstar.edu');const r=await api('/api/research',{cookie});const d=await r.json();assert.equal(r.status,200);assert.ok(d.research.length>=3);assert.ok(d.research.every(x=>x.doi.includes('/nu.')));});
test('Meridian admin cannot fetch Northstar record',async()=>{const {cookie}=await login('admin@meridian.edu');const r=await api('/api/research/n1',{cookie});assert.equal(r.status,404);});
test('researcher is restricted to authored research',async()=>{const {cookie}=await login('researcher@northstar.edu');const r=await api('/api/research',{cookie});const d=await r.json();assert.ok(d.research.length>=1);assert.ok(d.research.every(x=>x.owner==='u_n_research'));const forbidden=await api('/api/research/n3',{cookie});assert.equal(forbidden.status,404);});
test('researcher can submit own research but cannot institutionally approve it',async()=>{const {cookie}=await login('researcher@northstar.edu');let r=await api('/api/research/n1/workflow',{cookie,method:'PATCH',body:{state:'Researcher Approved'}});assert.equal(r.status,200);r=await api('/api/research/n1/workflow',{cookie,method:'PATCH',body:{state:'Approved'}});assert.equal(r.status,403);});
test('admin can change workflow and change persists',async()=>{const {cookie}=await login('admin@northstar.edu');let r=await api('/api/research/n1/workflow',{cookie,method:'PATCH',body:{state:'Approved'}});assert.equal(r.status,200);r=await api('/api/research/n1',{cookie});const d=await r.json();assert.equal(d.workflow,'Approved');});
test('multi-institution user can switch only to assigned tenant',async()=>{const {cookie,data}=await login('multi@aletvia.demo');assert.equal(data.institutions.length,2);let r=await api('/api/session/institution',{cookie,method:'POST',body:{institution_id:'inst_meridian'}});assert.equal(r.status,200);const d=await r.json();assert.equal(d.active_institution.id,'inst_meridian');r=await api('/api/session/institution',{cookie,method:'POST',body:{institution_id:'inst_fake'}});assert.equal(r.status,403);});
test('unauthenticated research API is blocked',async()=>{const r=await api('/api/research');assert.equal(r.status,401);});

test.after(()=>new Promise(r=>server.close(r)));
