import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeResearch } from '../engine/research-intelligence-engine.js';
import { validateExtraction, validateOpportunity } from '../engine/validate.js';

const sample=JSON.parse(await readFile(new URL('../fixtures/sample-input.json',import.meta.url),'utf8'));

test('local demo engine produces a complete validated intelligence record', async()=>{
  const out=await analyzeResearch(sample,{mode:'local-demo'});
  assert.equal(out.schema_version,'1.0');
  assert.equal(out.engine.provider,'local-demo');
  validateExtraction(out.extraction);
  validateOpportunity(out.opportunity);
  assert.ok(out.extraction.claims_to_avoid.length >= 1);
  assert.ok(out.opportunity.recommended_actions.length >= 1);
});

test('engine rejects insufficient source text', async()=>{
  await assert.rejects(()=>analyzeResearch({source_text:'too short'},{mode:'local-demo'}),/at least 80 characters/i);
});

test('sensitive topic triggers enhanced review in local demo provider', async()=>{
  const out=await analyzeResearch({title:'Dementia caregiver abuse study', evidence_depth:'abstract', source_text:'A cross-sectional observational study examined dementia caregiver burden and bidirectional abuse in vulnerable older adults. Associations were reported between behavioral symptoms, caregiver burden, and potentially abusive behaviors. The study does not establish causal effects or general population prevalence.'},{mode:'local-demo'});
  assert.equal(out.extraction.sensitive_research.is_sensitive,true);
  assert.equal(out.extraction.sensitive_research.review_mode,'enhanced');
});
