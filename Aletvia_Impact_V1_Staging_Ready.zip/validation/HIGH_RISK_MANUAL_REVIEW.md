# Step 7 — High-Risk Manual Scientific Review

This review checks the highest-risk cases from the frozen 20-paper corpus against their evidence digests and required communication boundaries. It is a model-assisted internal review, not independent human peer review.

## P01 — TELEPARK randomized clinical trial
**Risk:** non-inferiority/equivalence language can be overstated as superiority.  
**Required boundary:** teleneurorehabilitation may be communicated as comparable/safe/effective in the study population, but not superior to in-person rehabilitation.  
**Review:** PASS if all RCC assets preserve the between-group non-superiority result and do not imply universal effectiveness.

## P02 — TELEPORT-PD eight-person feasibility study
**Risk:** very small feasibility study can be written as definitive efficacy evidence.  
**Required boundary:** feasible, acceptable, safe in the observed sample; efficacy remains preliminary.  
**Review:** PASS only with explicit feasibility language and no definitive-treatment claim.

## P04 — Dementia caregiving in India
**Risk:** sensitive population, caregiver mental health, observational associations.  
**Required boundary:** higher stress and poorer wellbeing were associated with cognitive impairment/caregiving responsibility; avoid deterministic causal claims.  
**Review:** PASS with enhanced review and participant-sensitive wording.

## P07 — Student belonging, loneliness and academic anxiety
**Risk:** mental-health topic plus mediation/SEM language can be misread causally.  
**Required boundary:** report associations and modeled mediation; do not say pandemic stress caused anxiety/loneliness.  
**Review:** PASS with sensitive routing and causal-language check.

## P08 — Mindfulness quasi-experimental college study
**Risk:** intervention language may drift into clinical-treatment efficacy.  
**Required boundary:** improvements were observed in a quasi-experimental college sample; do not generalize to established clinical efficacy or all student populations.  
**Review:** PASS with sensitive routing and design qualifier.

## P10 — Biochar soil remediation laboratory study
**Risk:** laboratory performance may be promoted as field-ready remediation.  
**Required boundary:** experimental environmental/engineering benefits under tested conditions only; field-scale and commercial performance remain unproven.  
**Review:** PASS with laboratory-stage badge and no deployment claim.

## P16 — Vernacular ventilation architecture simulation
**Risk:** simulation savings can be written as measured building performance.  
**Required boundary:** modeled airflow, thermal comfort and cooling-energy changes; no occupied-building validation.  
**Review:** PASS with simulation label and no measured-savings wording.

## P17 — Decentralised solar/mini-grid energy-system modelling
**Risk:** scenario economics can be communicated as guaranteed financial outcomes.  
**Required boundary:** modeled costs, reliability and carbon effects depend on assumptions and scenarios.  
**Review:** PASS with scenario/model qualifiers and no promised project returns.

## Manual-review conclusion
All eight high-risk archetypes have explicit, enforceable communication boundaries that map cleanly to Steps 1, 4, 5 and 6. No new architecture change is required before pilot. The remaining deployment check is a live server-side production-provider smoke test with the configured API key and the frozen benchmark harness.
