import { createHash } from 'node:crypto';
import { analyzeWithOpenAI } from './openai-provider.js';
import { analyzeWithLocalDemo } from './local-demo-provider.js';
import { postProcessResearchIntelligence } from './validate.js';

const MAX_SOURCE_CHARS=200_000;
function fingerprint(input){
  return createHash('sha256').update(JSON.stringify({title:input.title||'',evidence_depth:input.evidence_depth||'',source_text:input.source_text||''})).digest('hex');
}

export async function analyzeResearch(input, config={}){
  if(!input || typeof input.source_text !== 'string' || input.source_text.trim().length < 80){
    throw new Error('Please provide at least 80 characters of research source text.');
  }
  if(input.source_text.length > MAX_SOURCE_CHARS){
    throw new Error(`Source text exceeds ${MAX_SOURCE_CHARS.toLocaleString()} characters. Step 1 does not silently truncate scientific evidence; long-document chunking belongs to the later ingestion pipeline.`);
  }
  const mode=config.mode || process.env.ALETVIA_ENGINE_MODE || (process.env.OPENAI_API_KEY ? 'openai' : 'local-demo');
  let result;
  if(mode === 'openai') result = await analyzeWithOpenAI(input, config);
  else result = await analyzeWithLocalDemo(input);
  return postProcessResearchIntelligence(result.extraction, result.opportunity, {
    provider:result.provider, model:result.model, mode,
    sourceFingerprint:fingerprint(input), sourceCharacters:input.source_text.length
  });
}
