import { scientificExtractionSchema, opportunityAssessmentSchema } from './schemas.js';
import { EXTRACTION_SYSTEM_PROMPT, OPPORTUNITY_SYSTEM_PROMPT, buildExtractionUserPrompt, buildOpportunityUserPrompt } from './prompts.js';

function extractResponseText(json){
  if (typeof json.output_text === 'string' && json.output_text.trim()) return json.output_text;
  for (const item of json.output || []){
    for (const c of item.content || []){
      if (typeof c.text === 'string' && c.text.trim()) return c.text;
    }
  }
  throw new Error('OpenAI response did not contain structured output text.');
}

const sleep = ms => new Promise(r=>setTimeout(r,ms));

async function structuredCall({apiKey, model, system, user, schema, name, timeoutMs=90000, maxAttempts=3}){
  let lastError;
  for(let attempt=1; attempt<=maxAttempts; attempt++){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const response = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          store: false,
          input: [
            { role: 'system', content: [{ type: 'input_text', text: system }] },
            { role: 'user', content: [{ type: 'input_text', text: user }] }
          ],
          text: {
            format: {
              type: 'json_schema',
              name,
              strict: true,
              schema
            }
          }
        })
      });
      const json = await response.json();
      if (!response.ok){
        const msg = json?.error?.message || `OpenAI request failed with ${response.status}`;
        const retryable=response.status===429 || response.status>=500;
        if(retryable && attempt<maxAttempts){ lastError=new Error(msg); await sleep(500*attempt); continue; }
        throw new Error(msg);
      }
      if (json.status === 'incomplete') throw new Error(`OpenAI response incomplete: ${json.incomplete_details?.reason || 'unknown reason'}`);
      const refusal = (json.output || []).flatMap(x=>x.content||[]).find(c=>c.type==='refusal');
      if(refusal) throw new Error(`Model refused analysis: ${refusal.refusal || 'unspecified'}`);
      return JSON.parse(extractResponseText(json));
    }catch(err){
      if(err?.name==='AbortError') lastError=new Error(`OpenAI ${name} request timed out after ${timeoutMs} ms.`);
      else lastError=err;
      if(attempt<maxAttempts && /fetch|network|timed out/i.test(lastError.message)){ await sleep(500*attempt); continue; }
      throw lastError;
    }finally{ clearTimeout(timer); }
  }
  throw lastError || new Error('Structured model call failed.');
}

export async function analyzeWithOpenAI(input, config={}){
  const apiKey = config.apiKey || process.env.OPENAI_API_KEY;
  if(!apiKey) throw new Error('OPENAI_API_KEY is not configured.');
  const model = config.model || process.env.OPENAI_MODEL || 'gpt-6-astra';
  const extraction = await structuredCall({
    apiKey, model,
    system: EXTRACTION_SYSTEM_PROMPT,
    user: buildExtractionUserPrompt(input),
    schema: scientificExtractionSchema,
    name: 'aletvia_scientific_extraction'
  });
  const opportunity = await structuredCall({
    apiKey, model,
    system: OPPORTUNITY_SYSTEM_PROMPT,
    user: buildOpportunityUserPrompt(extraction),
    schema: opportunityAssessmentSchema,
    name: 'aletvia_opportunity_assessment'
  });
  return { extraction, opportunity, provider: 'openai', model };
}
