function includesAny(text, words){ return words.some(w => text.includes(w)); }
const DIMS=['industry','policy','media','public','clinical','academic_collaboration','funding','commercialization'];
function dim(level, confidence, rationale, basis='aletvia_inferred'){ return {level, confidence, rationale, basis}; }

export async function analyzeWithLocalDemo(input){
  const text = `${input.title||''} ${input.source_text||''}`.toLowerCase();
  const isClinical=includesAny(text,['patient','clinical','disease','ulcer','parkinson','cancer','trial','hospital']);
  const isObs=includesAny(text,['observational','cohort','association','cross-sectional','survey']);
  const isLab=includesAny(text,['laboratory','adsorption','biochar','material','in vitro','batch','column']);
  const isAI=includesAny(text,['machine learning','deep learning','artificial intelligence','satellite','change detection','algorithm']);
  const sensitive=includesAny(text,['abuse','suicide','self-harm','child','dementia','genetic','mental health']);
  const evidenceDepth=input.evidence_depth || 'abstract';
  const maturity=isObs?'Observational human study':isClinical?'Other':isLab?'Laboratory':isAI?'Prototype':'Other';
  const title=input.title || 'Untitled research';
  const extraction={
    source_assessment:{evidence_depth:evidenceDepth,source_sufficiency:evidenceDepth==='full_text'?'High':'Medium',missing_information:evidenceDepth==='full_text'?[]:['Full methods/results details may be unavailable in abstract-only evidence.']},
    research_identity:{title,field:isClinical?'Health Sciences':isAI?'AI / Geospatial Systems':isLab?'Environmental / Materials Engineering':'Research',subfield:isLab?'Sustainable materials':isAI?'Applied machine learning':'Applied research',research_type:isObs?'Observational study':isLab?'Experimental study':isAI?'Algorithm / dataset study':'Research study'},
    scientific_core:{
      research_question:`What does the supplied study establish about ${title.toLowerCase()}?`,
      objective:'Extract the demonstrated result while preserving the supplied evidence boundaries.',
      study_design:isObs?'Observational human study':isLab?'Laboratory experimental study':isAI?'Algorithm development / validation':'Study design not fully classified from demo heuristics',
      methods_summary:'Local demo mode does not infer unstated methodological details; it uses the supplied source text only.',
      population_or_system:isClinical?'Human/clinical system described in the source':isLab?'Experimental material/system described in the source':isAI?'Dataset / computational system described in the source':'System described in supplied source',
      sample_or_dataset:'See supplied source; not invented by Aletvia local demo mode.',
      comparator:'See supplied source; not invented when absent.',
      primary_outcomes:['Primary reported result(s) in supplied source']
    },
    findings:[{claim:'The supplied source reports a study-specific result that should be communicated only within its stated conditions.',support:'direct',evidence_basis:'Supplied source text',magnitude_or_direction:'Retain exact magnitude/direction from source when available.',caveat:evidenceDepth==='full_text'?'Use full-text limitations.':'Abstract-only evidence limits detailed verification.'}],
    evidence_maturity:{level:maturity,rationale:`Classified conservatively from terms present in the supplied ${evidenceDepth.replace('_',' ')}.`},
    limitations:[evidenceDepth==='full_text'?'Limitations should be taken from the full supplied source.':'Abstract-only evidence may omit important limitations and subgroup/method details.', isObs?'Association does not establish causation.':'Do not generalize beyond the demonstrated system.'],
    significance:{scientific:'Potential scientific relevance within the study domain.',practical:'Practical relevance requires validation appropriate to the study maturity.',societal:'Societal relevance should be treated as a possible implication unless directly evaluated.'},
    sensitive_research:{is_sensitive:sensitive,categories:sensitive?['Sensitive human topic']:[],review_mode:sensitive?'enhanced':'standard',rationale:sensitive?'Topic warrants enhanced ethical/scientific communication review.':'No sensitive-topic trigger detected in local demo mode.'},
    claims_to_avoid:[isObs?'Avoid causal statements such as “causes”, “prevents”, or “proves”.':'Avoid claiming real-world effectiveness beyond the demonstrated evidence stage.','Avoid claiming commercial or regulatory readiness unless directly established.'],
    uncertainty_summary:evidenceDepth==='full_text'?'Demo analysis remains conservative even with full text.':'Important details may be missing because the evidence is abstract-level.'
  };

  const profile={
    industry:dim('Low','Low','No strong industry pathway is assumed without domain evidence.'),
    policy:dim('Low','Low','No direct policy pathway is assumed without domain evidence.'),
    media:dim('Low','Low','Newsworthiness is not assumed in local demo mode.'),
    public:dim('Low','Low','Broad public relevance is not assumed in local demo mode.'),
    clinical:dim('Very Low','High','No clinical relevance is assumed unless health/clinical evidence is detected.'),
    academic_collaboration:dim('Moderate','Low','Most research has at least specialist scholarly relevance.'),
    funding:dim('Low','Low','Funder relevance requires a clearer thematic match.'),
    commercialization:dim('Low','Low','Application does not imply commercial readiness.')
  };
  if(isLab){ profile.industry=dim('High','Medium','Applied material/process research may be relevant to technical industry teams.','mixed'); profile.policy=dim('Moderate','Low','Environmental or technical policy relevance may exist but is not directly demonstrated.'); profile.media=dim('Moderate','Low','A public-facing narrative may exist if the problem and result are understandable.'); profile.public=dim('Moderate','Low','The applied environmental problem may be understandable outside academia.'); profile.commercialization=dim('Moderate','Low','Potential application does not establish readiness.'); profile.academic_collaboration=dim('High','Medium','Cross-disciplinary technical collaboration is plausible.'); }
  if(isClinical){ profile.clinical=dim('Very High','Medium','The research directly concerns a health/clinical problem.','paper_supported'); profile.media=dim('Moderate','Low','Public interest may exist but evidence maturity requires careful framing.'); }
  if(isAI){ profile.industry=dim('High','Medium','Applied AI methods may be relevant to domain technology users.','mixed'); profile.policy=dim('High','Low','Potential operational relevance depends on the deployment context.'); profile.academic_collaboration=dim('Very High','Medium','Methods/datasets can support research collaboration.','mixed'); }
  if(sensitive){ profile.media=dim('Low','Medium','Sensitivity raises risk of harm or stigmatizing simplification.','mixed'); profile.public=dim('Moderate','Low','Public relevance may exist, but communication requires enhanced review.','mixed'); }
  const opportunity={
    opportunity_profile:profile,
    stakeholder_categories:[{audience:isClinical?'Clinical/research specialists':isAI?'Domain technology and research teams':isLab?'Technical industry and research teams':'Relevant specialist audiences',priority:'Primary',why:'Closest match to the demonstrated research domain and evidence maturity.',basis:'mixed'}],
    recommended_actions:[{action:'Prepare an evidence-grounded specialist summary',audience:'Primary specialist audience',priority:'High',rationale:'Best first activation while preserving scientific context.',prerequisite:sensitive?'Enhanced human review required.':'Researcher review required.'}],
    communication_priority:{level:sensitive?'B':'A',reason:sensitive?'Potential value exists, but enhanced review should precede activation.':'A credible specialist activation pathway is identifiable.'},
    inferred_opportunities_summary:'Local demo mode demonstrates the data contract and workflow; live AI should refine the audience and action map.',
    opportunity_uncertainty:'Opportunity ratings are conservative placeholders in local demo mode and must not be treated as live AI analysis.'
  };
  return {extraction, opportunity, provider:'local-demo', model:'deterministic-demo-v1'};
}
