export const levelEnum = ["Very Low", "Low", "Moderate", "High", "Very High"];
export const confidenceEnum = ["Low", "Medium", "High"];
export const basisEnum = ["paper_supported", "aletvia_inferred", "mixed"];

const dimensionSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    level: { type: "string", enum: levelEnum },
    confidence: { type: "string", enum: confidenceEnum },
    rationale: { type: "string" },
    basis: { type: "string", enum: basisEnum }
  },
  required: ["level", "confidence", "rationale", "basis"]
};

export const scientificExtractionSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    source_assessment: {
      type: "object",
      additionalProperties: false,
      properties: {
        evidence_depth: { type: "string", enum: ["metadata", "abstract", "full_text"] },
        source_sufficiency: { type: "string", enum: ["Low", "Medium", "High"] },
        missing_information: { type: "array", items: { type: "string" } }
      },
      required: ["evidence_depth", "source_sufficiency", "missing_information"]
    },
    research_identity: {
      type: "object",
      additionalProperties: false,
      properties: {
        title: { type: "string" },
        field: { type: "string" },
        subfield: { type: "string" },
        research_type: { type: "string" }
      },
      required: ["title", "field", "subfield", "research_type"]
    },
    scientific_core: {
      type: "object",
      additionalProperties: false,
      properties: {
        research_question: { type: "string" },
        objective: { type: "string" },
        study_design: { type: "string" },
        methods_summary: { type: "string" },
        population_or_system: { type: "string" },
        sample_or_dataset: { type: "string" },
        comparator: { type: "string" },
        primary_outcomes: { type: "array", items: { type: "string" } }
      },
      required: ["research_question", "objective", "study_design", "methods_summary", "population_or_system", "sample_or_dataset", "comparator", "primary_outcomes"]
    },
    findings: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          claim: { type: "string" },
          support: { type: "string", enum: ["direct", "inferred", "uncertain"] },
          evidence_basis: { type: "string" },
          magnitude_or_direction: { type: "string" },
          caveat: { type: "string" }
        },
        required: ["claim", "support", "evidence_basis", "magnitude_or_direction", "caveat"]
      }
    },
    evidence_maturity: {
      type: "object",
      additionalProperties: false,
      properties: {
        level: { type: "string", enum: ["Foundational", "Simulation", "Laboratory", "Animal / preclinical", "Observational human study", "Controlled human study", "Prototype", "Field validated", "Systematic review / meta-analysis", "Protocol / expert consensus", "Other"] },
        rationale: { type: "string" }
      },
      required: ["level", "rationale"]
    },
    limitations: { type: "array", items: { type: "string" } },
    significance: {
      type: "object",
      additionalProperties: false,
      properties: {
        scientific: { type: "string" },
        practical: { type: "string" },
        societal: { type: "string" }
      },
      required: ["scientific", "practical", "societal"]
    },
    sensitive_research: {
      type: "object",
      additionalProperties: false,
      properties: {
        is_sensitive: { type: "boolean" },
        categories: { type: "array", items: { type: "string" } },
        review_mode: { type: "string", enum: ["standard", "enhanced"] },
        rationale: { type: "string" }
      },
      required: ["is_sensitive", "categories", "review_mode", "rationale"]
    },
    claims_to_avoid: { type: "array", items: { type: "string" } },
    uncertainty_summary: { type: "string" }
  },
  required: ["source_assessment", "research_identity", "scientific_core", "findings", "evidence_maturity", "limitations", "significance", "sensitive_research", "claims_to_avoid", "uncertainty_summary"]
};

export const opportunityAssessmentSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    opportunity_profile: {
      type: "object",
      additionalProperties: false,
      properties: {
        industry: dimensionSchema,
        policy: dimensionSchema,
        media: dimensionSchema,
        public: dimensionSchema,
        clinical: dimensionSchema,
        academic_collaboration: dimensionSchema,
        funding: dimensionSchema,
        commercialization: dimensionSchema
      },
      required: ["industry", "policy", "media", "public", "clinical", "academic_collaboration", "funding", "commercialization"]
    },
    stakeholder_categories: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          audience: { type: "string" },
          priority: { type: "string", enum: ["Primary", "Secondary"] },
          why: { type: "string" },
          basis: { type: "string", enum: basisEnum }
        },
        required: ["audience", "priority", "why", "basis"]
      }
    },
    recommended_actions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          action: { type: "string" },
          audience: { type: "string" },
          priority: { type: "string", enum: ["High", "Medium", "Low"] },
          rationale: { type: "string" },
          prerequisite: { type: "string" }
        },
        required: ["action", "audience", "priority", "rationale", "prerequisite"]
      }
    },
    communication_priority: {
      type: "object",
      additionalProperties: false,
      properties: {
        level: { type: "string", enum: ["A", "B", "C", "No active recommendation"] },
        reason: { type: "string" }
      },
      required: ["level", "reason"]
    },
    inferred_opportunities_summary: { type: "string" },
    opportunity_uncertainty: { type: "string" }
  },
  required: ["opportunity_profile", "stakeholder_categories", "recommended_actions", "communication_priority", "inferred_opportunities_summary", "opportunity_uncertainty"]
};

export const finalResearchIntelligenceSchemaVersion = "1.0";
