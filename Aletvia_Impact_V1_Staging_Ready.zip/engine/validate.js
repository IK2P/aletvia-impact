import { levelEnum, confidenceEnum, basisEnum, finalResearchIntelligenceSchemaVersion } from './schemas.js';

function isString(x){ return typeof x === 'string'; }
function isArray(x){ return Array.isArray(x); }
function assert(cond, msg){ if(!cond) throw new Error(`Research Intelligence validation failed: ${msg}`); }
function oneOf(v, arr){ return arr.includes(v); }

export function validateExtraction(x){
  assert(x && typeof x === 'object', 'extraction must be an object');
  assert(x.source_assessment && isString(x.source_assessment.evidence_depth), 'source_assessment missing');
  assert(['metadata','abstract','full_text'].includes(x.source_assessment.evidence_depth), 'invalid evidence_depth');
  assert(['Low','Medium','High'].includes(x.source_assessment.source_sufficiency), 'invalid source_sufficiency');
  assert(isArray(x.source_assessment.missing_information), 'missing_information must be array');
  assert(x.research_identity && isString(x.research_identity.title), 'research_identity missing');
  assert(x.scientific_core && isString(x.scientific_core.research_question), 'scientific_core missing');
  assert(isArray(x.findings), 'findings must be array');
  for (const f of x.findings){
    assert(isString(f.claim), 'finding claim missing');
    assert(['direct','inferred','uncertain'].includes(f.support), 'invalid finding support');
  }
  assert(x.evidence_maturity && isString(x.evidence_maturity.level), 'evidence_maturity missing');
  assert(isArray(x.limitations), 'limitations must be array');
  assert(x.significance && isString(x.significance.scientific), 'significance missing');
  assert(x.sensitive_research && typeof x.sensitive_research.is_sensitive === 'boolean', 'sensitive_research missing');
  assert(isArray(x.claims_to_avoid), 'claims_to_avoid must be array');
  return x;
}

export function validateOpportunity(x){
  assert(x && typeof x === 'object', 'opportunity must be object');
  const op = x.opportunity_profile;
  assert(op && typeof op === 'object', 'opportunity_profile missing');
  for (const k of ['industry','policy','media','public','clinical','academic_collaboration','funding','commercialization']){
    const d=op[k]; assert(d, `${k} missing`);
    assert(oneOf(d.level, levelEnum), `${k} invalid level`);
    assert(oneOf(d.confidence, confidenceEnum), `${k} invalid confidence`);
    assert(oneOf(d.basis, basisEnum), `${k} invalid basis`);
    assert(isString(d.rationale), `${k} rationale missing`);
  }
  assert(isArray(x.stakeholder_categories), 'stakeholder_categories must be array');
  assert(isArray(x.recommended_actions), 'recommended_actions must be array');
  assert(x.communication_priority && ['A','B','C','No active recommendation'].includes(x.communication_priority.level), 'invalid communication priority');
  return x;
}

export function postProcessResearchIntelligence(extraction, opportunity, meta={}){
  validateExtraction(extraction); validateOpportunity(opportunity);
  const warnings=[];
  const earlyMaturity=['Foundational','Simulation','Laboratory','Animal / preclinical','Protocol / expert consensus'];
  const high=v=>['High','Very High'].includes(v);
  if(extraction.source_assessment.evidence_depth === 'abstract' && extraction.source_assessment.source_sufficiency === 'High'){
    warnings.push('Abstract-only source was rated High sufficiency; human review recommended.');
  }
  if(extraction.source_assessment.evidence_depth === 'metadata'){
    const highConfidence=Object.values(opportunity.opportunity_profile).some(d=>d.confidence==='High');
    if(highConfidence) warnings.push('High-confidence opportunity rating produced from metadata-only evidence.');
  }
  if(extraction.evidence_maturity.level === 'Observational human study'){
    const text = JSON.stringify(opportunity).toLowerCase();
    if(/\bcauses?\b|\bprevents?\b|\bproves?\b|\bcures?\b/.test(text)) warnings.push('Potential causal language detected for observational evidence.');
  }
  if(extraction.sensitive_research.is_sensitive && extraction.sensitive_research.review_mode !== 'enhanced'){
    warnings.push('Sensitive research should use enhanced review.');
  }
  if(extraction.sensitive_research.is_sensitive && high(opportunity.opportunity_profile.media.level)){
    warnings.push('High media opportunity on sensitive research requires enhanced human review before activation.');
  }
  if(earlyMaturity.includes(extraction.evidence_maturity.level) && high(opportunity.opportunity_profile.clinical.level)){
    warnings.push('High clinical opportunity on early-stage evidence must not be interpreted as demonstrated clinical efficacy.');
  }
  if(earlyMaturity.includes(extraction.evidence_maturity.level) && high(opportunity.opportunity_profile.commercialization.level)){
    warnings.push('High commercialization opportunity on early-stage evidence requires separate readiness validation.');
  }
  return {
    schema_version: finalResearchIntelligenceSchemaVersion,
    generated_at: new Date().toISOString(),
    engine: {
      pipeline_version: 'research-intelligence-v1',
      extraction_prompt_version: '1.0',
      opportunity_prompt_version: '1.0',
      provider: meta.provider || 'unknown',
      model: meta.model || 'unknown',
      mode: meta.mode || 'unknown'
    },
    provenance: {
      source_fingerprint_sha256: meta.sourceFingerprint || '',
      source_characters: meta.sourceCharacters || 0
    },
    extraction,
    opportunity,
    quality_control: {
      passed: warnings.length === 0,
      warnings
    }
  };
}
