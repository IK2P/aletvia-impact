#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "Starting Aletvia on http://127.0.0.1:8787"
node server.js
