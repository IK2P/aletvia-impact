import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, verifyPassword, createSession, sessionFromToken, tokenHash, audit } from './backend-db.js';
import { analyzeResearch } from './engine/research-intelligence-engine.js';
import { ensureStep3Schema, ingestDoi, ingestOrcid, ingestPdf, normalizeDoi, normalizeOrcid, isValidOrcid } from './ingestion/research-ingestion.js';
import { generateCommunicationAsset, generateContentPack, contentPacks, assetFamily, allowedAssetTypes } from './communication/communication-engine.js';
import { ensureStep4Schema, listAssets, getAsset, createGeneratedAsset, addVersion, addManualVersion, setAssetStatus, createContentPack, getContentPack, listContentPacks } from './communication/persistence.js';
import { verifyFidelity } from './fidelity/fidelity-engine.js';
import { ensureStep5Schema, buildVerificationPacket, persistFidelityReport, getFidelityReport, listFidelityReports, latestFidelityReport, currentFidelityState, approvalGate } from './fidelity/persistence.js';
import { ensureStep6Schema, ensureApprovalCase, getApprovalCase, getApprovalCaseByAsset, listApprovalCases, recordDecision, addApprovalComment, listApprovalComments, updateGovernanceOptions, approvalTimeline, recomputeApprovalCase } from './governance/workflow.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const defaultDb=process.env.ALETVIA_DB_PATH || path.join(__dirname,'data','aletvia.sqlite');

function json(res,status,obj,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(obj))}
function parseCookies(req){const out={};for(const part of (req.headers.cookie||'').split(';')){const i=part.indexOf('=');if(i>0)out[part.slice(0,i).trim()]=decodeURIComponent(part.slice(i+1).trim())}return out}
async function body(req,maxBytes=2_000_000){let raw='';for await(const c of req){raw+=c;if(Buffer.byteLength(raw,'utf8')>maxBytes) throw new Error('Request too large')}return raw?JSON.parse(raw):{}}
function publicSession(s){return {user:{id:s.user_id,email:s.email,display_name:s.display_name},active_institution:{id:s.membership.institution_id,name:s.membership.institution_name,short_code:s.membership.short_code,role:s.membership.role},institutions:s.institutions}}
function canManage(role){return ['institution_admin','research_office_reviewer','communications_reviewer'].includes(role)}
function serializeResearch(db,row){
 const opportunities=db.prepare('SELECT dimension,rating,confidence,rationale FROM opportunity_assessments WHERE research_output_id=? ORDER BY id').all(row.id);
 return {id:row.id,title:row.title,authors:row.authors,owner:row.owner_user_id,owner_name:row.owner_name,dept:row.department_name||'—',journal:row.journal,doi:row.doi,date:row.publication_date,state:row.publication_state,depth:row.evidence_depth,maturity:row.evidence_maturity,priority:row.communication_priority,workflow:row.workflow_state,sensitive:!!row.sensitive,did:row.did_text,found:row.found_text,why:row.why_text,limits:row.limitations_text,audience:JSON.parse(row.audience_json||'[]'),action:row.action_text,visibility:row.visibility_text,ingestion_status:row.ingestion_status||'legacy',latest_source_type:row.latest_source_type||null,opportunities:Object.fromEntries(opportunities.map(o=>[o.dimension,[o.rating,o.confidence,o.rationale]]))};
}
function listResearch(db,s){
 const role=s.membership.role; let sql=`SELECT r.*,d.name department_name,u.display_name owner_name FROM research_outputs r LEFT JOIN departments d ON d.id=r.department_id JOIN users u ON u.id=r.owner_user_id WHERE r.institution_id=?`;const args=[s.active_institution_id];
 if(role==='researcher'){sql+=' AND r.owner_user_id=?';args.push(s.user_id)} sql+=' ORDER BY r.publication_date DESC';
 return db.prepare(sql).all(...args).map(r=>serializeResearch(db,r));
}
function getResearch(db,s,id){
 let sql=`SELECT r.*,d.name department_name,u.display_name owner_name FROM research_outputs r LEFT JOIN departments d ON d.id=r.department_id JOIN users u ON u.id=r.owner_user_id WHERE r.id=? AND r.institution_id=?`;const args=[id,s.active_institution_id];
 if(s.membership.role==='researcher'){sql+=' AND r.owner_user_id=?';args.push(s.user_id)} const row=db.prepare(sql).get(...args);return row?serializeResearch(db,row):null;
}
function mime(file){return file.endsWith('.html')?'text/html':file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.png')?'image/png':file.endsWith('.md')?'text/markdown':'application/octet-stream'}

function latestIntelligence(db,institutionId,researchId){
 const row=db.prepare('SELECT record_json,created_at FROM research_intelligence_records WHERE research_output_id=? AND institution_id=? ORDER BY created_at DESC LIMIT 1').get(researchId,institutionId);
 return row?{record:JSON.parse(row.record_json),created_at:row.created_at}:null;
}
function scopedAsset(db,s,id){const a=getAsset(db,s.active_institution_id,id);if(!a)return null;if(s.membership.role==='researcher'&&a.owner_user_id!==s.user_id)return null;return a}


export function createAppServer(dbPath=defaultDb){
 const db=openDb(dbPath); ensureStep3Schema(db); ensureStep4Schema(db); ensureStep5Schema(db); ensureStep6Schema(db);
 return http.createServer(async(req,res)=>{
  try{
   const u=new URL(req.url,'http://localhost'); const cookies=parseCookies(req); const s=sessionFromToken(db,cookies.aletvia_session);
   if(req.method==='POST'&&u.pathname==='/api/auth/login'){
    const b=await body(req);const user=db.prepare('SELECT * FROM users WHERE lower(email)=lower(?)').get(b.email||'');
    if(!user||!verifyPassword(b.password||'',user.password_salt,user.password_hash)) return json(res,401,{error:'Invalid email or password'});
    const memberships=db.prepare('SELECT institution_id FROM memberships WHERE user_id=? AND active=1 ORDER BY id').all(user.id);if(!memberships.length)return json(res,403,{error:'No active institutional membership'});
    const token=createSession(db,user.id,memberships[0].institution_id);const ss=sessionFromToken(db,token);audit(db,ss,'auth.login');
    return json(res,200,publicSession(ss),{'Set-Cookie':`aletvia_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800`});
   }
   if(req.method==='POST'&&u.pathname==='/api/auth/logout'){
    if(cookies.aletvia_session) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(cookies.aletvia_session));
    return json(res,200,{ok:true},{'Set-Cookie':'aletvia_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'});
   }
   if(req.method==='GET'&&u.pathname==='/api/health') return json(res,200,{ok:true,service:'aletvia-impact',version:'1.0.0-pilot',database:process.env.ALETVIA_DB_PATH?'configured':'default'});
   if(u.pathname.startsWith('/api/')&&!s) return json(res,401,{error:'Authentication required'});
   if(req.method==='GET'&&u.pathname==='/api/session') return json(res,200,publicSession(s));
   if(req.method==='POST'&&u.pathname==='/api/session/institution'){
    const b=await body(req);const mem=db.prepare('SELECT 1 FROM memberships WHERE user_id=? AND institution_id=? AND active=1').get(s.user_id,b.institution_id);
    if(!mem)return json(res,403,{error:'You are not a member of that institution'});
    db.prepare('UPDATE sessions SET active_institution_id=? WHERE token_hash=?').run(b.institution_id,tokenHash(cookies.aletvia_session));const ss=sessionFromToken(db,cookies.aletvia_session);audit(db,ss,'tenant.switch','institution',b.institution_id);return json(res,200,publicSession(ss));
   }
   if(req.method==='GET'&&u.pathname==='/api/research') return json(res,200,{research:listResearch(db,s)});
   if(req.method==='GET'&&u.pathname.startsWith('/api/research/')){const id=decodeURIComponent(u.pathname.split('/').pop());const r=getResearch(db,s,id);return r?json(res,200,r):json(res,404,{error:'Research not found in active tenant/scope'});}
   if(req.method==='GET'&&u.pathname==='/api/researchers'){
    if(s.membership.role==='researcher') return json(res,403,{error:'Insufficient permission'});
    const rows=db.prepare(`SELECT u.id,u.display_name name,u.email,m.role,d.name dept FROM memberships m JOIN users u ON u.id=m.user_id LEFT JOIN departments d ON d.id=m.department_id WHERE m.institution_id=? AND m.active=1 ORDER BY u.display_name`).all(s.active_institution_id);return json(res,200,{researchers:rows});
   }
   if(req.method==='PATCH'&&u.pathname.match(/^\/api\/research\/[^/]+\/workflow$/)){
    const id=decodeURIComponent(u.pathname.split('/')[3]);const scoped=getResearch(db,s,id);if(!scoped)return json(res,404,{error:'Research not found in active tenant/scope'});const b=await body(req);const allowed=['Draft','Researcher Review','Researcher Approved','Institutional Review','Approved','Revision Requested','Declined','Embargoed','IP Review Required','Enhanced Review'];if(!allowed.includes(b.state))return json(res,400,{error:'Invalid workflow state'});
    if(s.membership.role==='researcher' && b.state!=='Researcher Approved') return json(res,403,{error:'Researchers may only submit their own research for institutional review'});
    if(s.membership.role!=='researcher' && !canManage(s.membership.role)) return json(res,403,{error:'This role cannot change institutional workflow state'});
    db.prepare('UPDATE research_outputs SET workflow_state=? WHERE id=? AND institution_id=?').run(b.state,id,s.active_institution_id);audit(db,s,'workflow.update','research_output',id,{state:b.state});return json(res,200,getResearch(db,s,id));
   }
   if(req.method==='GET'&&u.pathname==='/api/dashboard'){
    const research=listResearch(db,s);const metrics={outputs:research.length,priority_a:research.filter(x=>x.priority==='A').length,awaiting_researcher:research.filter(x=>x.workflow==='Researcher Review').length,awaiting_institution:research.filter(x=>['Researcher Approved','Institutional Review','Enhanced Review'].includes(x.workflow)).length,activated:research.filter(x=>x.workflow==='Approved').length};return json(res,200,{metrics});
   }
   if(req.method==='GET'&&u.pathname==='/api/ingestion/capabilities') return json(res,200,{step:3,doi:{provider:'Crossref REST API',requires_credentials:false},pdf:{max_mb:15,text_extraction:'pdftotext',ocr:false},orcid:{validated_id:true,public_api_token_configured:!!process.env.ORCID_PUBLIC_TOKEN,fallback:'Crossref works filtered by ORCID'},automatic_analysis:'Runs frozen Step 1 when >=80 and <=200000 source characters'});
   if(req.method==='POST'&&u.pathname==='/api/ingest/doi'){
    const b=await body(req); if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot import research'});
    const doi=normalizeDoi(b.doi||''); if(!doi)return json(res,400,{error:'DOI is required'});
    try{const out=await ingestDoi(db,s,doi,{owner_user_id:b.owner_user_id,analyze:b.analyze!==false});audit(db,s,'ingestion.doi','research_output',out.research_output_id,{doi,created:out.created,deduplicated:out.deduplicated});return json(res,200,out)}catch(e){return json(res,e.status===404?404:400,{error:String(e.message||e)})}
   }
   if(req.method==='POST'&&u.pathname==='/api/ingest/orcid'){
    const b=await body(req); if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot import research'});
    const orcid=normalizeOrcid(b.orcid||''); if(!isValidOrcid(orcid))return json(res,400,{error:'A valid ORCID iD is required'});
    try{const out=await ingestOrcid(db,s,orcid,{owner_user_id:b.owner_user_id,analyze:b.analyze!==false,limit:b.limit||25});audit(db,s,'ingestion.orcid','researcher',s.user_id,{orcid,works_found:out.works_found,provider:out.provider});return json(res,200,out)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='POST'&&u.pathname==='/api/ingest/pdf'){
    if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot import research'}); const b=await body(req,22_000_000);
    try{const out=await ingestPdf(db,s,{filename:b.filename||'paper.pdf',content_base64:b.content_base64||'',owner_user_id:b.owner_user_id,analyze:b.analyze!==false});audit(db,s,'ingestion.pdf','research_output',out.research_output_id,{filename:b.filename||'paper.pdf',characters:out.canonical.extracted_characters,created:out.created,deduplicated:out.deduplicated});return json(res,200,out)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='GET'&&u.pathname.startsWith('/api/research-intelligence/')){const id=decodeURIComponent(u.pathname.split('/').pop());const r=getResearch(db,s,id);if(!r)return json(res,404,{error:'Research not found in active tenant/scope'});const row=db.prepare('SELECT record_json,created_at FROM research_intelligence_records WHERE research_output_id=? AND institution_id=? ORDER BY created_at DESC LIMIT 1').get(id,s.active_institution_id);return json(res,200,{research:r,intelligence:row?JSON.parse(row.record_json):null,generated_at:row?.created_at||null});}
   if(req.method==='GET'&&u.pathname==='/api/communication/capabilities') return json(res,200,{step:4,name:'Research, Communication & Content Studio',short_name:'RCC Studio',mode:process.env.OPENAI_API_KEY?'openai':'local-demo',provider:process.env.OPENAI_API_KEY?'OpenAI Responses API':'deterministic local demo',model:process.env.OPENAI_COMM_MODEL||process.env.OPENAI_MODEL||(process.env.OPENAI_API_KEY?'gpt-5.6-terra':'deterministic-rcc-v1'),requires_research_intelligence:true,version_history:true,human_approval_required:true,artifact_families:['Text','Visual','Motion','Learning'],packs:contentPacks()});

   if(req.method==='GET'&&u.pathname==='/api/fidelity/capabilities') return json(res,200,{step:5,name:'Multimodal Scientific Fidelity Engine',mode:process.env.OPENAI_API_KEY?'openai':'local-rules',provider:process.env.OPENAI_API_KEY?'OpenAI Responses API':'independent deterministic verifier',model:process.env.OPENAI_FIDELITY_MODEL||process.env.OPENAI_MODEL||(process.env.OPENAI_API_KEY?'gpt-5.6-sol':'aletvia-fidelity-rules-v1'),independent_from_generation:true,modalities:['text','visual','motion','learning'],verdicts:['Supported','Supported with context','Speculative','Unsupported'],version_bound:true,approval_gate:true});
   if(req.method==='POST'&&u.pathname==='/api/fidelity/verify'){
    if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot run fidelity verification'});const b=await body(req);const a=scopedAsset(db,s,b.asset_id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});
    try{const packet=buildVerificationPacket(db,s,a);const verification=await verifyFidelity(packet);const report=persistFidelityReport(db,s,a,verification);audit(db,s,'fidelity.verify','communication_asset',a.id,{report_id:report.id,asset_version:a.latest_version.version_number,overall_status:report.overall_status,approval_eligible:report.approval_eligible});return json(res,200,report)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='GET'&&u.pathname==='/api/fidelity-reports'){const assetId=u.searchParams.get('asset_id')||undefined;return json(res,200,{reports:listFidelityReports(db,s,{asset_id:assetId})});}
   if(req.method==='GET'&&u.pathname.match(/^\/api\/fidelity-reports\/[^/]+$/)){const id=decodeURIComponent(u.pathname.split('/').pop());const r=getFidelityReport(db,s,id);return r?json(res,200,r):json(res,404,{error:'Fidelity report not found in active tenant'});}
   if(req.method==='GET'&&u.pathname.match(/^\/api\/fidelity-status\/[^/]+$/)){const id=decodeURIComponent(u.pathname.split('/').pop());const a=scopedAsset(db,s,id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});return json(res,200,{state:currentFidelityState(db,s,id),latest_report:latestFidelityReport(db,s,id)});}

   if(req.method==='GET'&&u.pathname==='/api/governance/capabilities') return json(res,200,{step:6,name:'Institutional Approval & Governance Workflow',routes:{standard:['Researcher sign-off','Current Step-5 fidelity','Communications review','Ready for Activation'],enhanced:['Researcher sign-off','Current Step-5 fidelity','Research Office review','Communications review','Ready for Activation']},version_bound_reviews:true,sensitive_forces_enhanced:true,ip_gate:true,embargo_gate:true,comments:true,audit_timeline:true});
   if(req.method==='GET'&&u.pathname==='/api/approval-cases'){const status=u.searchParams.get('status')||undefined;const cases=listApprovalCases(db,s,{status});for(const c of cases)recomputeApprovalCase(db,s,c.id);return json(res,200,{cases:listApprovalCases(db,s,{status})});}
   if(req.method==='POST'&&u.pathname==='/api/approval-cases'){
    if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot open approval cases'});const b=await body(req);const a=scopedAsset(db,s,b.asset_id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});
    try{return json(res,200,ensureApprovalCase(db,s,a.id,{workflow_mode:b.workflow_mode,ip_review_required:!!b.ip_review_required,embargo_until:b.embargo_until||null}))}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='GET'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+$/)){const id=decodeURIComponent(u.pathname.split('/').pop());const c=getApprovalCase(db,s,id);if(!c)return json(res,404,{error:'Approval case not found in active tenant/scope'});recomputeApprovalCase(db,s,id);return json(res,200,getApprovalCase(db,s,id));}
   if(req.method==='GET'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/timeline$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);const x=approvalTimeline(db,s,id);return x?json(res,200,x):json(res,404,{error:'Approval case not found in active tenant/scope'});}
   if(req.method==='POST'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/decisions$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);const b=await body(req);try{return json(res,200,recordDecision(db,s,id,b))}catch(e){return json(res,403,{error:String(e.message||e)})}}
   if(req.method==='GET'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/comments$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);return json(res,200,{comments:listApprovalComments(db,s,id)});}
   if(req.method==='POST'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/comments$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);const b=await body(req);try{return json(res,200,{comments:addApprovalComment(db,s,id,b)})}catch(e){return json(res,400,{error:String(e.message||e)})}}
   if(req.method==='PATCH'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/governance$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);const b=await body(req);try{return json(res,200,updateGovernanceOptions(db,s,id,b))}catch(e){return json(res,403,{error:String(e.message||e)})}}
   if(req.method==='POST'&&u.pathname.match(/^\/api\/approval-cases\/[^/]+\/recompute$/)){const id=decodeURIComponent(u.pathname.split('/')[3]);try{return json(res,200,recomputeApprovalCase(db,s,id))}catch(e){return json(res,400,{error:String(e.message||e)})}}
   if(req.method==='GET'&&u.pathname==='/api/content-packs'){
    const researchId=u.searchParams.get('research_output_id')||undefined;return json(res,200,{packs:listContentPacks(db,s,{research_output_id:researchId}),catalog:contentPacks()});
   }
   if(req.method==='GET'&&u.pathname.match(/^\/api\/content-packs\/[^/]+$/)){
    const id=decodeURIComponent(u.pathname.split('/').pop());const pack=getContentPack(db,s,id);return pack?json(res,200,pack):json(res,404,{error:'Content pack not found in active tenant/scope'});
   }
   if(req.method==='POST'&&u.pathname==='/api/content-packs/generate'){
    if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot generate content packs'});const b=await body(req);const r=getResearch(db,s,b.research_output_id);if(!r)return json(res,404,{error:'Research not found in active tenant/scope'});const ir=latestIntelligence(db,s.active_institution_id,r.id);if(!ir)return json(res,409,{error:'Research Intelligence Record required before content-pack generation.'});
    try{const generated=await generateContentPack({research:r,intelligence:ir.record,branding:b.branding||{}},b.pack_name);const packId=createContentPack(db,s,{research_output_id:r.id,pack_name:b.pack_name});const assets=[];for(const g of generated.assets){assets.push(createGeneratedAsset(db,s,{research_output_id:r.id,audience:g.asset.audience,asset_family:g.asset.asset_family,asset_type:g.asset.asset_type,generation:g,content_pack_id:packId}))}audit(db,s,'rcc.pack.generate','content_pack',packId,{research_output_id:r.id,pack_name:b.pack_name,assets:assets.length});return json(res,200,getContentPack(db,s,packId))}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='GET'&&u.pathname==='/api/communication-assets'){
    const researchId=u.searchParams.get('research_output_id')||undefined;return json(res,200,{assets:listAssets(db,s,{research_output_id:researchId})});
   }
   if(req.method==='GET'&&u.pathname.match(/^\/api\/communication-assets\/[^/]+$/)){
    const id=decodeURIComponent(u.pathname.split('/').pop());const a=scopedAsset(db,s,id);return a?json(res,200,a):json(res,404,{error:'Communication asset not found in active tenant/scope'});
   }
   if(req.method==='POST'&&u.pathname==='/api/communication/generate'){
    if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot generate communication assets'});const b=await body(req);const r=getResearch(db,s,b.research_output_id);if(!r)return json(res,404,{error:'Research not found in active tenant/scope'});const ir=latestIntelligence(db,s.active_institution_id,r.id);if(!ir)return json(res,409,{error:'Research Intelligence Record required. Import/analyze this research through Step 1 before generating communication.'});
    try{const family=b.asset_family||assetFamily(b.asset_type);const generation=await generateCommunicationAsset({research:r,intelligence:ir.record,audience:b.audience,asset_family:family,asset_type:b.asset_type,branding:b.branding||{}});const a=createGeneratedAsset(db,s,{research_output_id:r.id,audience:b.audience,asset_family:family,asset_type:b.asset_type,generation});audit(db,s,'rcc.generate','communication_asset',a.id,{research_output_id:r.id,audience:b.audience,asset_family:family,asset_type:b.asset_type,provider:generation.engine.provider,model:generation.engine.model});return json(res,200,a)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='POST'&&u.pathname.match(/^\/api\/communication-assets\/[^/]+\/revise$/)){
    const id=decodeURIComponent(u.pathname.split('/')[3]);const a=scopedAsset(db,s,id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot revise communication assets'});const b=await body(req);const r=getResearch(db,s,a.research_output_id);const ir=latestIntelligence(db,s.active_institution_id,r.id);if(!ir)return json(res,409,{error:'Research Intelligence Record required for revision.'});
    try{const generation=await generateCommunicationAsset({research:r,intelligence:ir.record,audience:a.audience,asset_family:a.asset_family||assetFamily(a.asset_type),asset_type:a.asset_type,revision_instruction:b.instruction||'',prior_content:a.latest_version?.body_markdown||'',branding:b.branding||{}});const updated=addVersion(db,s,id,generation,b.instruction||'');audit(db,s,'rcc.revise','communication_asset',id,{version:updated.latest_version.version_number});return json(res,200,updated)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='PATCH'&&u.pathname.match(/^\/api\/communication-assets\/[^/]+$/)){
    const id=decodeURIComponent(u.pathname.split('/').pop());const a=scopedAsset(db,s,id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot edit communication assets'});const b=await body(req);try{const updated=addManualVersion(db,s,id,{body_markdown:b.body_markdown});audit(db,s,'communication.edit','communication_asset',id,{version:updated.latest_version.version_number});return json(res,200,updated)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='POST'&&u.pathname.match(/^\/api\/communication-assets\/[^/]+\/submit$/)){
    const id=decodeURIComponent(u.pathname.split('/')[3]);const a=scopedAsset(db,s,id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});if(s.membership.role==='leadership_viewer')return json(res,403,{error:'Leadership viewer cannot submit assets'});try{const c=ensureApprovalCase(db,s,id,{});if(s.membership.role==='researcher')recordDecision(db,s,c.id,{review_type:'researcher',decision:'approve',comment:'Researcher submitted this version for institutional review.'});else recomputeApprovalCase(db,s,c.id);audit(db,s,'communication.submit','communication_asset',id,{approval_case_id:c.id});return json(res,200,getAsset(db,s.active_institution_id,id))}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='PATCH'&&u.pathname.match(/^\/api\/communication-assets\/[^/]+\/status$/)){
    const id=decodeURIComponent(u.pathname.split('/')[3]);const a=scopedAsset(db,s,id);if(!a)return json(res,404,{error:'Communication asset not found in active tenant/scope'});const b=await body(req);if(s.membership.role==='researcher'){if(b.status!=='Researcher Approved')return json(res,403,{error:'Researchers may only mark their own communication asset Researcher Approved'});}else if(!canManage(s.membership.role))return json(res,403,{error:'This role cannot change communication approval status'});if(b.status==='Approved'){const gate=approvalGate(db,s,id);if(!gate.ok)return json(res,409,{error:gate.reason,fidelity:gate.state});try{const c=ensureApprovalCase(db,s,id,{});if(s.membership.role==='institution_admin'||s.membership.role==='communications_reviewer'){const gc=recordDecision(db,s,c.id,{review_type:'communications',decision:'approve',comment:'Compatibility approval recorded through institutional status action.'});if(gc.workflow_mode==='Enhanced'&&!gc.decisions.research_office.current&&s.membership.role==='institution_admin')recordDecision(db,s,c.id,{review_type:'research_office',decision:'approve',comment:'Institution admin completed enhanced Research Office review.'});const finalCase=recomputeApprovalCase(db,s,c.id);if(!finalCase.ready&&finalCase.status!=='Embargoed')return json(res,409,{error:'Step-6 governance requirements are not yet complete.',approval_case:finalCase});audit(db,s,'governance.compat.approve','communication_asset',id,{case_id:c.id,status:finalCase.status});return json(res,200,getAsset(db,s.active_institution_id,id))}}catch(e){return json(res,400,{error:String(e.message||e)})}}try{const updated=setAssetStatus(db,s,id,b.status);const map={'Researcher Approved':'Researcher Approved','Institutional Review':'Institutional Review','Approved':'Approved','Revision Requested':'Revision Requested','Declined':'Declined'};if(map[b.status])db.prepare('UPDATE research_outputs SET workflow_state=? WHERE id=? AND institution_id=?').run(map[b.status],a.research_output_id,s.active_institution_id);audit(db,s,'communication.status','communication_asset',id,{status:b.status});return json(res,200,updated)}catch(e){return json(res,400,{error:String(e.message||e)})}
   }
   if(req.method==='GET'&&u.pathname==='/api/engine-status') return json(res,200,{mode:process.env.OPENAI_API_KEY?'openai':'local-demo',step:1});
   if(req.method==='POST'&&u.pathname==='/api/analyze-research'){
    const b=await body(req);const result=await analyzeResearch(b);audit(db,s,'research.analyze','research_output',null,{title:b.title||''});return json(res,200,result);
   }
   if(req.method==='GET'&&u.pathname==='/api/audit'){
    if(!canManage(s.membership.role)&&s.membership.role!=='leadership_viewer')return json(res,403,{error:'Insufficient permission'});const rows=db.prepare('SELECT * FROM audit_events WHERE institution_id=? ORDER BY id DESC LIMIT 100').all(s.active_institution_id);return json(res,200,{events:rows});
   }
   if(req.method!=='GET'&&req.method!=='HEAD') return json(res,404,{error:'Not found'});
   let rel=u.pathname==='/'?'index.html':u.pathname.replace(/^\//,''); if(rel.includes('..')) return json(res,400,{error:'Bad path'}); const file=path.join(__dirname,rel);if(!file.startsWith(__dirname)||!fs.existsSync(file)||fs.statSync(file).isDirectory()){res.writeHead(404);return res.end('Not found')};res.writeHead(200,{'Content-Type':mime(file),'Cache-Control':'no-cache'});if(req.method==='HEAD')return res.end();fs.createReadStream(file).pipe(res);
  }catch(e){console.error(e);json(res,500,{error:'Internal server error',detail:process.env.NODE_ENV==='development'?String(e):undefined})}
 });
}

if(process.argv[1]===fileURLToPath(import.meta.url)){
 const port=Number(process.env.PORT||8787);const host=process.env.HOST||'0.0.0.0';const server=createAppServer();server.listen(port,host,()=>console.log(`Aletvia Impact running at http://${host}:${port}`));
}
