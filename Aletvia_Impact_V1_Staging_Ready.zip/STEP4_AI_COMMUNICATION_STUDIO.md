# Step 4 — AI-Powered Communication Studio

Status: **COMPLETE / ready to freeze**

Frozen prerequisites: Step 1 Research Intelligence Engine, Step 2 Auth/Persistence/Multi-tenancy, Step 3 DOI/PDF/ORCID Ingestion.

## Objective

Convert a persisted Research Intelligence Record into audience-specific research communication without allowing the writing layer to bypass scientific extraction, evidence maturity, limitations, sensitive-research governance, or human approval.

Step 4 deliberately does **not** implement the independent claim-verification engine. That is Step 5. Instead, every generated draft contains a structured claim ledger and provenance metadata so Step 5 can independently verify the generated claims.

## Architecture

```
Research Object
   ↓
Frozen Step-1 Research Intelligence Record
   ↓
Communication Engine
   ├─ Audience selection
   ├─ Format-specific generation rules
   ├─ Evidence-boundary preservation
   └─ Structured claim ledger
   ↓
Versioned Communication Asset
   ├─ AI version
   ├─ human edit version
   └─ AI revision version
   ↓
Researcher submit
   ↓
Frozen Step-2 institutional approval workflow
   ↓
Step 5 Fidelity Engine (next; not implemented here)
```

## Supported audiences

- Public
- Industry
- Policy
- Media
- Clinical
- Academic

## Supported formats

- Plain-language summary
- Institutional research story
- LinkedIn post
- Media pitch
- Industry brief
- Policy brief
- Clinical evidence summary
- Collaboration summary
- Researcher Q&A

Formats are constrained by audience. For example, an Industry brief cannot be requested under the Clinical audience.

## Hard scientific rules

The communication model receives the **Research Intelligence Record**, not arbitrary web context. Its system contract requires:

- no invented sample sizes, effects, mechanisms, quotations, applications or stakeholder interest;
- evidence maturity preserved in wording;
- observational evidence not converted to causality;
- laboratory/simulation/protocol evidence not converted to demonstrated real-world efficacy;
- paper-supported findings separated from Aletvia-inferred relevance;
- claims-to-avoid inherited from Step 1;
- sensitive research written neutrally and kept in enhanced review;
- no automatic publishing.

The communication engine refuses generation if no persisted Research Intelligence Record exists.

## Structured output

Each generation returns:

- `audience`
- `asset_type`
- `headline`
- `dek`
- `body_markdown`
- `key_messages[]`
- `evidence_boundary`
- `suggested_call_to_action`
- `claim_ledger[]`
- `generation_notes[]`

Each claim-ledger item contains:

- claim text;
- `paper_supported`, `aletvia_inferred`, or `mixed` basis;
- a Research Intelligence path/reference;
- a generation-time risk note.

**Important:** these basis labels are generation provenance, not independent fidelity verdicts. Step 5 performs that verification.

## Real AI provider

When `OPENAI_API_KEY` is configured, the server uses OpenAI's Responses API with:

- server-side API key only;
- `store: false`;
- strict JSON-schema Structured Outputs;
- retry for transient 429/5xx/network failures;
- request timeout;
- refusal/incomplete-response handling.

Model selection:

1. `OPENAI_COMM_MODEL`
2. `OPENAI_MODEL`
3. fallback `gpt-5.6-terra`

Without an API key, the deterministic local provider exercises the exact same output contract for development/tests. It is clearly labelled local-demo and must not be represented as live model generation.

## Persistence and reproducibility

New relational tables:

### `communication_assets`

Stores tenant, research object, audience, asset type, status and creator.

### `communication_asset_versions`

Every generation/edit/revision is immutable history with:

- version number;
- structured content JSON;
- body markdown;
- generation mode/provider/model;
- prompt version;
- context fingerprint;
- Step-1 source fingerprint;
- revision instruction;
- author and timestamp.

A human edit therefore does not overwrite the AI draft. It creates a new version.

## Product behavior

Communication Studio now supports:

1. select research;
2. choose audience;
3. choose valid format;
4. generate a real server-side communication draft;
5. edit and save as a new version;
6. ask AI to revise with a natural-language instruction;
7. inspect generation provenance and claim ledger;
8. send claim ledger to the Step-5 handoff screen;
9. submit the asset into the institutional approval workflow.

The institutional Communication page now reads persisted assets rather than generating a fake queue from research records.

## Authorization

- Researcher: can generate/edit/revise/submit only for research visible under frozen Step-2 researcher scope.
- Research office / communications reviewer / institution admin: can operate on assets within the active institution.
- Leadership viewer: read-only; generation/edit/submission blocked.
- Cross-tenant asset access returns not found.

## Approval integration

Submitting an asset updates both:

- asset-level status; and
- the frozen Step-2 research workflow state.

Researchers cannot mark an asset institutionally approved. Institutional reviewer/admin roles can approve or request revision.

## Production migration

`supabase/003_step4_communication.sql` adds versioned communication tables with RLS-compatible read policies. Production writes should occur through a trusted server/Edge Function that resolves `auth.uid()`, active institution and membership server-side. The OpenAI API key must never be exposed in browser code.

## Validation completed

Automated suite: **32 / 32 passing**.

Step-4-specific validation includes:

- audience/format contract;
- claim ledger required;
- generation blocked without Research Intelligence;
- generation persistence;
- immutable version increments;
- manual edit versioning;
- AI revision versioning;
- researcher submission;
- institutional approval permission;
- researcher self-approval blocked;
- tenant isolation;
- OpenAI Responses API request shape;
- `store:false`;
- strict JSON-schema mode.

Manual HTTP E2E validation also passed:

`PDF upload → Step 1 analysis → Industry brief generation → AI revision → researcher submission`.

## Explicitly deferred to Step 5

- independent sentence/claim extraction from final draft;
- retrieval of exact supporting passages from PDF/full text;
- Supported / Supported-with-context / Speculative / Unsupported adjudication;
- contradiction detection;
- numeric/effect-size verification;
- fidelity score/decision policy;
- blocking approval when fidelity fails.

This boundary is intentional so Step 4 remains the generation layer and Step 5 remains the independent verification layer.
