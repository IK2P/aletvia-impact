# Aletvia Impact — Staging Deployment

## Recommended first staging target
Railway, with a persistent volume mounted at `/data`.

## Required environment variables

```text
NODE_ENV=production
HOST=0.0.0.0
ALETVIA_DB_PATH=/data/aletvia.sqlite
```

`PORT` is supplied by Railway automatically.

For the first staging deployment, leave AI provider variables unset. The application then runs its deterministic local-demo providers, which is appropriate for infrastructure smoke testing but not university scientific evaluation.

## Optional production-provider variables after infrastructure smoke test

```text
OPENAI_API_KEY=<server-side secret>
ALETVIA_ENGINE_MODE=openai
ALETVIA_COMM_MODE=openai
ALETVIA_FIDELITY_MODE=openai
OPENAI_MODEL=<validated production model>
OPENAI_COMM_MODEL=<validated production model>
OPENAI_FIDELITY_MODEL=<validated production model>
```

Do not expose API keys to browser code.

## Persistent volume
Mount a Railway volume at `/data`. Without a persistent volume, the SQLite database may be lost when a container is replaced.

## Staging smoke test
1. `GET /api/health` returns HTTP 200 and `ok: true`.
2. Open `/` and confirm the Aletvia Impact login page loads.
3. Log in with a seeded demo account.
4. Verify tenant-scoped dashboard data.
5. Import the bundled/sample PDF flow.
6. Generate an RCC content pack.
7. Run fidelity.
8. Complete governance through Ready for Activation.
9. Restart/redeploy the service and confirm persisted state remains.

## Production migration
The repository includes Supabase/PostgreSQL migrations under `supabase/`. Move from SQLite to managed PostgreSQL/RLS before accepting real institutional data at scale. The initial Railway/SQLite deployment is a controlled staging environment, not the final production architecture.
