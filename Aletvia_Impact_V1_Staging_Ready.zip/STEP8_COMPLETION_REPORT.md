# Step 8 Completion Report — University Design-Partner Readiness

## Outcome
Aletvia is now prepared for controlled university design-partner outreach. No external outreach has been sent.

## Prepared assets
- Five-account target matrix with current public contact routes
- 90-day founding design-partner program
- ₹2.5 lakh + GST pilot commercial structure
- One-page pilot proposition
- Five personalized initial outreach emails
- Three-touch follow-up sequence
- Onboarding runbook
- Quantitative pilot scorecard
- CRM-style outreach tracker
- Explicit founder approval gate before sending

## Recommended first-wave order
1. MAHE
2. VIT
3. BITS Pilani
4. Amrita Vishwa Vidyapeetham
5. SRMIST

The order is operational, not a judgment of institutional quality. MAHE goes first because Aletvia has already been tested conceptually against MAHE's public research portfolio and MAHE exposes a clear Directorate of Research plus research-management/PURE infrastructure. VIT follows because Academic Research explicitly emphasizes research integrity and has a direct Dean/Associate Dean route. BITS offers a strong research-and-industry ecosystem. Amrita is useful for multi-campus research/communications governance. SRMIST offers portfolio scale and an engineering + health-science validation environment.

## Outreach discipline
- First email: short, no pricing, no large deck
- Goal: obtain a 20-minute demonstration call
- Day 4: concise follow-up
- Day 10: scientific-governance differentiator + offer one-pager
- Day 18: close-the-loop email
- Stop after four touches unless there is engagement

## Demo agenda (20 minutes)
1. 2 min — institutional problem
2. 3 min — ingest a research paper
3. 4 min — Research Intelligence + opportunity profile
4. 5 min — RCC Studio: summary + graphical/WhatsApp/video package
5. 3 min — Scientific Fidelity Engine
6. 2 min — institutional approval/governance
7. 1 min — 90-day design-partner pilot

## Qualification questions for the call
- Roughly how many research outputs does the institution produce annually?
- Who currently decides which papers receive active communication support?
- Which team owns research communication: research office, communications, schools, or a combination?
- Is research communication centrally governed or distributed by school/campus?
- What is the largest bottleneck: discovery, researcher time, content creation, scientific review, audience routing, approval, or measurement?
- Are there existing CRIS/PURE/Scopus/WoS/repository systems that would eventually need integration?
- Would the institution be willing to nominate 15–25 researchers for a 90-day design-partner pilot?
- Who besides the current contact would need to approve a pilot?

## Commercial sequencing
Do not lead with annual pricing. After the institution confirms fit:
- Founding pilot: ₹2.5 lakh + GST / 90 days
- 100% credit toward Year 1 if converted within 30 days
- Indicative Year-1 range: ₹10–15 lakh, final scope based on institution size, usage and integrations

## Step-8 acceptance status
Preparation: PASS
Target-account verification: PASS
Pilot definition: PASS
Success framework: PASS
Outreach package: PASS
Onboarding package: PASS
Commercial-validation design: PASS
External outreach sent: NO — founder approval required

Step 8 is ready to freeze only after the founder is satisfied with the package. The first external send is a separate explicit action.
