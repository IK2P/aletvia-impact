# Aletvia Brand Architecture

## Master brand
**Aletvia** is the scholarly infrastructure master brand.

## Product family
- **Aletvia Publish** — publication discovery, journal/publisher matching, routing and publishing infrastructure.
- **Aletvia Impact** — post-publication research intelligence, communication, scientific fidelity, institutional governance, activation and impact measurement.

## Aletvia Impact descriptor
**Research Visibility & Impact Infrastructure**

Preferred positioning line: **From published research to measurable impact.**

## Naming rule
Customer-facing product surfaces use descriptive Aletvia product names. Particle names such as **Electron, Proton, Photon** are reserved for future engines, modules or internal technology layers rather than primary products.

## Existing attribution rule
Institutional assets remain institution-first. Aletvia attribution can be visible, subtle or white-label according to the branding specification. Existing `Powered by Aletvia` logic is intentionally preserved.
