@echo off
title Aletvia Impact
cd /d "%~dp0"
echo Starting Aletvia on http://127.0.0.1:8787
echo.
echo Demo password: DemoPass!2026
echo Admin: admin@northstar.edu
echo Researcher: researcher@northstar.edu
echo Communications: communications@northstar.edu
echo.
node server.js
pause
