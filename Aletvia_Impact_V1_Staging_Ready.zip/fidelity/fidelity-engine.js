import { createHash } from 'node:crypto';
import { verifyWithLocalRules } from './local-verifier.js';
import { verifyWithOpenAI } from './openai-provider.js';
import { validateFidelityReport } from './validate.js';
export function fingerprintText(text){return createHash('sha256').update(String(text||'')).digest('hex')}
export async function verifyFidelity(packet,config={}){
 if(!packet?.asset_version_id)throw new Error('Exact communication asset version is required.');if(!packet.asset)throw new Error('Communication asset content is required.');if(!packet.intelligence)throw new Error('Research Intelligence Record is required.');
 const mode=config.mode||process.env.ALETVIA_FIDELITY_MODE||(process.env.OPENAI_API_KEY?'openai':'local-rules');const out=mode==='openai'?await verifyWithOpenAI(packet,config):{report:await verifyWithLocalRules(packet),provider:'local-rules',model:'aletvia-fidelity-rules-v1'};validateFidelityReport(out.report);
 return {schema_version:'1.0',generated_at:new Date().toISOString(),engine:{pipeline_version:'multimodal-fidelity-v1',provider:out.provider,model:out.model,mode},provenance:{asset_id:packet.asset_id,asset_version_id:packet.asset_version_id,asset_version_number:packet.asset_version_number,source_fingerprint_sha256:packet.source_fingerprint_sha256||'',context_fingerprint_sha256:packet.context_fingerprint_sha256||'',verification_packet_sha256:fingerprintText(JSON.stringify({asset:packet.asset,source:packet.source_text,intelligence:packet.intelligence}))},report:out.report};
}
