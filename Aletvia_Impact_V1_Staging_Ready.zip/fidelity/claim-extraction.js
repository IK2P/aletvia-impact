function push(out,location,modality,text){
  const v=String(text||'').replace(/\s+/g,' ').trim();
  if(v.length<8)return;
  out.push({location,modality,claim:v});
}
function sentences(text){
  return String(text||'').split(/(?<=[.!?])\s+|\n+/).map(x=>x.trim()).filter(x=>x.length>=20);
}
export function extractIndependentClaims(asset){
  const out=[];
  push(out,'headline','text',asset?.headline);
  push(out,'dek','text',asset?.dek);
  sentences(asset?.body_markdown).forEach((x,i)=>push(out,`body.${i+1}`,'text',x.replace(/^#+\s*/,'')));
  (asset?.key_messages||[]).forEach((x,i)=>push(out,`key_messages.${i+1}`,'text',x));
  const vs=asset?.visual_spec||{};
  (vs.layout_blocks||[]).forEach((b,i)=>{if(b?.evidence_role!=='decorative')push(out,`visual.layout_blocks.${i+1}`,'visual',`${b.label||''}: ${b.text||''}`)});
  (vs.diagram_semantics||[]).forEach((x,i)=>push(out,`visual.diagram_semantics.${i+1}`,'visual',x));
  const ms=asset?.motion_spec||{};
  sentences(ms.voiceover_script).forEach((x,i)=>push(out,`motion.voiceover.${i+1}`,'motion',x));
  (ms.captions||[]).forEach((x,i)=>push(out,`motion.captions.${i+1}`,'motion',x));
  (ms.storyboard||[]).forEach((s,i)=>{if(s?.evidence_role!=='decorative'){push(out,`motion.storyboard.${i+1}.narration`,'motion',s.narration);push(out,`motion.storyboard.${i+1}.on_screen_text`,'motion',s.on_screen_text)}});
  const ls=asset?.learning_spec||{};
  (ls.cards||[]).forEach((c,i)=>push(out,`learning.cards.${i+1}.back`,'learning',c.back));
  (ls.glossary_items||[]).forEach((x,i)=>push(out,`learning.glossary.${i+1}`,'learning',x));
  const seen=new Set();
  return out.filter(x=>{const k=x.modality+'|'+x.claim.toLowerCase();if(seen.has(k))return false;seen.add(k);return true});
}
