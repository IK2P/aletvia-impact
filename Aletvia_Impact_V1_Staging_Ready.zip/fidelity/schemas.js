export const verdictEnum=['Supported','Supported with context','Speculative','Unsupported'];
export const confidenceEnum=['Low','Medium','High'];
export const riskEnum=['none','qualification','causality','quantitative','clinical','commercial','policy','visual_semantics','source_sufficiency','other'];

export const fidelityClaimSchema={
  type:'object',additionalProperties:false,
  properties:{
    location:{type:'string'},
    modality:{type:'string',enum:['text','visual','motion','learning']},
    claim:{type:'string'},
    verdict:{type:'string',enum:verdictEnum},
    confidence:{type:'string',enum:confidenceEnum},
    rationale:{type:'string'},
    evidence_excerpt:{type:'string'},
    evidence_reference:{type:'string'},
    risk_type:{type:'string',enum:riskEnum},
    suggested_revision:{type:'string'}
  },
  required:['location','modality','claim','verdict','confidence','rationale','evidence_excerpt','evidence_reference','risk_type','suggested_revision']
};

export const fidelityReportSchema={
  type:'object',additionalProperties:false,
  properties:{
    source_sufficiency:{type:'string',enum:['full_text','abstract','intelligence_only','metadata_only']},
    overall_status:{type:'string',enum:['Pass','Pass with cautions','Fail','Insufficient evidence']},
    approval_eligible:{type:'boolean'},
    summary:{type:'string'},
    claims:{type:'array',items:fidelityClaimSchema},
    counts:{
      type:'object',additionalProperties:false,
      properties:{supported:{type:'integer'},supported_with_context:{type:'integer'},speculative:{type:'integer'},unsupported:{type:'integer'}},
      required:['supported','supported_with_context','speculative','unsupported']
    },
    review_notes:{type:'array',items:{type:'string'}}
  },
  required:['source_sufficiency','overall_status','approval_eligible','summary','claims','counts','review_notes']
};
