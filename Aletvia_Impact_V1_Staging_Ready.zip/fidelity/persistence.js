import crypto from 'node:crypto';

export function ensureStep5Schema(db){
 db.exec(`
 CREATE TABLE IF NOT EXISTS fidelity_reports (
   id TEXT PRIMARY KEY,
   institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
   research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
   asset_id TEXT NOT NULL REFERENCES communication_assets(id) ON DELETE CASCADE,
   asset_version_id TEXT NOT NULL REFERENCES communication_asset_versions(id) ON DELETE CASCADE,
   asset_version_number INTEGER NOT NULL,
   source_fingerprint_sha256 TEXT NOT NULL DEFAULT '',
   context_fingerprint_sha256 TEXT NOT NULL DEFAULT '',
   source_evidence_depth TEXT NOT NULL DEFAULT '',
   schema_version TEXT NOT NULL,
   engine_pipeline_version TEXT NOT NULL,
   verifier_provider TEXT NOT NULL,
   verifier_model TEXT NOT NULL,
   overall_status TEXT NOT NULL,
   approval_eligible INTEGER NOT NULL DEFAULT 0,
   report_json TEXT NOT NULL,
   created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
   created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 );
 CREATE TABLE IF NOT EXISTS fidelity_claims (
   id TEXT PRIMARY KEY,
   report_id TEXT NOT NULL REFERENCES fidelity_reports(id) ON DELETE CASCADE,
   ordinal INTEGER NOT NULL,
   location TEXT NOT NULL,
   modality TEXT NOT NULL,
   claim_text TEXT NOT NULL,
   verdict TEXT NOT NULL,
   confidence TEXT NOT NULL,
   rationale TEXT NOT NULL,
   evidence_excerpt TEXT NOT NULL DEFAULT '',
   evidence_reference TEXT NOT NULL DEFAULT '',
   risk_type TEXT NOT NULL,
   suggested_revision TEXT NOT NULL DEFAULT ''
 );
 CREATE INDEX IF NOT EXISTS idx_fidelity_reports_asset ON fidelity_reports(institution_id,asset_id,created_at DESC);
 CREATE INDEX IF NOT EXISTS idx_fidelity_reports_version ON fidelity_reports(asset_version_id,created_at DESC);
 CREATE INDEX IF NOT EXISTS idx_fidelity_claims_report ON fidelity_claims(report_id,ordinal);
 `);
}

export function strongestEvidenceSource(db,institutionId,researchId){
 const rows=db.prepare(`SELECT * FROM ingestion_sources WHERE institution_id=? AND research_output_id=? ORDER BY imported_at DESC`).all(institutionId,researchId);
 const rank=x=>{const d=String(x.evidence_depth||'').toLowerCase();if(d.includes('full'))return 3;if(d.includes('abstract'))return 2;if(String(x.source_text||'').trim())return 1;return 0};
 return rows.sort((a,b)=>rank(b)-rank(a))[0]||null;
}
export function latestIntelligenceRow(db,institutionId,researchId){return db.prepare(`SELECT * FROM research_intelligence_records WHERE institution_id=? AND research_output_id=? ORDER BY created_at DESC LIMIT 1`).get(institutionId,researchId)}
export function buildVerificationPacket(db,session,asset){
 ensureStep5Schema(db);if(!asset?.latest_version)throw new Error('Communication asset has no version to verify.');
 const research=db.prepare(`SELECT r.*,d.name department_name FROM research_outputs r LEFT JOIN departments d ON d.id=r.department_id WHERE r.id=? AND r.institution_id=?`).get(asset.research_output_id,session.active_institution_id);if(!research)throw new Error('Research not found in active tenant.');
 const ir=latestIntelligenceRow(db,session.active_institution_id,research.id);if(!ir)throw new Error('Research Intelligence Record is required for fidelity verification.');const source=strongestEvidenceSource(db,session.active_institution_id,research.id);
 return {asset_id:asset.id,asset_version_id:asset.latest_version.id,asset_version_number:asset.latest_version.version_number,asset:asset.latest_version.content,research,intelligence:JSON.parse(ir.record_json),source_text:source?.source_text||'',evidence_depth:source?.evidence_depth||research.evidence_depth||'',source_fingerprint_sha256:ir.source_fingerprint_sha256||asset.latest_version.source_fingerprint_sha256||source?.content_sha256||'',context_fingerprint_sha256:asset.latest_version.context_fingerprint_sha256||''};
}
export function persistFidelityReport(db,session,asset,verification){
 ensureStep5Schema(db);const id=`fr_${crypto.randomUUID()}`;const r=verification.report;const packet=buildVerificationPacket(db,session,asset);
 db.prepare(`INSERT INTO fidelity_reports(id,institution_id,research_output_id,asset_id,asset_version_id,asset_version_number,source_fingerprint_sha256,context_fingerprint_sha256,source_evidence_depth,schema_version,engine_pipeline_version,verifier_provider,verifier_model,overall_status,approval_eligible,report_json,created_by_user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id,session.active_institution_id,asset.research_output_id,asset.id,packet.asset_version_id,packet.asset_version_number,verification.provenance.source_fingerprint_sha256||'',verification.provenance.context_fingerprint_sha256||'',packet.evidence_depth||'',verification.schema_version,verification.engine.pipeline_version,verification.engine.provider,verification.engine.model,r.overall_status,r.approval_eligible?1:0,JSON.stringify(verification),session.user_id);
 const ins=db.prepare(`INSERT INTO fidelity_claims(id,report_id,ordinal,location,modality,claim_text,verdict,confidence,rationale,evidence_excerpt,evidence_reference,risk_type,suggested_revision) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);r.claims.forEach((c,i)=>ins.run(`fc_${crypto.randomUUID()}`,id,i+1,c.location,c.modality,c.claim,c.verdict,c.confidence,c.rationale,c.evidence_excerpt,c.evidence_reference,c.risk_type,c.suggested_revision));return getFidelityReport(db,session,id);
}
function reportRow(db,session,id){return db.prepare(`SELECT f.* FROM fidelity_reports f WHERE f.id=? AND f.institution_id=?`).get(id,session.active_institution_id)}
export function getFidelityReport(db,session,id){
 const row=reportRow(db,session,id);if(!row)return null;const claims=db.prepare(`SELECT location,modality,claim_text claim,verdict,confidence,rationale,evidence_excerpt,evidence_reference,risk_type,suggested_revision FROM fidelity_claims WHERE report_id=? ORDER BY ordinal`).all(id);let verification={};try{verification=JSON.parse(row.report_json)}catch{}
 const current=currentFidelityState(db,session,row.asset_id,row);return {...row,approval_eligible:!!row.approval_eligible,claims,verification,is_stale:current.is_stale,stale_reasons:current.stale_reasons,is_current:!current.is_stale};
}
export function listFidelityReports(db,session,{asset_id}={}){let sql=`SELECT id FROM fidelity_reports WHERE institution_id=?`,args=[session.active_institution_id];if(asset_id){sql+=' AND asset_id=?';args.push(asset_id)}sql+=' ORDER BY created_at DESC';return db.prepare(sql).all(...args).map(x=>getFidelityReport(db,session,x.id))}
export function latestFidelityReport(db,session,assetId){const x=db.prepare(`SELECT id FROM fidelity_reports WHERE institution_id=? AND asset_id=? ORDER BY created_at DESC LIMIT 1`).get(session.active_institution_id,assetId);return x?getFidelityReport(db,session,x.id):null}
export function currentFidelityState(db,session,assetId,knownRow=null){
 const asset=db.prepare(`SELECT a.*,v.id version_id,v.version_number,v.source_fingerprint_sha256,v.context_fingerprint_sha256 FROM communication_assets a LEFT JOIN communication_asset_versions v ON v.id=(SELECT id FROM communication_asset_versions WHERE asset_id=a.id ORDER BY version_number DESC LIMIT 1) WHERE a.id=? AND a.institution_id=?`).get(assetId,session.active_institution_id);if(!asset)return {exists:false,is_stale:true,stale_reasons:['Asset not found']};const row=knownRow||db.prepare(`SELECT * FROM fidelity_reports WHERE institution_id=? AND asset_id=? ORDER BY created_at DESC LIMIT 1`).get(session.active_institution_id,assetId);if(!row)return {exists:true,has_report:false,is_stale:true,stale_reasons:['No fidelity report exists for the current asset.']};const reasons=[];if(row.asset_version_id!==asset.version_id)reasons.push('Communication asset has a newer version than the fidelity report.');if((row.source_fingerprint_sha256||'')!==(asset.source_fingerprint_sha256||''))reasons.push('Source fingerprint differs from the asset version verified.');if((row.context_fingerprint_sha256||'')!==(asset.context_fingerprint_sha256||''))reasons.push('Generation context fingerprint differs from the verified version.');return {exists:true,has_report:true,report_id:row.id,is_stale:reasons.length>0,stale_reasons:reasons,approval_eligible:!!row.approval_eligible&&!reasons.length,overall_status:row.overall_status,asset_version_number:asset.version_number,verified_version_number:row.asset_version_number};
}
export function approvalGate(db,session,assetId){const state=currentFidelityState(db,session,assetId);if(!state.has_report)return {ok:false,reason:'A current Step-5 fidelity report is required before final approval.',state};if(state.is_stale)return {ok:false,reason:'The fidelity report is stale because the asset changed after verification. Re-run Step 5.',state};if(!state.approval_eligible)return {ok:false,reason:'The current fidelity report contains unresolved scientific-fidelity issues.',state};return {ok:true,state}}
