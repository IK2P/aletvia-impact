import { extractIndependentClaims } from './claim-extraction.js';

const stop=new Set('the a an and or to of in on for with by from at as is are was were be been being this that these those it its their our your we they can could may might will would should study research researchers result results paper work using used use showed found report reported under within into than compared'.split(/\s+/));
const strongCausal=/\b(causes?|caused|leads? to|prevents?|cures?|eliminates?|proves?|guarantees?|results? in)\b/i;
const strongCommercial=/\b(commercially ready|market ready|ready for deployment|ready to deploy|scalable solution|will transform|will revolutionize|solves? .*pollution|works? in municipal|proven solution)\b/i;
const clinical=/\b(treats?|treatment works|improves? patients?|clinical efficacy|safe and effective|diagnoses?|prevents? disease|cures?)\b/i;
const policy=/\b(policy makers should|governments? should|must regulate|should mandate|proves? .*policy)\b/i;
function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9.%+-]+/g,' ').replace(/\s+/g,' ').trim()}
function tokens(s){return new Set(norm(s).split(' ').filter(x=>x.length>2&&!stop.has(x)))}
function overlap(a,b){const A=tokens(a),B=tokens(b);if(!A.size||!B.size)return 0;let n=0;for(const x of A)if(B.has(x))n++;return n/Math.min(A.size,B.size)}
function nums(s){return [...String(s||'').matchAll(/(?<![A-Za-z])[-+]?\d+(?:\.\d+)?%?/g)].map(m=>m[0])}
function sourceLevel(packet){const d=String(packet.evidence_depth||'').toLowerCase().replace(/\s+/g,'_');if(d.includes('full'))return 'full_text';if(d.includes('abstract'))return 'abstract';if((packet.source_text||'').trim())return 'abstract';if(packet.intelligence)return 'intelligence_only';return 'metadata_only'}
function evidenceStatements(packet){
 const e=packet.intelligence?.extraction||{};const arr=[];
 for(const f of e.findings||[])arr.push({ref:'intelligence.findings',text:f.claim});
 for(const l of e.limitations||[])arr.push({ref:'intelligence.limitations',text:l});
 for(const k of ['scientific','practical','societal'])if(e.significance?.[k])arr.push({ref:`intelligence.significance.${k}`,text:e.significance[k]});
 if(e.scientific_core?.methods_summary)arr.push({ref:'intelligence.methods',text:e.scientific_core.methods_summary});
 if(e.scientific_core?.objective)arr.push({ref:'intelligence.objective',text:e.scientific_core.objective});
 for(const c of e.claims_to_avoid||[])arr.push({ref:'intelligence.claims_to_avoid',text:c,avoid:true});
 for(const c of packet.intelligence?.extraction?.claims_to_avoid||[])arr.push({ref:'intelligence.claims_to_avoid',text:c,avoid:true});
 if(packet.research?.title)arr.push({ref:'research.title',text:packet.research.title});
 return arr;
}
function bestEvidence(claim,packet){
 const source=String(packet.source_text||'');let best={score:0,ref:'',text:''};
 for(const s of source.split(/(?<=[.!?])\s+|\n+/).filter(x=>x.trim().length>20)){const score=overlap(claim,s);if(score>best.score)best={score,ref:'source_text',text:s.trim()}}
 for(const s of evidenceStatements(packet).filter(x=>!x.avoid)){const score=overlap(claim,s.text);if(score>best.score)best={score,ref:s.ref,text:s.text}}
 return best;
}
function forbiddenMatch(claim,packet){
 const avoid=[...(packet.intelligence?.extraction?.claims_to_avoid||[]),...(packet.intelligence?.claims_to_avoid||[])];let best=0,text='';for(const a of avoid){const s=overlap(claim,a);if(s>best){best=s;text=a}}return {score:best,text};
}
function maturity(packet){return String(packet.intelligence?.extraction?.evidence_maturity?.level||packet.research?.maturity||'').toLowerCase()}
function classify(item,packet){
 const claim=item.claim;const level=sourceLevel(packet);const ev=bestEvidence(claim,packet);const forb=forbiddenMatch(claim,packet);const n=nums(claim);const evidenceBlob=[packet.source_text,...evidenceStatements(packet).map(x=>x.text)].join(' ');const missingNums=n.filter(x=>!String(evidenceBlob).includes(x));
 const mat=maturity(packet);const weak=/laboratory|cross-sectional|pilot|abstract|preclinical|simulation|prototype/.test(mat);const isCaution=/\b(do not|should not|not established|not evaluated|not validated|remains? unknown|no evidence|cannot conclude|does not establish)\b/i.test(claim);
 let verdict='Speculative',confidence='Medium',rationale='The statement is plausible but is not directly established by the available evidence.',risk_type='other',suggested_revision='Frame this explicitly as a possible implication rather than an established result.';
 if(isCaution&&ev.score>=0.45){verdict='Supported';confidence=level==='full_text'?'High':'Medium';risk_type='none';rationale='The statement accurately preserves a limitation or non-claim from the research evidence.';suggested_revision='No scientific revision required.'}
 else if(missingNums.length){verdict='Unsupported';confidence='High';risk_type='quantitative';rationale=`Numeric detail ${missingNums.join(', ')} was not found in the verification evidence.`;suggested_revision='Remove the unsupported number or cite the exact source result that contains it.'}
 else if(forb.score>=0.38){verdict='Unsupported';confidence='High';risk_type='qualification';rationale='The claim substantially overlaps a frozen Step-1 claim-to-avoid / overstatement boundary.';suggested_revision='Rewrite within the evidence boundary and explicitly preserve the limitation.'}
 else if((strongCommercial.test(claim)||clinical.test(claim)||policy.test(claim)||strongCausal.test(claim))&&weak){verdict='Unsupported';confidence='High';risk_type=clinical.test(claim)?'clinical':strongCausal.test(claim)?'causality':strongCommercial.test(claim)?'commercial':'policy';rationale='The wording implies a stronger causal, clinical, commercial, or policy conclusion than the study maturity supports.';suggested_revision='Use evidence-stage language such as “may be relevant,” “was associated with,” or “under the reported study conditions.”'}
 else if(ev.score>=0.62){verdict='Supported';confidence=level==='full_text'?'High':'Medium';risk_type='none';rationale='The claim closely matches the available research evidence.';suggested_revision='No scientific revision required.'}
 else if(ev.score>=0.34){verdict='Supported with context';confidence=level==='full_text'?'High':'Medium';risk_type='qualification';rationale='The core claim is supported, but important study context or qualification should remain visible.';suggested_revision='Add or retain study conditions, population, comparator, evidence stage, or limitation.'}
 else if(ev.score>=0.18){verdict='Speculative';confidence='Medium';risk_type='other';rationale='The claim extends beyond the directly matched result and should be presented as an inference.';suggested_revision='Label the statement as potential relevance or a hypothesis, not as a demonstrated outcome.'}
 if(level==='metadata_only'){confidence='Low';if(verdict==='Supported')verdict='Supported with context';rationale+=' Verification is limited because only metadata is available.';risk_type='source_sufficiency'}
 return {...item,verdict,confidence,rationale,evidence_excerpt:ev.text.slice(0,500),evidence_reference:ev.ref||'No direct evidence located',risk_type,suggested_revision};
}
export async function verifyWithLocalRules(packet){
 const claims=extractIndependentClaims(packet.asset).map(x=>classify(x,packet));
 const count=v=>claims.filter(x=>x.verdict===v).length;
 const counts={supported:count('Supported'),supported_with_context:count('Supported with context'),speculative:count('Speculative'),unsupported:count('Unsupported')};
 const suff=sourceLevel(packet);const sensitive=!!packet.intelligence?.extraction?.sensitive_research?.is_sensitive;
 let overall='Pass';if(suff==='metadata_only')overall='Insufficient evidence';else if(counts.unsupported>0)overall='Fail';else if(counts.speculative>0||counts.supported_with_context>0)overall='Pass with cautions';
 const eligible=suff!=='metadata_only'&&counts.unsupported===0&&(!sensitive||counts.speculative===0);
 const notes=[];if(suff!=='full_text')notes.push(`Verification used ${suff.replaceAll('_',' ')} evidence; full text would strengthen fidelity assurance.`);if(sensitive)notes.push('Sensitive research: speculative claims block approval until resolved.');if(counts.unsupported)notes.push('Unsupported claims must be revised before final institutional approval.');
 return {source_sufficiency:suff,overall_status:overall,approval_eligible:eligible,summary:`Verified ${claims.length} independently extracted claims across ${[...new Set(claims.map(x=>x.modality))].join(', ')||'no'} modalities.`,claims,counts,review_notes:notes};
}
