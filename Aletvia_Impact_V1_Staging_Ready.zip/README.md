# Aletvia Impact — Integrated V1

**Aletvia Impact** is Aletvia's institutional **Research Visibility & Impact Infrastructure**.

> From published research to measurable impact.

This canonical package combines the previously frozen executable Steps 1–6, the Step-7 real-paper validation evidence, the Step-8 university design-partner package, and the polished ten-route integrated UI.

## Product flow

```text
DOI / PDF / ORCID
        ↓
Canonical Research Object
        ↓
Research Intelligence
        ↓
Opportunity Assessment
        ↓
Research, Communication & Content Studio
        ↓
Research Content Packs
        ↓
Independent Multimodal Scientific Fidelity
        ↓
Researcher Sign-off
        ↓
Institutional Governance / IP / Embargo
        ↓
Ready for Activation
        ↓
Impact Dashboard / downstream measurement layer
```

## Run locally
Requires Node.js 22+.

```bash
npm start
```

Open `http://127.0.0.1:8787`.

Demo password: `DemoPass!2026`

Useful demo identities:
- Institution Admin — `admin@northstar.edu`
- Researcher — `researcher@northstar.edu`
- Communications Reviewer — `communications@northstar.edu`
- Meridian Admin — `admin@meridian.edu`

## Test

```bash
npm test
npm run e2e
```

Expected frozen regression result: **53/53 passing**.

## Recommended integrated demo
1. Import Research → bundled sample PDF.
2. Review Research Intelligence in RCC Studio.
3. Generate Public Impact Pack.
4. Select a content asset.
5. Run Scientific Fidelity.
6. Researcher signs off the exact current version.
7. Institutional reviewer completes governance.
8. Reach Ready for Activation.
9. Review live dashboard metrics.

## Important product boundaries
- Ready for Activation is not automatic external publishing.
- Editing an asset makes prior version-bound fidelity/approvals stale.
- Visual and motion outputs are scientifically governed production specifications; final pixel/MP4 rendering remains a downstream connector.
- Local deterministic AI providers exist for reproducible development and are not represented as production-quality scientific reasoning.

## Key documentation
- `BRAND_ARCHITECTURE.md`
- `PRODUCT_STATUS.md`
- `NEXT_STEPS.md`
- `ARCHITECTURE.md`
- `STEP1_RESEARCH_INTELLIGENCE_ENGINE.md`
- `STEP2_AUTH_PERSISTENCE.md`
- `STEP3_RESEARCH_INGESTION.md`
- `STEP4_RCC_STUDIO.md`
- `STEP5_MULTIMODAL_FIDELITY_ENGINE.md`
- `STEP6_APPROVAL_GOVERNANCE_WORKFLOW.md`
- `STEP7_REAL_PAPER_VALIDATION.md`
- `STEP8_DESIGN_PARTNER_PROGRAM.md`
- `STEP8_COMPLETION_REPORT.md`

## Validation and pilot evidence
- `validation/` — real-paper corpora, holdout results and high-risk review.
- `design_partner/` — target accounts, pilot one-pager, outreach drafts, scorecard and onboarding runbook.

## Production direction
The package includes Supabase/PostgreSQL migrations under `supabase/`. See `NEXT_STEPS.md` for the recommended staging/deployment sequence.
