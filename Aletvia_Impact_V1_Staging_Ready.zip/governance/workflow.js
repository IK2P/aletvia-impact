import crypto from 'node:crypto';
import { approvalGate, latestFidelityReport } from '../fidelity/persistence.js';
import { getAsset } from '../communication/persistence.js';

const REVIEW_TYPES=['researcher','research_office','communications','ip'];
const DECISIONS={
  researcher:['approve','withdraw'],
  research_office:['approve','request_changes','decline'],
  communications:['approve','request_changes','decline'],
  ip:['clear','request_changes','block']
};

export function ensureStep6Schema(db){
  db.exec(`
  CREATE TABLE IF NOT EXISTS approval_cases (
    id TEXT PRIMARY KEY,
    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
    asset_id TEXT NOT NULL UNIQUE REFERENCES communication_assets(id) ON DELETE CASCADE,
    workflow_mode TEXT NOT NULL CHECK(workflow_mode IN ('Standard','Enhanced')),
    status TEXT NOT NULL DEFAULT 'Awaiting Researcher',
    assigned_communications_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    assigned_research_office_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    ip_review_required INTEGER NOT NULL DEFAULT 0,
    embargo_until TEXT,
    embargo_released_at TEXT,
    due_at TEXT NOT NULL,
    activation_ready_at TEXT,
    created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS approval_decisions (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES approval_cases(id) ON DELETE CASCADE,
    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    review_type TEXT NOT NULL CHECK(review_type IN ('researcher','research_office','communications','ip')),
    decision TEXT NOT NULL,
    comment TEXT NOT NULL DEFAULT '',
    asset_version_id TEXT NOT NULL REFERENCES communication_asset_versions(id) ON DELETE CASCADE,
    fidelity_report_id TEXT REFERENCES fidelity_reports(id) ON DELETE SET NULL,
    decided_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS approval_comments (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES approval_cases(id) ON DELETE CASCADE,
    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    body TEXT NOT NULL,
    visibility TEXT NOT NULL DEFAULT 'all_participants' CHECK(visibility IN ('all_participants','institution_internal')),
    created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS approval_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id TEXT NOT NULL REFERENCES approval_cases(id) ON DELETE CASCADE,
    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    actor_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    event_type TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_approval_cases_tenant_status ON approval_cases(institution_id,status,updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_approval_decisions_case_type ON approval_decisions(case_id,review_type,created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_approval_comments_case ON approval_comments(case_id,created_at);
  CREATE INDEX IF NOT EXISTS idx_approval_events_case ON approval_events(case_id,id);
  `);
}

function addDaysIso(days){const d=new Date(Date.now()+days*86400000);return d.toISOString()}
function event(db,session,caseId,eventType,metadata={}){db.prepare(`INSERT INTO approval_events(case_id,institution_id,actor_user_id,event_type,metadata_json) VALUES(?,?,?,?,?)`).run(caseId,session.active_institution_id,session.user_id,eventType,JSON.stringify(metadata))}
function currentVersion(db,assetId){return db.prepare(`SELECT * FROM communication_asset_versions WHERE asset_id=? ORDER BY version_number DESC LIMIT 1`).get(assetId)}
function rawCase(db,institutionId,id){return db.prepare(`SELECT c.*,r.title research_title,r.owner_user_id,r.sensitive research_sensitive,a.asset_type,a.asset_family,a.audience,a.status asset_status FROM approval_cases c JOIN research_outputs r ON r.id=c.research_output_id JOIN communication_assets a ON a.id=c.asset_id WHERE c.id=? AND c.institution_id=?`).get(id,institutionId)}
function caseForAsset(db,institutionId,assetId){return db.prepare(`SELECT id FROM approval_cases WHERE institution_id=? AND asset_id=?`).get(institutionId,assetId)}
function latestDecision(db,caseId,type){return db.prepare(`SELECT d.*,u.display_name decided_by_name FROM approval_decisions d JOIN users u ON u.id=d.decided_by_user_id WHERE d.case_id=? AND d.review_type=? ORDER BY d.created_at DESC,d.rowid DESC LIMIT 1`).get(caseId,type)}
function currentDecision(db,caseId,type,versionId){const d=latestDecision(db,caseId,type);return d&&d.asset_version_id===versionId?d:null}
function assignee(db,institutionId,role,fallbackRole=null){let row=db.prepare(`SELECT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.institution_id=? AND m.active=1 AND m.role=? ORDER BY m.id LIMIT 1`).get(institutionId,role);if(!row&&fallbackRole)row=db.prepare(`SELECT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.institution_id=? AND m.active=1 AND m.role=? ORDER BY m.id LIMIT 1`).get(institutionId,fallbackRole);return row||null}
function membershipRole(db,userId,institutionId){return db.prepare(`SELECT role FROM memberships WHERE user_id=? AND institution_id=? AND active=1`).get(userId,institutionId)?.role||null}

export function ensureApprovalCase(db,session,assetId,{workflow_mode,ip_review_required=false,embargo_until=null}={}){
  ensureStep6Schema(db);
  const asset=getAsset(db,session.active_institution_id,assetId);if(!asset)throw new Error('Communication asset not found in active tenant.');
  if(session.membership.role==='researcher'&&asset.owner_user_id!==session.user_id)throw new Error('Researcher can only govern their own research assets.');
  const existing=caseForAsset(db,session.active_institution_id,assetId);if(existing)return getApprovalCase(db,session,existing.id);
  const mode=asset.research_sensitive?'Enhanced':(workflow_mode==='Enhanced'?'Enhanced':'Standard');
  const comm=assignee(db,session.active_institution_id,'communications_reviewer','institution_admin');
  const researchOffice=assignee(db,session.active_institution_id,'research_office_reviewer','institution_admin');
  const id=`ac_${crypto.randomUUID()}`;
  db.prepare(`INSERT INTO approval_cases(id,institution_id,research_output_id,asset_id,workflow_mode,status,assigned_communications_user_id,assigned_research_office_user_id,ip_review_required,embargo_until,due_at,created_by_user_id) VALUES(?,?,?,?,?,'Awaiting Researcher',?,?,?,?,?,?)`).run(id,session.active_institution_id,asset.research_output_id,asset.id,mode,comm?.id||null,researchOffice?.id||null,ip_review_required?1:0,embargo_until||null,addDaysIso(mode==='Enhanced'?5:3),session.user_id);
  event(db,session,id,'case.created',{workflow_mode:mode,sensitive:asset.research_sensitive,ip_review_required:!!ip_review_required,embargo_until:embargo_until||null});
  return recomputeApprovalCase(db,session,id);
}

function decisionSummary(db,c,versionId){
  const out={};for(const type of REVIEW_TYPES){const latest=latestDecision(db,c.id,type);out[type]={latest:latest||null,current:latest&&latest.asset_version_id===versionId?latest:null,is_stale:!!latest&&latest.asset_version_id!==versionId};}return out;
}
function isFutureIso(x){if(!x)return false;const t=Date.parse(x);return Number.isFinite(t)&&t>Date.now()}

export function readinessState(db,session,caseId){
  const c=rawCase(db,session.active_institution_id,caseId);if(!c)return null;const v=currentVersion(db,c.asset_id);if(!v)return {...c,ready:false,status:'Blocked',blockers:['Asset has no version']};
  const decisions=decisionSummary(db,c,v.id);const blockers=[];const cautions=[];
  if(!decisions.researcher.current||decisions.researcher.current.decision!=='approve')blockers.push('Current asset version requires researcher sign-off.');
  const fidelity=approvalGate(db,session,c.asset_id);if(!fidelity.ok)blockers.push(fidelity.reason);
  if(c.workflow_mode==='Enhanced'&&(!decisions.research_office.current||decisions.research_office.current.decision!=='approve'))blockers.push('Enhanced review requires Research Office approval for the current version.');
  if(c.ip_review_required&&(!decisions.ip.current||decisions.ip.current.decision!=='clear'))blockers.push('IP review must be cleared for the current version.');
  if(!decisions.communications.current||decisions.communications.current.decision!=='approve')blockers.push('Communications approval is required for the current version.');
  for(const type of REVIEW_TYPES){const d=decisions[type].current;if(d&&['request_changes','decline','block','withdraw'].includes(d.decision))blockers.push(`${type.replace('_',' ')} decision: ${d.decision}.`)}
  const embargoActive=!c.embargo_released_at&&isFutureIso(c.embargo_until);if(embargoActive)cautions.push(`Embargo active until ${c.embargo_until}.`);
  const overdue=Date.parse(c.due_at)<Date.now()&&!['Ready for Activation','Declined','Withdrawn'].includes(c.status);
  const stale_reviews=Object.entries(decisions).filter(([,v])=>v.is_stale).map(([k])=>k);
  return {...c,asset_version:{id:v.id,version_number:v.version_number},decisions,fidelity:fidelity.state,blockers,cautions,embargo_active:embargoActive,overdue,stale_reviews,ready:blockers.length===0&&!embargoActive};
}

export function recomputeApprovalCase(db,session,caseId){
  const s=readinessState(db,session,caseId);if(!s)throw new Error('Approval case not found in active tenant.');
  let status='Institutional Review';
  const current=s.decisions;
  if(current.researcher.current?.decision==='withdraw')status='Withdrawn';
  else if(['decline','block'].includes(current.ip.current?.decision)||current.research_office.current?.decision==='decline'||current.communications.current?.decision==='decline')status='Declined';
  else if([current.researcher.current,current.research_office.current,current.communications.current,current.ip.current].some(d=>d?.decision==='request_changes'))status='Revision Requested';
  else if(!current.researcher.current||current.researcher.current.decision!=='approve')status='Awaiting Researcher';
  else if(!s.fidelity?.has_report||s.fidelity?.is_stale||!s.fidelity?.approval_eligible)status='Fidelity Review Required';
  else if(s.workflow_mode==='Enhanced'&&(!current.research_office.current||current.research_office.current.decision!=='approve'))status='Research Office Review';
  else if(s.ip_review_required&&(!current.ip.current||current.ip.current.decision!=='clear') )status=current.ip.current?.decision==='block'?'IP Blocked':'IP Review';
  else if(!current.communications.current||current.communications.current.decision!=='approve')status='Communications Review';
  else if(s.embargo_active)status='Embargoed';
  else status='Ready for Activation';
  const ready=status==='Ready for Activation';
  db.prepare(`UPDATE approval_cases SET status=?,activation_ready_at=CASE WHEN ? THEN COALESCE(activation_ready_at,CURRENT_TIMESTAMP) ELSE NULL END,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(status,ready?1:0,caseId);
  const assetStatus=ready||status==='Embargoed'?'Approved':status==='Revision Requested'?'Revision Requested':status==='Declined'?'Declined':status==='Awaiting Researcher'?'Draft':status==='Fidelity Review Required'?'Researcher Approved':'Institutional Review';
  db.prepare(`UPDATE communication_assets SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(assetStatus,s.asset_id);
  const researchStatus=ready?'Ready for Activation':status;
  db.prepare(`UPDATE research_outputs SET workflow_state=? WHERE id=? AND institution_id=?`).run(researchStatus,s.research_output_id,session.active_institution_id);
  return serializeApprovalCase(db,session,rawCase(db,session.active_institution_id,caseId));
}

function serializeDecision(d){if(!d)return null;return {id:d.id,review_type:d.review_type,decision:d.decision,comment:d.comment,asset_version_id:d.asset_version_id,fidelity_report_id:d.fidelity_report_id,decided_by_user_id:d.decided_by_user_id,decided_by_name:d.decided_by_name,created_at:d.created_at}}
export function serializeApprovalCase(db,session,c){
  if(!c)return null;const s=readinessState(db,session,c.id);const commName=c.assigned_communications_user_id?db.prepare('SELECT display_name FROM users WHERE id=?').get(c.assigned_communications_user_id)?.display_name:null;const roName=c.assigned_research_office_user_id?db.prepare('SELECT display_name FROM users WHERE id=?').get(c.assigned_research_office_user_id)?.display_name:null;
  return {id:c.id,institution_id:c.institution_id,research_output_id:c.research_output_id,research_title:c.research_title,owner_user_id:c.owner_user_id,research_sensitive:!!c.research_sensitive,asset_id:c.asset_id,asset_type:c.asset_type,asset_family:c.asset_family,audience:c.audience,workflow_mode:c.workflow_mode,status:c.status,assigned_communications_user_id:c.assigned_communications_user_id,assigned_communications_name:commName,assigned_research_office_user_id:c.assigned_research_office_user_id,assigned_research_office_name:roName,ip_review_required:!!c.ip_review_required,embargo_until:c.embargo_until,embargo_released_at:c.embargo_released_at,due_at:c.due_at,activation_ready_at:c.activation_ready_at,created_at:c.created_at,updated_at:c.updated_at,asset_version:s.asset_version,decisions:Object.fromEntries(Object.entries(s.decisions).map(([k,v])=>[k,{latest:serializeDecision(v.latest),current:serializeDecision(v.current),is_stale:v.is_stale}])),fidelity:s.fidelity,blockers:s.blockers,cautions:s.cautions,embargo_active:s.embargo_active,overdue:s.overdue,stale_reviews:s.stale_reviews,ready:s.ready};
}

export function getApprovalCase(db,session,id){const c=rawCase(db,session.active_institution_id,id);if(!c)return null;if(session.membership.role==='researcher'&&c.owner_user_id!==session.user_id)return null;return serializeApprovalCase(db,session,c)}
export function getApprovalCaseByAsset(db,session,assetId){const x=caseForAsset(db,session.active_institution_id,assetId);return x?getApprovalCase(db,session,x.id):null}
export function listApprovalCases(db,session,{status}={}){let sql=`SELECT c.id FROM approval_cases c JOIN research_outputs r ON r.id=c.research_output_id WHERE c.institution_id=?`,args=[session.active_institution_id];if(session.membership.role==='researcher'){sql+=' AND r.owner_user_id=?';args.push(session.user_id)}if(status){sql+=' AND c.status=?';args.push(status)}sql+=' ORDER BY c.updated_at DESC';return db.prepare(sql).all(...args).map(x=>getApprovalCase(db,session,x.id));}

function authorizeReview(db,session,c,type){const role=session.membership.role;if(type==='researcher')return role==='researcher'&&c.owner_user_id===session.user_id;if(type==='communications')return role==='institution_admin'||role==='communications_reviewer'&&(c.assigned_communications_user_id===session.user_id||!c.assigned_communications_user_id);if(type==='research_office'||type==='ip')return role==='institution_admin'||role==='research_office_reviewer'&&(c.assigned_research_office_user_id===session.user_id||!c.assigned_research_office_user_id);return false}
export function recordDecision(db,session,caseId,{review_type,decision,comment=''}){
  if(!REVIEW_TYPES.includes(review_type))throw new Error('Invalid review type.');if(!DECISIONS[review_type].includes(decision))throw new Error('Invalid decision for review type.');const c=rawCase(db,session.active_institution_id,caseId);if(!c)throw new Error('Approval case not found in active tenant.');if(!authorizeReview(db,session,c,review_type))throw new Error('You are not authorized for this review stage.');
  const v=currentVersion(db,c.asset_id);if(!v)throw new Error('Asset has no current version.');const fidelity=latestFidelityReport(db,session,c.asset_id);const id=`ad_${crypto.randomUUID()}`;
  db.prepare(`INSERT INTO approval_decisions(id,case_id,institution_id,review_type,decision,comment,asset_version_id,fidelity_report_id,decided_by_user_id) VALUES(?,?,?,?,?,?,?,?,?)`).run(id,caseId,session.active_institution_id,review_type,decision,comment||'',v.id,fidelity?.id||null,session.user_id);event(db,session,caseId,'decision.recorded',{review_type,decision,asset_version_id:v.id,comment:comment||''});return recomputeApprovalCase(db,session,caseId);
}

export function addApprovalComment(db,session,caseId,{body,visibility='all_participants'}){const c=rawCase(db,session.active_institution_id,caseId);if(!c)throw new Error('Approval case not found in active tenant.');if(session.membership.role==='researcher'&&c.owner_user_id!==session.user_id)throw new Error('Researcher cannot access this approval case.');if(!body||body.trim().length<2)throw new Error('Comment is required.');if(!['all_participants','institution_internal'].includes(visibility))throw new Error('Invalid comment visibility.');if(session.membership.role==='researcher'&&visibility==='institution_internal')throw new Error('Researchers cannot create institution-internal comments.');const id=`cm_${crypto.randomUUID()}`;db.prepare(`INSERT INTO approval_comments(id,case_id,institution_id,body,visibility,created_by_user_id) VALUES(?,?,?,?,?,?)`).run(id,caseId,session.active_institution_id,body.trim(),visibility,session.user_id);event(db,session,caseId,'comment.added',{visibility});return listApprovalComments(db,session,caseId)}
export function listApprovalComments(db,session,caseId){const c=rawCase(db,session.active_institution_id,caseId);if(!c)return [];if(session.membership.role==='researcher'&&c.owner_user_id!==session.user_id)return [];let sql=`SELECT c.*,u.display_name author_name FROM approval_comments c JOIN users u ON u.id=c.created_by_user_id WHERE c.case_id=? AND c.institution_id=?`,args=[caseId,session.active_institution_id];if(session.membership.role==='researcher')sql+=` AND c.visibility='all_participants'`;sql+=' ORDER BY c.created_at';return db.prepare(sql).all(...args)}

export function updateGovernanceOptions(db,session,caseId,{workflow_mode,ip_review_required,embargo_until,release_embargo=false,assigned_communications_user_id,assigned_research_office_user_id}={}){
  const c=rawCase(db,session.active_institution_id,caseId);if(!c)throw new Error('Approval case not found in active tenant.');if(!['institution_admin','research_office_reviewer'].includes(session.membership.role))throw new Error('Only Research Office or Institution Admin may change governance controls.');
  let mode=c.workflow_mode;if(c.research_sensitive)mode='Enhanced';else if(workflow_mode)mode=workflow_mode==='Enhanced'?'Enhanced':'Standard';
  if(assigned_communications_user_id&&membershipRole(db,assigned_communications_user_id,session.active_institution_id)!=='communications_reviewer'&&membershipRole(db,assigned_communications_user_id,session.active_institution_id)!=='institution_admin')throw new Error('Communications assignee must be a communications reviewer or institution admin.');
  if(assigned_research_office_user_id&&!['research_office_reviewer','institution_admin'].includes(membershipRole(db,assigned_research_office_user_id,session.active_institution_id)))throw new Error('Research Office assignee must be a research-office reviewer or institution admin.');
  db.prepare(`UPDATE approval_cases SET workflow_mode=?,ip_review_required=COALESCE(?,ip_review_required),embargo_until=CASE WHEN ? IS NOT NULL THEN ? ELSE embargo_until END,embargo_released_at=CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE embargo_released_at END,assigned_communications_user_id=COALESCE(?,assigned_communications_user_id),assigned_research_office_user_id=COALESCE(?,assigned_research_office_user_id),due_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(mode,ip_review_required===undefined?null:(ip_review_required?1:0),embargo_until===undefined?null:embargo_until,embargo_until||null,release_embargo?1:0,assigned_communications_user_id||null,assigned_research_office_user_id||null,addDaysIso(mode==='Enhanced'?5:3),caseId);
  event(db,session,caseId,'governance.updated',{workflow_mode:mode,ip_review_required,embargo_until,release_embargo,assigned_communications_user_id,assigned_research_office_user_id});return recomputeApprovalCase(db,session,caseId);
}

export function approvalTimeline(db,session,caseId){const c=getApprovalCase(db,session,caseId);if(!c)return null;const events=db.prepare(`SELECT e.*,u.display_name actor_name FROM approval_events e JOIN users u ON u.id=e.actor_user_id WHERE e.case_id=? AND e.institution_id=? ORDER BY e.id`).all(caseId,session.active_institution_id).map(e=>({...e,metadata:JSON.parse(e.metadata_json||'{}')}));return {case:c,comments:listApprovalComments(db,session,caseId),events}}
