-- Aletvia Impact — Step 4 revised production migration
-- Research, Communication & Content Studio (RCC Studio)
-- Text + Visual + Motion + Learning artifacts with content packs and versioned provenance.

create table if not exists public.content_packs (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  pack_name text not null,
  created_by_user_id uuid not null references auth.users(id),
  status text not null default 'Draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.communication_assets (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  created_by_user_id uuid not null references auth.users(id),
  audience text not null check(audience in ('Public','Industry','Policy','Media','Clinical','Academic')),
  asset_family text not null default 'Text' check(asset_family in ('Text','Visual','Motion','Learning')),
  asset_type text not null,
  content_pack_id uuid references public.content_packs(id) on delete set null,
  status text not null default 'Draft' check(status in ('Draft','Researcher Approved','Institutional Review','Approved','Revision Requested','Declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.communication_asset_versions (
  id uuid primary key default gen_random_uuid(),
  asset_id uuid not null references public.communication_assets(id) on delete cascade,
  version_number integer not null,
  content jsonb not null,
  body_markdown text not null,
  generation_mode text not null,
  provider text not null,
  model text not null,
  prompt_version text not null,
  context_fingerprint_sha256 text not null,
  source_fingerprint_sha256 text not null default '',
  revision_instruction text not null default '',
  created_by_user_id uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  unique(asset_id,version_number)
);

create index if not exists communication_assets_tenant_research_idx on public.communication_assets(institution_id,research_output_id);
create index if not exists communication_assets_pack_idx on public.communication_assets(content_pack_id);
create index if not exists communication_versions_asset_idx on public.communication_asset_versions(asset_id,version_number desc);
create index if not exists content_packs_tenant_research_idx on public.content_packs(institution_id,research_output_id);

alter table public.content_packs enable row level security;
alter table public.communication_assets enable row level security;
alter table public.communication_asset_versions enable row level security;

create policy content_pack_select on public.content_packs for select using (
  institution_id=public.current_institution_id()
  and exists (
    select 1 from public.research_outputs r where r.id=research_output_id and r.institution_id=public.current_institution_id()
      and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
  )
);
create policy communication_asset_select on public.communication_assets for select using (
  institution_id=public.current_institution_id()
  and exists (
    select 1 from public.research_outputs r where r.id=research_output_id and r.institution_id=public.current_institution_id()
      and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
  )
);
create policy communication_version_select on public.communication_asset_versions for select using (
  exists (
    select 1 from public.communication_assets a join public.research_outputs r on r.id=a.research_output_id
    where a.id=asset_id and a.institution_id=public.current_institution_id()
      and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
  )
);

-- Generation, revision, rendering handoff and approval writes belong in trusted server/Edge Functions.
-- Institution branding is primary. Aletvia attribution can be visible, subtle or white-label by subscription policy.
-- Original PDFs and final rendered media should live in private object storage.
-- OPENAI_API_KEY and future image/video renderer keys must remain server-side.
