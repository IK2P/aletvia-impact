-- Aletvia Impact — Step 5
-- Multimodal Scientific Fidelity Engine

create table if not exists public.fidelity_reports (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  asset_id uuid not null references public.communication_assets(id) on delete cascade,
  asset_version_id uuid not null references public.communication_asset_versions(id) on delete cascade,
  asset_version_number integer not null,
  source_fingerprint_sha256 text not null default '',
  context_fingerprint_sha256 text not null default '',
  source_evidence_depth text not null default '',
  schema_version text not null,
  engine_pipeline_version text not null,
  verifier_provider text not null,
  verifier_model text not null,
  overall_status text not null check (overall_status in ('Pass','Pass with cautions','Fail','Insufficient evidence')),
  approval_eligible boolean not null default false,
  report_json jsonb not null,
  created_by_user_id uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.fidelity_claims (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references public.fidelity_reports(id) on delete cascade,
  ordinal integer not null,
  location text not null,
  modality text not null check (modality in ('text','visual','motion','learning')),
  claim_text text not null,
  verdict text not null check (verdict in ('Supported','Supported with context','Speculative','Unsupported')),
  confidence text not null check (confidence in ('Low','Medium','High')),
  rationale text not null,
  evidence_excerpt text not null default '',
  evidence_reference text not null default '',
  risk_type text not null,
  suggested_revision text not null default ''
);

create index if not exists fidelity_reports_tenant_asset_idx on public.fidelity_reports(institution_id,asset_id,created_at desc);
create index if not exists fidelity_reports_version_idx on public.fidelity_reports(asset_version_id,created_at desc);
create index if not exists fidelity_claims_report_idx on public.fidelity_claims(report_id,ordinal);

alter table public.fidelity_reports enable row level security;
alter table public.fidelity_claims enable row level security;

create policy fidelity_reports_select_members on public.fidelity_reports
for select using (
  exists (select 1 from public.memberships m where m.user_id=auth.uid() and m.institution_id=fidelity_reports.institution_id and m.active=true)
);
create policy fidelity_reports_insert_members on public.fidelity_reports
for insert with check (
  exists (select 1 from public.memberships m where m.user_id=auth.uid() and m.institution_id=fidelity_reports.institution_id and m.active=true and m.role in ('researcher','institution_admin','research_office_reviewer','communications_reviewer'))
);
create policy fidelity_claims_select_members on public.fidelity_claims
for select using (
  exists (select 1 from public.fidelity_reports f join public.memberships m on m.institution_id=f.institution_id where f.id=fidelity_claims.report_id and m.user_id=auth.uid() and m.active=true)
);
create policy fidelity_claims_insert_members on public.fidelity_claims
for insert with check (
  exists (select 1 from public.fidelity_reports f join public.memberships m on m.institution_id=f.institution_id where f.id=fidelity_claims.report_id and m.user_id=auth.uid() and m.active=true and m.role in ('researcher','institution_admin','research_office_reviewer','communications_reviewer'))
);

-- Final approval should be enforced server-side / through a controlled RPC so that
-- a communication asset can reach Approved only when the newest report matches the
-- newest asset version and approval_eligible=true. Direct client updates to approval
-- status should remain disallowed in production RLS.
