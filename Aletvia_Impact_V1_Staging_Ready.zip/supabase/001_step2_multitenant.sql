-- Aletvia Impact — Step 2 production Supabase/PostgreSQL schema
-- Auth identity comes from auth.users. Application access is membership-scoped.
create extension if not exists pgcrypto;

create table if not exists public.institutions (
  id uuid primary key default gen_random_uuid(), name text not null, short_code text not null unique, created_at timestamptz not null default now()
);
create table if not exists public.organizational_units (
  id uuid primary key default gen_random_uuid(), institution_id uuid not null references public.institutions(id) on delete cascade,
  parent_id uuid references public.organizational_units(id) on delete cascade, name text not null,
  unique(institution_id,name)
);
create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  institution_id uuid not null references public.institutions(id) on delete cascade,
  organizational_unit_id uuid references public.organizational_units(id) on delete set null,
  role text not null check(role in ('researcher','research_office_reviewer','communications_reviewer','institution_admin','leadership_viewer')),
  active boolean not null default true, unique(user_id,institution_id)
);
create table if not exists public.research_outputs (
  id uuid primary key default gen_random_uuid(), institution_id uuid not null references public.institutions(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id), organizational_unit_id uuid references public.organizational_units(id),
  title text not null, authors text not null, journal text, doi text, publication_date date, publication_state text not null default 'Published',
  evidence_depth text not null default 'Abstract', evidence_maturity text not null, communication_priority text not null default 'B',
  workflow_state text not null default 'Draft', sensitive boolean not null default false,
  did_text text not null, found_text text not null, why_text text not null, limitations_text text not null,
  audience_json jsonb not null default '[]'::jsonb, action_text text not null, visibility_text text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.opportunity_assessments (
  id uuid primary key default gen_random_uuid(), research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  dimension text not null, rating text not null, confidence text not null, rationale text not null, unique(research_output_id,dimension)
);
create table if not exists public.audit_events (
  id bigint generated always as identity primary key, institution_id uuid not null references public.institutions(id), user_id uuid not null references auth.users(id),
  action text not null, entity_type text, entity_id text, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

-- Helper functions use the active institution supplied in the JWT app_metadata.
create or replace function public.current_institution_id() returns uuid language sql stable as $$
  select nullif(auth.jwt() -> 'app_metadata' ->> 'active_institution_id','')::uuid
$$;
create or replace function public.current_membership_role() returns text language sql stable security definer set search_path=public as $$
  select role from public.memberships where user_id=auth.uid() and institution_id=public.current_institution_id() and active=true limit 1
$$;

alter table public.institutions enable row level security;
alter table public.organizational_units enable row level security;
alter table public.memberships enable row level security;
alter table public.research_outputs enable row level security;
alter table public.opportunity_assessments enable row level security;
alter table public.audit_events enable row level security;

create policy institutions_member_select on public.institutions for select using (
  exists(select 1 from public.memberships m where m.user_id=auth.uid() and m.institution_id=institutions.id and m.active)
);
create policy units_tenant_select on public.organizational_units for select using (institution_id=public.current_institution_id());
create policy memberships_self_or_admin_select on public.memberships for select using (
  institution_id=public.current_institution_id() and (user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
);
create policy research_tenant_select on public.research_outputs for select using (
  institution_id=public.current_institution_id() and (owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
);
create policy research_reviewer_update on public.research_outputs for update using (
  institution_id=public.current_institution_id() and public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer')
) with check (institution_id=public.current_institution_id());
create policy opportunity_tenant_select on public.opportunity_assessments for select using (
  exists(select 1 from public.research_outputs r where r.id=research_output_id and r.institution_id=public.current_institution_id() and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer')))
);
create policy audit_privileged_select on public.audit_events for select using (
  institution_id=public.current_institution_id() and public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer')
);

-- IMPORTANT: active_institution_id must be changed only after server-side membership verification.
-- Never trust a client-supplied institution id without validating membership.
