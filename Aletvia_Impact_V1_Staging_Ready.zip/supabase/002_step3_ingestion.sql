-- Aletvia Impact — Step 3 production migration
-- Adds canonical ingestion provenance for DOI / PDF / ORCID and preserves frozen Step-1 intelligence records.

alter table public.research_outputs add column if not exists title_key text not null default '';
alter table public.research_outputs add column if not exists ingestion_status text not null default 'ready';
alter table public.research_outputs add column if not exists latest_source_type text;

create unique index if not exists research_doi_per_tenant
  on public.research_outputs(institution_id, lower(doi))
  where doi is not null and btrim(doi)<>'';
create index if not exists research_title_key_per_tenant on public.research_outputs(institution_id,title_key);

create table if not exists public.ingestion_sources (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  source_type text not null check(source_type in ('doi','pdf','orcid')),
  source_identifier text not null,
  source_url text,
  storage_path text, -- original PDFs belong in private Supabase Storage; do not expose public URLs.
  content_sha256 text,
  raw_metadata jsonb not null default '{}'::jsonb,
  extracted_text text not null default '',
  evidence_depth text not null check(evidence_depth in ('metadata','abstract','full_text')),
  imported_by_user_id uuid not null references auth.users(id),
  imported_at timestamptz not null default now(),
  unique(institution_id,source_type,source_identifier)
);

create table if not exists public.research_intelligence_records (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  schema_version text not null,
  engine_pipeline_version text not null,
  source_fingerprint_sha256 text not null,
  record jsonb not null,
  created_at timestamptz not null default now(),
  unique(research_output_id,source_fingerprint_sha256)
);

create table if not exists public.researcher_identifiers (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  identifier_type text not null check(identifier_type in ('orcid')),
  identifier_value text not null,
  authenticated boolean not null default false,
  source text not null default 'manual_import',
  created_at timestamptz not null default now(),
  unique(institution_id,user_id,identifier_type,identifier_value)
);

alter table public.ingestion_sources enable row level security;
alter table public.research_intelligence_records enable row level security;
alter table public.researcher_identifiers enable row level security;

create policy ingestion_source_select on public.ingestion_sources for select using (
  institution_id=public.current_institution_id()
  and exists (
    select 1 from public.research_outputs r
    where r.id=research_output_id and r.institution_id=public.current_institution_id()
      and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
  )
);
create policy intelligence_record_select on public.research_intelligence_records for select using (
  institution_id=public.current_institution_id()
  and exists (
    select 1 from public.research_outputs r
    where r.id=research_output_id and r.institution_id=public.current_institution_id()
      and (r.owner_user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer'))
  )
);
create policy researcher_identifier_self_or_admin_select on public.researcher_identifiers for select using (
  institution_id=public.current_institution_id()
  and (user_id=auth.uid() or public.current_membership_role() in ('institution_admin','research_office_reviewer','communications_reviewer'))
);

-- Production write model:
-- DOI/PDF/ORCID ingestion should run in a trusted Edge Function/server using a service credential.
-- The function must resolve active tenant + membership server-side exactly as Step 2 does.
-- Never expose the service-role key in the browser. Storage objects for PDFs must be private.
