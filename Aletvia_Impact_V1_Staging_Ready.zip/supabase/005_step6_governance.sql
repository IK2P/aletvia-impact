-- Aletvia Impact — Step 6
-- Institutional Approval & Governance Workflow

create table if not exists public.approval_cases (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  research_output_id uuid not null references public.research_outputs(id) on delete cascade,
  asset_id uuid not null unique references public.communication_assets(id) on delete cascade,
  workflow_mode text not null check (workflow_mode in ('Standard','Enhanced')),
  status text not null default 'Awaiting Researcher',
  assigned_communications_user_id uuid references auth.users(id),
  assigned_research_office_user_id uuid references auth.users(id),
  ip_review_required boolean not null default false,
  embargo_until timestamptz,
  embargo_released_at timestamptz,
  due_at timestamptz not null,
  activation_ready_at timestamptz,
  created_by_user_id uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.approval_decisions (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.approval_cases(id) on delete cascade,
  institution_id uuid not null references public.institutions(id) on delete cascade,
  review_type text not null check (review_type in ('researcher','research_office','communications','ip')),
  decision text not null,
  comment text not null default '',
  asset_version_id uuid not null references public.communication_asset_versions(id) on delete cascade,
  fidelity_report_id uuid references public.fidelity_reports(id) on delete set null,
  decided_by_user_id uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.approval_comments (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.approval_cases(id) on delete cascade,
  institution_id uuid not null references public.institutions(id) on delete cascade,
  body text not null,
  visibility text not null default 'all_participants' check (visibility in ('all_participants','institution_internal')),
  created_by_user_id uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.approval_events (
  id bigint generated always as identity primary key,
  case_id uuid not null references public.approval_cases(id) on delete cascade,
  institution_id uuid not null references public.institutions(id) on delete cascade,
  actor_user_id uuid not null references auth.users(id),
  event_type text not null,
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists approval_cases_tenant_status_idx on public.approval_cases(institution_id,status,updated_at desc);
create index if not exists approval_decisions_case_type_idx on public.approval_decisions(case_id,review_type,created_at desc);
create index if not exists approval_comments_case_idx on public.approval_comments(case_id,created_at);
create index if not exists approval_events_case_idx on public.approval_events(case_id,id);

alter table public.approval_cases enable row level security;
alter table public.approval_decisions enable row level security;
alter table public.approval_comments enable row level security;
alter table public.approval_events enable row level security;

-- Institutional members may see cases in their tenant; ordinary researchers are
-- narrowed to research outputs they own.
create policy approval_cases_select_scoped on public.approval_cases
for select using (
  exists (
    select 1 from public.memberships m
    where m.user_id=auth.uid() and m.institution_id=approval_cases.institution_id and m.active=true
      and (
        m.role <> 'researcher'
        or exists (
          select 1 from public.research_outputs r
          where r.id=approval_cases.research_output_id and r.owner_user_id=auth.uid()
        )
      )
  )
);

create policy approval_cases_insert_participants on public.approval_cases
for insert with check (
  exists (
    select 1 from public.memberships m
    where m.user_id=auth.uid() and m.institution_id=approval_cases.institution_id and m.active=true
      and m.role in ('researcher','institution_admin','research_office_reviewer','communications_reviewer')
  )
);

create policy approval_decisions_select_scoped on public.approval_decisions
for select using (
  exists (
    select 1 from public.approval_cases c
    join public.memberships m on m.institution_id=c.institution_id
    where c.id=approval_decisions.case_id and m.user_id=auth.uid() and m.active=true
      and (
        m.role <> 'researcher'
        or exists (select 1 from public.research_outputs r where r.id=c.research_output_id and r.owner_user_id=auth.uid())
      )
  )
);

create policy approval_comments_select_scoped on public.approval_comments
for select using (
  exists (
    select 1 from public.approval_cases c
    join public.memberships m on m.institution_id=c.institution_id
    where c.id=approval_comments.case_id and m.user_id=auth.uid() and m.active=true
      and (
        m.role <> 'researcher'
        or (
          approval_comments.visibility='all_participants'
          and exists (select 1 from public.research_outputs r where r.id=c.research_output_id and r.owner_user_id=auth.uid())
        )
      )
  )
);

create policy approval_events_select_institutional on public.approval_events
for select using (
  exists (
    select 1 from public.memberships m
    where m.user_id=auth.uid() and m.institution_id=approval_events.institution_id and m.active=true
      and m.role in ('institution_admin','research_office_reviewer','communications_reviewer','leadership_viewer')
  )
);

-- IMPORTANT PRODUCTION CONTROL:
-- Do not grant clients direct INSERT/UPDATE permissions for approval_decisions,
-- approval_case status, embargo release, reviewer assignments or activation_ready_at.
-- Route those mutations through audited server/RPC functions that verify:
-- 1) the actor's institutional role and assignment,
-- 2) the decision is bound to the newest asset_version_id,
-- 3) the newest Step-5 fidelity report is current and approval_eligible,
-- 4) Enhanced/IP/embargo requirements are satisfied,
-- 5) sensitive research cannot be downgraded to Standard review.
