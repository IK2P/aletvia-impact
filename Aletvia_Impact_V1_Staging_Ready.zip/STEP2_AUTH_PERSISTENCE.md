# Step 2 — Authentication, Persistence & Multi-Tenancy

Status: **COMPLETE / candidate to freeze**

Step 1 (Research Intelligence Engine) remains frozen and unchanged in its engine contract. Step 2 adds the institutional security and persistence substrate beneath the existing product.

## What Step 2 implements

### 1. Real relational persistence
The local runnable implementation uses SQLite through Node's built-in `node:sqlite` module (no external packages required). The schema contains:
- institutions
- departments
- users
- memberships
- research_outputs
- opportunity_assessments
- sessions
- audit_events

The database is created and seeded automatically on first launch.

### 2. Real authentication
- email/password login
- PBKDF2-SHA256 password hashing with per-user random salts and 210,000 iterations
- opaque random session tokens
- only a SHA-256 hash of the session token is stored server-side
- HttpOnly, SameSite=Strict session cookie
- 8-hour demo session lifetime
- server-side logout invalidation

Production direction: replace local password auth with Supabase Auth / institutional SSO while retaining the same membership and authorization model.

### 3. Institutional multi-tenancy
Every research output is institution-scoped. The active institution is stored in the authenticated server-side session.

A user can switch institution only if an active membership exists for that institution. Client-supplied institution identifiers are never accepted as authorization by themselves.

### 4. Role model
Roles:
- researcher
- research_office_reviewer
- communications_reviewer
- institution_admin
- leadership_viewer

Researchers can read only their own authored/owned research within the active institution. Institutional roles receive tenant-wide visibility according to role. Researchers may submit their own work to `Researcher Approved`, but cannot perform institutional approval.

### 5. Persistent workflow state
Workflow changes are persisted in the relational database rather than `localStorage`.

Supported states:
- Draft
- Researcher Review
- Researcher Approved
- Institutional Review
- Approved
- Revision Requested
- Declined
- Embargoed
- IP Review Required
- Enhanced Review

### 6. Audit trail
Authentication, tenant switches, analysis events and workflow changes are written to `audit_events` with institution and user attribution.

### 7. Production Supabase/PostgreSQL migration
`supabase/001_step2_multitenant.sql` contains the production-target schema and Row Level Security policies.

RLS is enabled on all application-exposed tables. Policies enforce:
- institution membership for institution access
- active-institution isolation
- researcher ownership restrictions
- privileged reviewer/admin access
- reviewer-only workflow updates
- audit-event visibility for privileged roles

The production design assumes `active_institution_id` is set in trusted JWT app metadata only after membership verification.

## Local demo identities
All demo accounts use password: `DemoPass!2026`

- `admin@northstar.edu` — Northstar institution admin
- `researcher@northstar.edu` — Northstar researcher
- `communications@northstar.edu` — Northstar communications reviewer
- `admin@meridian.edu` — Meridian institution admin
- `researcher@meridian.edu` — Meridian researcher
- `multi@aletvia.demo` — leadership viewer in both institutions, used to prove membership-gated tenant switching

These accounts are fictional and exist only in the local seeded database.

## API surface completed in Step 2
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/session`
- `POST /api/session/institution`
- `GET /api/research`
- `GET /api/research/:id`
- `PATCH /api/research/:id/workflow`
- `GET /api/researchers`
- `GET /api/dashboard`
- `GET /api/audit`
- Step 1 preserved: `GET /api/engine-status`, `POST /api/analyze-research`

## Security acceptance tests
Automated integration tests verify:
1. Northstar admin sees Northstar research only.
2. Meridian admin cannot fetch a Northstar research object.
3. Researchers receive only authored research.
4. A researcher cannot fetch another Northstar researcher's record.
5. A researcher may submit their own research for institutional review.
6. A researcher cannot institutionally approve research.
7. An institution admin can update workflow state and the change persists.
8. A multi-institution user may switch only to institutions for which membership exists.
9. Unauthenticated research access returns HTTP 401.
10. All frozen Step 1 engine tests continue to pass.

Current result: **13/13 automated tests pass.**

## Browser-validation note
A headless Chromium smoke test against `localhost` was attempted after the server/API tests. The execution environment blocks browser navigation to localhost with `ERR_BLOCKED_BY_ADMINISTRATOR`. This is an environment policy restriction; it prevented browser automation from reaching the local server. It is not counted as a passed test. The API integration suite tests authentication/session/tenant behavior directly at the HTTP layer.

## How to run locally
No npm installation is required.

```bash
cd Aletvia_RI_OS_Step2
npm start
```

Then open `http://127.0.0.1:8787` in a normal local browser.

To run tests:

```bash
npm test
```

## What is deliberately NOT Step 2
The following remain later steps:
- DOI / PDF / ORCID ingestion (Step 3)
- live AI Communication Studio (Step 4)
- full claim-level Scientific Fidelity Engine (Step 5)
- complete production approval workflow/embargo/IP automation (Step 6)
- 20–50 paper validation study (Step 7)
- university design-partner outreach (Step 8)

## Step 2 freeze criteria
Step 2 can be frozen when the product owner accepts these invariants:
- authentication is server-side, not simulated
- all application data access is tenant-scoped
- researcher access is ownership-scoped
- tenant switching is membership-gated
- workflow state persists server-side
- institutional actions are auditable
- a Supabase/PostgreSQL RLS path exists for production
- Step 1 remains operational and tests remain green
