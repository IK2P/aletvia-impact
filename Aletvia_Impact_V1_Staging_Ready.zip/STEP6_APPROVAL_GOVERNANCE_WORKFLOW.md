# Aletvia Impact — Step 6
## Institutional Approval & Governance Workflow

**Status:** Complete and ready to freeze  
**Frozen predecessors:** Steps 1–5 remain unchanged in their scientific/product contracts.  
**Step-6 outcome:** an RCC asset cannot become **Ready for Activation** until every governance gate applicable to the *current asset version* is satisfied.

---

## 1. Purpose

Step 6 turns approval from a status dropdown into a version-bound institutional governance system. The workflow coordinates the researcher, Step-5 scientific-fidelity verification, Research Office, communications reviewers, IP/disclosure review, embargo controls, comments, assignments and immutable decision history.

The final Step-6 state is **Ready for Activation**. Step 6 does not perform external distribution itself.

---

## 2. Governing invariant

> Approval belongs to an exact content version, not merely to an asset name.

Every decision stores the exact `asset_version_id` it reviewed. If the researcher or AI creates a newer version, prior researcher, Research Office, communications and IP decisions become stale automatically. Step-5 fidelity already behaves the same way.

This prevents a common governance failure: approving V1 and then silently publishing modified V2.

---

## 3. Standard workflow

**Researcher sign-off → current Step-5 fidelity report → Communications approval → Ready for Activation**

Default SLA: **3 days**.

A Standard case is appropriate for ordinary research communication that does not require enhanced institutional scrutiny.

---

## 4. Enhanced workflow

**Researcher sign-off → current Step-5 fidelity report → Research Office approval → Communications approval → Ready for Activation**

Default SLA: **5 days**.

Sensitive research is automatically forced into Enhanced mode. It cannot be downgraded to Standard by a user.

Enhanced review is intended for areas such as sensitive human research, clinical claims, mental health, abuse, vulnerable populations, genetics and other categories detected upstream.

---

## 5. Optional hard gates

### IP / disclosure review
An institution can mark a case `ip_review_required=true`.

The asset cannot become Ready for Activation until the current version receives an IP `clear` decision. IP `block` or `request_changes` prevents readiness.

### Embargo
An institution can set `embargo_until`.

All scientific and institutional approvals can be completed while an embargo remains active, but the case becomes **Embargoed**, not Ready for Activation. Once the date passes or an authorized institutional user explicitly releases the embargo, the case can become Ready for Activation.

---

## 6. Workflow states

The computed Step-6 states are:

- Awaiting Researcher
- Fidelity Review Required
- Research Office Review
- IP Review
- IP Blocked
- Communications Review
- Revision Requested
- Declined
- Withdrawn
- Embargoed
- Ready for Activation

These states are computed from current-version decisions and gates rather than being freely selectable labels.

---

## 7. Approval-case object

Every submitted RCC asset receives one institutional `approval_case` containing:

- institution
- research output
- RCC asset
- workflow mode: Standard / Enhanced
- current computed state
- communications reviewer assignment
- Research Office reviewer assignment
- IP-review requirement
- embargo deadline/release
- due date / overdue signal
- activation-ready timestamp
- full version-bound decision history
- current Step-5 fidelity state
- blockers and cautions

---

## 8. Reviewer assignment

Step 6 automatically assigns:

- the institution's first active `communications_reviewer`, falling back to `institution_admin`
- the institution's first active `research_office_reviewer`, falling back to `institution_admin`

Institution Admin / Research Office can change assignments, subject to membership-role validation.

This is intentionally simple for V1; production can later add round-robin assignment, department-specific queues or reviewer workload balancing without changing the approval-case contract.

---

## 9. Role permissions

### Researcher
Can:
- sign off the current version of their own asset
- withdraw their sign-off
- see their own cases
- add participant-visible comments

Cannot:
- institutionally approve
- perform communications review
- perform Research Office review
- clear IP review
- create institution-internal comments
- see other researchers' cases

### Communications Reviewer
Can:
- review assigned communication assets
- approve / request changes / decline at the communications stage
- see institutional cases
- add participant or institution-internal comments

### Research Office Reviewer
Can:
- complete Enhanced review
- request changes / decline
- control governance mode for non-sensitive cases
- require IP review
- manage embargo controls

### Institution Admin
Can:
- perform institutional governance actions
- act as the fallback reviewer when a specialized reviewer is unavailable
- manage IP / embargo / assignments

### Leadership Viewer
Read-oriented role. Cannot mutate governance decisions.

---

## 10. Decision model

`approval_decisions` are immutable events containing:

- review type: researcher / research_office / communications / ip
- decision
- comment
- exact asset version ID
- current fidelity report ID where available
- deciding user
- timestamp

The engine never overwrites an old decision. A new decision creates a new row.

---

## 11. Staleness after edits

Example:

1. Researcher approves V1.
2. Step 5 verifies V1.
3. Communications approves V1.
4. Case becomes Ready for Activation.
5. Researcher edits the artifact, creating V2.

Step 6 now reports:

- researcher decision: stale
- communications decision: stale
- fidelity report: stale
- case status: Awaiting Researcher

The workflow must run again for V2.

---

## 12. Revision loop

A reviewer can choose `request_changes` and provide a comment.

The case becomes **Revision Requested**. Once the researcher creates a new asset version:

- the change-request decision is tied to the old version
- prior approvals are stale
- the case returns to the appropriate current-version path
- the researcher must sign off again
- Step 5 must verify the new version again
- institutional reviews must be repeated where required

This creates a controlled revision cycle rather than a one-way approval funnel.

---

## 13. Comments and confidentiality

Step 6 supports two comment visibility levels:

### `all_participants`
Visible to the researcher and institutional reviewers.

### `institution_internal`
Visible only to institutional users. Researchers cannot create or read these comments.

This supports internal governance conversations without leaking them into the researcher-facing review thread.

---

## 14. Audit timeline

Every Step-6 case has an append-only event timeline including:

- case creation
- governance changes
- reviewer decisions
- comments
- version-bound metadata

The existing global audit log also records key workflow actions.

---

## 15. Fidelity gate integration

Step 6 calls the frozen Step-5 approval gate.

A case cannot progress to final readiness when:

- no fidelity report exists
- the fidelity report belongs to an older asset version
- source/context fingerprints differ
- the report contains unresolved fidelity issues

Thus institutional approval cannot bypass scientific verification.

---

## 16. Ready for Activation

A Standard case is activation-ready only when:

1. the current asset version has researcher sign-off
2. the current asset version has an eligible, non-stale Step-5 fidelity report
3. communications has approved the same current version
4. any required IP review is cleared for the same current version
5. no active embargo blocks activation
6. no current decision is request-changes, decline, block or withdraw

Enhanced mode adds:

7. Research Office approval of the same current version

When all requirements are met:

- `approval_cases.status = Ready for Activation`
- `approval_cases.activation_ready_at` is recorded
- the RCC asset is marked Approved
- the research output workflow becomes Ready for Activation

---

## 17. API surface

### Capabilities
`GET /api/governance/capabilities`

### Cases
`GET /api/approval-cases`  
`POST /api/approval-cases`  
`GET /api/approval-cases/:id`  
`POST /api/approval-cases/:id/recompute`

### Decisions
`POST /api/approval-cases/:id/decisions`

### Governance controls
`PATCH /api/approval-cases/:id/governance`

### Comments
`GET /api/approval-cases/:id/comments`  
`POST /api/approval-cases/:id/comments`

### Timeline
`GET /api/approval-cases/:id/timeline`

The existing RCC submit/status routes remain as compatibility paths but now create/use Step-6 governance instead of bypassing it.

---

## 18. Data model

New local tables:

- `approval_cases`
- `approval_decisions`
- `approval_comments`
- `approval_events`

Production Supabase/PostgreSQL migration:

`supabase/005_step6_governance.sql`

The production migration enables RLS and scopes researcher access to owned research while institutional reviewers remain institution-scoped.

Critical write operations should run through controlled server/RPC functions rather than direct client table mutation.

---

## 19. UI

The Approvals screen now reads real approval cases from the backend and displays:

- case status
- Standard / Enhanced route
- asset version
- sensitivity
- IP / embargo indicators
- overdue state
- researcher decision
- Research Office decision
- IP decision
- communications decision
- Step-5 fidelity status
- current blockers
- reviewer assignments
- role-appropriate decision buttons
- governance controls
- comments

The UI is therefore driven by computed governance state rather than static demo rows.

---

## 20. Validation

### Automated regression suite
**53 / 53 tests pass.**

This includes the complete frozen Steps 1–5 suite plus Step-6 tests covering:

- capabilities
- Standard workflow
- Enhanced workflow
- sensitive research route
- stale decisions after edits
- revision loop
- IP hard gate
- embargo hard gate / release
- internal-comment visibility
- tenant isolation

### End-to-end Step-6 validation
A real local flow was executed:

PDF upload  
→ Step 1 intelligence  
→ RCC Industry Brief  
→ researcher sign-off  
→ Step-5 fidelity verification  
→ communications approval  
→ IP review required  
→ IP cleared  
→ future embargo active  
→ Embargoed  
→ authorized embargo release  
→ **Ready for Activation**

Final blockers: **0**.

See `STEP6_E2E_RESULTS.txt`.

---

## 21. Deliberately deferred

Step 6 does not yet include:

- email/Slack/Teams approval notifications
- legal counsel as a separate authentication role
- department-specific reviewer routing rules
- advanced SLA escalation notifications
- electronic signatures
- external distribution / publishing itself
- automated external stakeholder outreach

Those are integrations/extensions; they do not require redesigning the core governance model.

---

## 22. Step-6 acceptance criteria

- [x] Standard institutional approval route
- [x] Enhanced route
- [x] Sensitive research forced to Enhanced
- [x] Researcher sign-off bound to exact version
- [x] Step-5 fidelity gate
- [x] Research Office review
- [x] Communications review
- [x] IP gate
- [x] Embargo gate / release
- [x] Reviewer assignments
- [x] Revision loop
- [x] Stale decisions after edits
- [x] Participant/internal comments
- [x] Immutable decision/event history
- [x] Tenant isolation
- [x] Researcher ownership scoping
- [x] SLA / overdue signal
- [x] Ready for Activation final state
- [x] Supabase production migration / RLS
- [x] Dynamic Approvals UI
- [x] 53/53 automated tests
- [x] End-to-end readiness validation

**Step 6 is complete and ready to freeze.**
