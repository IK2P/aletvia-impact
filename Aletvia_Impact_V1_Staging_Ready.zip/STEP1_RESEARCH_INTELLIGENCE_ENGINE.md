# Step 1 — Aletvia Research Intelligence Engine

**Status:** Implemented and tested in Build 0.  
**Scope boundary:** Step 1 only. Database/authentication, DOI/PDF ingestion, AI Communication Studio, production Scientific Fidelity Engine, production approval workflow, and university pilot testing remain later steps.

## 1. Purpose

Step 1 converts research source text into a stable, evidence-grounded **Research Intelligence Record**. It deliberately separates two questions:

1. **Scientific Extraction:** What does the supplied research source actually establish?
2. **Opportunity Assessment:** Given those evidence boundaries, who might care and what activation paths may be appropriate?

The second stage never gets permission to rewrite the science established by the first stage.

## 2. Input contract

The engine currently accepts:

- `title`
- `authors`
- `venue`
- `evidence_depth`: `metadata | abstract | full_text`
- `source_text`

Step 1 accepts text directly. DOI retrieval and PDF extraction are intentionally deferred to Step 3 so ingestion complexity does not contaminate evaluation of the intelligence engine itself.

Minimum source: 80 characters.  
Maximum source: 200,000 characters.  
The engine rejects over-limit text rather than silently truncating scientific evidence.

## 3. Pipeline

```text
Research source text
      ↓
Scientific Extraction Engine
      ↓
Structured Scientific Extraction Record
      ↓
Schema + semantic validation
      ↓
Opportunity Assessment Engine
      ↓
Structured Opportunity Assessment
      ↓
Semantic quality-control rules
      ↓
Final Research Intelligence Record
```

## 4. Scientific Extraction Record

The extraction stage produces:

- source evidence depth and sufficiency
- missing information
- field / subfield / research type
- research question and objective
- study design
- methods summary
- population / experimental system
- sample / dataset
- comparator
- primary outcomes
- finding-level claims
  - direct / inferred / uncertain
  - evidence basis
  - magnitude or direction
  - caveat
- evidence maturity
- limitations
- scientific / practical / societal significance
- sensitive-research classification
- claims that communications should avoid
- uncertainty summary

### Evidence maturity vocabulary

- Foundational
- Simulation
- Laboratory
- Animal / preclinical
- Observational human study
- Controlled human study
- Prototype
- Field validated
- Systematic review / meta-analysis
- Protocol / expert consensus
- Other

## 5. Opportunity Assessment Record

The opportunity stage assesses eight **independent** dimensions. These are communication/activation opportunities, not scientific-quality ratings.

- Industry
- Policy
- Media
- Public
- Clinical
- Academic collaboration
- Funding
- Commercialization

Every dimension contains:

- `level`: Very Low → Very High
- `confidence`: Low / Medium / High
- `rationale`
- `basis`:
  - `paper_supported`
  - `aletvia_inferred`
  - `mixed`

The engine also produces:

- stakeholder categories
- primary vs secondary audience priority
- recommended actions
- prerequisites before action
- communication priority: A / B / C / No active recommendation
- opportunity uncertainty

## 6. Trust architecture

### 6.1 Evidence before opportunity

Opportunity reasoning never occurs before the scientific extraction record exists.

### 6.2 No silent invention

The prompts explicitly prohibit invention of:

- sample sizes
- effect sizes
- methods
- comparator details
- causal relations
- clinical effects
- commercial readiness
- regulatory readiness
- policy efficacy

When information is absent, the engine is instructed to state that it is not available in the supplied source.

### 6.3 Association is not causation

Observational evidence is explicitly protected from causal wording.

### 6.4 Evidence maturity is not readiness

Laboratory evidence can have high industry *relevance* while still having low deployment readiness. The engine keeps these concepts separate.

### 6.5 Sensitive Research Mode

Sensitive topics can trigger enhanced review. Categories include, among others:

- clinical efficacy
- mental health / self-harm
- abuse
- children
- genetics
- vulnerable populations
- sexual health
- dual-use / security-sensitive work
- confidential or commercially sensitive IP

### 6.6 Prompt-injection resistance

Research source text is treated as **untrusted data**. Instructions embedded inside a paper or abstract are not allowed to override Aletvia's system rules.

## 7. Structured Outputs

The production provider uses two strict JSON Schemas:

- `aletvia_scientific_extraction`
- `aletvia_opportunity_assessment`

All declared object properties are required and `additionalProperties` is disabled. Automated tests lint this requirement so application code and model output cannot quietly drift apart.

## 8. Semantic QC layer

After schema validation, deterministic quality-control checks look for suspicious combinations, including:

- abstract-only evidence rated as highly sufficient
- high-confidence opportunity claims from metadata only
- causal language associated with observational evidence
- sensitive research not assigned enhanced review
- high media opportunity on sensitive research
- high clinical opportunity from early-stage evidence
- high commercialization opportunity from early-stage evidence

QC does not replace expert review. It is an additional safety net.

## 9. Provenance and reproducibility

Every final record includes:

- schema version
- pipeline version
- extraction-prompt version
- opportunity-prompt version
- model/provider/mode
- generation timestamp
- SHA-256 fingerprint of the input source
- source character count

This establishes the foundation for future institutional auditability.

## 10. Provider architecture

### Live mode

If `OPENAI_API_KEY` is set and `ALETVIA_ENGINE_MODE=openai`, the server performs two structured model calls through the Responses API.

### Local validation mode

If no API key exists, the engine runs a deterministic local-demo provider. It exists only to validate:

- data contracts
- UI rendering
- workflow integration
- schema validation
- sensitive-topic routing

The UI clearly marks local-demo results as **not production AI analysis**.

## 11. Reliability controls

The live provider includes:

- server-side API credential handling
- 90-second request timeout
- retries for transient network, 429, and 5xx failures
- refusal detection
- incomplete-response detection
- strict JSON parsing
- post-model schema validation
- post-model semantic QC

The API key is never placed in browser code.

## 12. User interface

A new **AI Intelligence** module is available for both researcher and institution roles.

The working screen provides:

1. research metadata input
2. evidence-depth selection
3. source-text input
4. engine mode indicator
5. scientific-core output
6. findings and evidence support level
7. evidence maturity and source sufficiency
8. limitations
9. claims to avoid
10. eight-dimensional opportunity profile
11. confidence and evidence/inference basis
12. stakeholder categories
13. recommended actions
14. communication priority
15. uncertainty / QC results

## 13. Automated validation completed

Current automated tests cover:

- valid complete local Research Intelligence Record
- rejection of insufficient source input
- sensitive research → enhanced review
- two-pass OpenAI provider behavior
- strict Structured Outputs call configuration
- extraction schema strictness
- opportunity schema strictness

In addition, an end-to-end headless browser smoke test verified:

```text
Institution login
→ AI Intelligence
→ Run engine
→ structured result renders
→ 8 opportunity dimensions visible
→ recommended action visible
```

## 14. Running locally

```bash
cd Aletvia_RI_OS_MVP
node server.js
```

Open:

```text
http://127.0.0.1:4173
```

Choose a demo role, then open **AI Intelligence**.

### Live model mode

Set server-side environment variables:

```bash
export OPENAI_API_KEY="..."
export OPENAI_MODEL="gpt-6-astra"
export ALETVIA_ENGINE_MODE="openai"
node server.js
```

A `.env.example` is included as documentation. The current zero-dependency server intentionally does not auto-load `.env`; production secret management belongs to the deployment environment.

## 15. What Step 1 deliberately does NOT do

Step 1 does not implement:

- university database or tenant persistence — **Step 2**
- real authentication / permissions — **Step 2**
- DOI metadata fetching — **Step 3**
- PDF extraction / parsing — **Step 3**
- ORCID integration — **Step 3**
- AI-generated communication assets — **Step 4**
- production claim-level Scientific Fidelity Engine — **Step 5**
- production approval workflow — **Step 6**
- multi-paper scientific evaluation — **Step 7**
- university design-partner rollout — **Step 8**

This boundary is intentional.

## 16. Step 1 acceptance criteria

| Criterion | Status |
|---|---|
| Canonical scientific schema | ✅ |
| Canonical opportunity schema | ✅ |
| Two-pass scientific → opportunity architecture | ✅ |
| Strict structured-model provider | ✅ |
| Paper-supported vs Aletvia-inferred distinction | ✅ |
| Evidence maturity and uncertainty | ✅ |
| Sensitive-research logic | ✅ |
| Prompt-injection guardrails | ✅ |
| Semantic QC | ✅ |
| Source fingerprint/provenance | ✅ |
| Retry / timeout / refusal handling | ✅ |
| Working local API endpoint | ✅ |
| Working in-product UI | ✅ |
| Automated tests | ✅ |
| Browser E2E smoke test | ✅ |
| Live external model invocation in this container | Requires an API credential; integration code is complete |

## Product principle

> **Amplify significance. Never manufacture significance.**

Step 1 is the intellectual core on which the later Aletvia workflow will depend.
