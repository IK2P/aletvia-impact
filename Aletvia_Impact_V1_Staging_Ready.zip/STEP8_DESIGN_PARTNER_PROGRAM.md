# Aletvia Impact — Step 8
## Controlled University Design-Partner Program

**Status:** Step 8 completion package  
**Date:** 24 September 2026  
**Frozen prerequisites:** Steps 1–7

## 1. Objective

Step 8 is not a mass-market launch. It is a controlled institutional validation program designed to answer four questions in live university conditions:

1. Do researchers trust Aletvia's scientific interpretation and communication outputs?
2. Does the system materially reduce the effort required to translate research into usable communication and impact assets?
3. Can institutional research and communications teams govern the workflow without losing scientific control?
4. Will a university pay for the product after experiencing the workflow with its own research portfolio?

The step is considered complete when Aletvia has a send-ready design-partner package, five validated target accounts, a fixed pilot scope, measurable success criteria, onboarding and governance procedures, and an outreach sequence ready for explicit human approval before sending.

## 2. Founding Design-Partner Pilot

### Commercial structure
- Duration: **90 days**
- Pilot fee: **₹2.5 lakh + GST**
- Conversion credit: **100% of pilot fee credited toward the first annual subscription** if converted within 30 days after pilot close
- Indicative annual SaaS range after pilot: **₹10–15 lakh/year**, subject to institution size, usage, integrations, and support requirements
- The first cold email does **not** mention price. Commercial terms are introduced after a qualified conversation.

### Included scope
- 1 university / institutional tenant
- Up to **25 researcher users**
- Up to **5 institutional reviewer/admin users**
- Up to **100 research outputs** during the pilot
- DOI, PDF and ORCID ingestion
- Research Intelligence Engine
- Opportunity profiling across industry, policy, media, public, clinical, academic collaboration, funding and commercialization
- Research, Communication & Content Studio (RCC Studio)
- Text, visual-production specifications, motion-production packages and learning assets
- Scientific Fidelity Engine
- Researcher, research-office and communications approval workflow
- Sensitive-research, embargo and IP governance
- Institution-first branding with optional subtle “Powered by Aletvia” attribution
- Weekly design-partner review meeting
- Pilot scorecard and final executive review

### Deliberately excluded from the founding pilot
- Automatic posting to social-media accounts
- Automatic journalist/company outreach
- Production CRIS/Pure/Scopus/WoS integrations
- Final generative video rendering as MP4
- Final pixel-level image rendering as a production design service
- Custom enterprise SSO/SAML
- Unlimited institutional rollout

These exclusions keep the pilot focused on research intelligence, scientific trust, researcher usability and institutional workflow rather than integration work.

## 3. 90-Day Operating Plan

### Days 0–14 — Institutional setup and baseline
- Sign design-partner agreement / pilot order
- Nominate executive sponsor, research-office lead and communications lead
- Configure institution branding and review mode
- Select 3–5 departments representing at least three disciplines
- Invite first 10 researchers
- Import first 20 papers
- Record baseline: current communication process, time per research item, typical artifact mix and approval path

### Days 15–35 — Controlled use
- Expand to 15 researchers
- Process approximately 30 additional papers
- Researchers review Research Intelligence Records
- Generate Quick Share, Public Impact and discipline-relevant packs
- Institutional reviewers exercise Standard and Enhanced workflows
- Capture every correction as structured feedback

### Days 36–65 — Live institutional workflow
- Expand to 20–25 researchers
- Reach 70–80 cumulative research outputs
- Test sensitive-research routing, IP review and embargo handling where naturally applicable
- Track researcher review time, communication-team revision burden and approval cycle time
- Identify recurring product friction and required integrations

### Days 66–80 — Portfolio-scale test
- Reach up to 100 cumulative research outputs
- Review opportunity distribution across the portfolio
- Evaluate whether Aletvia surfaces “hidden research” not normally selected for active communication
- Produce institution-branded RCC assets for approved outputs

### Days 81–90 — Executive review and conversion
- Deliver pilot scorecard
- Present scientific-quality, adoption, workflow and efficiency findings
- Document unresolved blockers
- Agree production requirements and annual subscription scope
- Conversion decision within 30 days

## 4. Pilot Success Criteria

### Scientific trust — hard gate
- **Zero severe scientific misrepresentation** may reach Ready for Activation
- ≥90% of researcher-reviewed Research Intelligence Records rated “accurate” or “mostly accurate”
- 100% of activated assets must have a current Step-5 fidelity report
- Sensitive-research cases must route through Enhanced review

### Adoption
- ≥15 of 25 invited researchers become active users
- ≥50 real research outputs processed
- ≥30 RCC assets reach institutional approval / Ready for Activation
- ≥3 departments use the workflow meaningfully

### Efficiency
- Median researcher review burden ≤10 minutes per paper after ingestion
- ≥70% of generated first drafts accepted with minor edits or less
- Communications/research-office users report ≥50% reduction in preparation effort for comparable artifacts, measured against their baseline estimate

### Perceived value
- ≥70% of active researchers rate the workflow ≥4/5 for usefulness
- Institutional sponsor rates scientific governance ≥4/5
- Research/communications leadership identifies at least one ongoing institutional workflow where Aletvia should remain in use

### Commercial validation
The pilot is commercially validated if the institution either:
1. converts to an annual subscription, or
2. provides a concrete procurement path with a defined blocker and decision date.

A “successful demo but no owner, budget, procurement path or next date” is **not** counted as commercial validation.

## 5. Design-Partner Feedback Loop

Every substantive correction is recorded in one of these buckets:
- Research extraction error
- Evidence maturity error
- Opportunity-routing error
- Audience mismatch
- Unsupported/overstated claim
- Missing limitation
- Poor content format
- Branding/layout requirement
- Reviewer-routing problem
- Institution policy requirement
- Integration requirement
- Usability/friction

Feedback should improve the product across institutions; university-specific customizations should be isolated from the core product whenever possible.

## 6. Governance and Safety During Pilot

- No asset is externally distributed by Aletvia automatically.
- Researchers retain sign-off over their own scientific communication.
- Institutional reviewers control final activation.
- A current fidelity report is mandatory for final approval.
- Sensitive research follows Enhanced review.
- Institution controls embargo and IP clearance.
- Any severe scientific error is treated as a pilot incident and reviewed immediately.

## 7. Target Cohort

The first five design-partner targets are:
1. Manipal Academy of Higher Education (MAHE)
2. Vellore Institute of Technology (VIT)
3. BITS Pilani
4. Amrita Vishwa Vidyapeetham
5. SRM Institute of Science and Technology (SRMIST)

Selection rationale: all five are research-active, multidisciplinary Indian institutions with identifiable research leadership and enough portfolio diversity to test the product rigorously. The cohort intentionally mixes strong health-sciences portfolios, engineering-heavy portfolios and multi-campus governance structures.

## 8. Outreach Rule

No outreach is sent automatically in Step 8. The package is prepared to “ready to send.” The founder explicitly approves the first outreach wave before any email is sent.

## 9. Step-8 Completion Gate

Step 8 preparation is complete when the following exist:
- verified target-account matrix
- public decision-maker/contact routes
- fixed 90-day pilot scope and commercial structure
- success scorecard
- personalized initial emails
- follow-up cadence
- one-page pilot proposition
- onboarding runbook
- conversion decision framework
- CRM-style outreach tracker
- explicit founder approval gate before send

