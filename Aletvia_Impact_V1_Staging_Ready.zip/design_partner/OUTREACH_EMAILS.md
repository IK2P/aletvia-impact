# Aletvia — Founding Design-Partner Outreach

These are short first-touch emails. Do not attach a large deck on the first message. Attach or link the one-page pilot proposition only if appropriate. Price is intentionally omitted until a qualified conversation.

---

## 1. MAHE
**To:** Dr Naveen Salins — naveen.salins@manipal.edu  
**Suggested CC:** office.dor@manipal.edu  
**Subject:** Design-partner pilot for research impact at MAHE

Dear Dr Salins,

I’m building **Aletvia Impact**, an institutional platform designed to help universities systematically turn published research into scientifically faithful, audience-specific impact assets without adding manual burden to researchers or communications teams.

For each paper, Aletvia can:
- identify industry, policy, media, public and collaboration opportunities;
- create research summaries, graphical abstracts, posters/share cards, video-abstract packages and briefs; and
- independently check scientific fidelity before researcher and institutional approval.

We have completed an internal 30-paper validation program and are now selecting a small group of Indian universities for a **90-day founding design-partner pilot**.

MAHE is particularly relevant because of its multidisciplinary research portfolio and established Directorate of Research / research-management infrastructure. Aletvia is intended to work alongside those systems rather than replace them.

Would you be open to a 20-minute demonstration and discussion of whether a controlled pilot at MAHE would be useful?

Regards,
Rajnish Kumar Yadav
Aletvia

---

## 2. VIT
**To:** Dr Amitava Mukherjee — dean.ar@vit.ac.in  
**Suggested CC:** assodean.ar@vit.ac.in  
**Subject:** Aletvia research-impact design-partner pilot for VIT

Dear Dr Mukherjee,

I’m developing **Aletvia Impact**, a university SaaS platform that helps researchers and research offices translate published work into accurate, institution-governed research communication and impact assets.

Aletvia combines:
- research intelligence and opportunity identification;
- audience-specific summaries, briefs, graphical/visual assets and video-abstract packages;
- independent scientific-fidelity checking; and
- researcher + institutional approval workflows.

We have completed a 30-paper internal validation across multiple disciplines and are now inviting a small number of research-active Indian universities into a **90-day founding design-partner pilot**.

VIT’s explicit focus on quality research and research integrity makes it a strong environment for testing whether Aletvia can extend research visibility while preserving scientific control.

May I show you the working system in a 20-minute demonstration and discuss a controlled pilot with selected VIT researchers?

Regards,
Rajnish Kumar Yadav
Aletvia

---

## 3. BITS Pilani
**To:** Prof Sounak Roy — dean.ri@bits-pilani.ac.in  
**Suggested CC:** deanri.office@bits-pilani.ac.in  
**Subject:** Research-to-impact infrastructure pilot for BITS Pilani

Dear Prof Roy,

I’m building **Aletvia Impact**, an institutional platform that helps a university move from published research to scientifically governed external impact.

For each paper, the system can identify suitable industry, policy, media, public and collaboration pathways; generate audience-specific research assets; independently verify scientific fidelity; and route outputs through researcher and institutional approval.

We have completed an internal 30-paper multidisciplinary validation and are now selecting a few universities for a **90-day founding design-partner pilot**.

BITS is especially relevant because Aletvia’s research-to-industry and research-to-stakeholder routing could complement the institute’s Research & Innovation, grants, consultancy and industrial-research ecosystem.

Would you be open to a 20-minute demonstration to assess whether this is worth piloting with a selected BITS research cohort?

Regards,
Rajnish Kumar Yadav
Aletvia

---

## 4. Amrita Vishwa Vidyapeetham
**To:** Office of the Pro Vice-Chancellor — provostoffice@amrita.edu  
**Suggested CC:** aoc@amrita.edu  
**Subject:** Founding design-partner pilot for university research impact

Dear Prof Maneesha Ramesh,

I’m developing **Aletvia Impact**, an institutional SaaS platform that connects research understanding, research communication and institutional governance in one workflow.

For each publication Aletvia can identify relevant external audiences, generate research summaries and multimodal content, independently verify scientific claims, and route every asset through researcher and institutional approval before activation.

After completing an internal 30-paper multidisciplinary validation, we are selecting a small group of Indian universities for a **90-day founding design-partner pilot**.

Amrita’s multi-campus research portfolio, active research partnerships and established Office of Communications make it particularly relevant for testing a research-to-impact workflow that spans both research leadership and communications.

Would you be open to a short demonstration and discussion of a controlled pilot with selected researchers?

Regards,
Rajnish Kumar Yadav
Aletvia

---

## 5. SRMIST
**To:** Dean (Research) — dean.research@srmist.edu.in  
**Subject:** Aletvia research-impact design-partner pilot for SRMIST

Dear Dean (Research),

I’m building **Aletvia Impact**, an institutional platform designed to help research-active universities systematically identify, translate and activate the external value of their published research while maintaining scientific and institutional control.

Aletvia can:
- analyse research outputs and identify suitable audiences;
- create research summaries, briefs, posters/share cards, graphical-abstract specifications and video-abstract packages;
- independently verify scientific fidelity; and
- route content through researcher, research-office and communications approval.

We have completed an internal 30-paper validation program and are now selecting a few Indian universities for a **90-day founding design-partner pilot**.

Given SRMIST’s large multidisciplinary research portfolio, I believe it would be a strong environment for testing the workflow across both engineering and health-sciences research.

Would you be open to a 20-minute demonstration?

Regards,
Rajnish Kumar Yadav
Aletvia

---

# Follow-up sequence

## Follow-up 1 — Day 4
**Subject:** Re: [original subject]

Dear [Name],

Just following up on my note below. The main idea is simple: **Aletvia gives every participating researcher an AI Research Impact Assistant while keeping the research office and communications team in control of scientific approval.**

I can demonstrate the full paper → research intelligence → content → fidelity → approval workflow in about 20 minutes.

Would a short call next week be useful?

Regards,
Rajnish

## Follow-up 2 — Day 10

Dear [Name],

One additional point that may be relevant: we built Aletvia specifically to avoid the usual trade-off between wider research communication and scientific accuracy. Every activatable asset is versioned and independently checked against the underlying evidence before institutional approval.

Our current design-partner pilot is deliberately limited to a small research cohort so the institution can evaluate scientific quality, researcher effort and communications value before considering a broader deployment.

Happy to share the one-page pilot outline if useful.

Regards,
Rajnish

## Close-the-loop — Day 18

Dear [Name],

I’ll close the loop after this note. If research-portfolio communication / impact infrastructure is relevant to your current priorities, I would be glad to show Aletvia and explore a controlled pilot. If not, no action is needed.

Regards,
Rajnish Kumar Yadav
Aletvia
