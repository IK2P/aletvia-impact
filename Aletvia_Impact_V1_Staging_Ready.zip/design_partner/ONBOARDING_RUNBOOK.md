# Aletvia Founding Design-Partner — Onboarding Runbook

## Before kickoff
Institution nominates:
- Executive sponsor
- Research-office owner
- Communications owner
- Technical/contact person
- Up to 25 researchers
- Up to 5 reviewers/admins

Aletvia confirms:
- pilot scope and dates
- data-handling expectations
- branding profile
- Standard vs Enhanced review defaults
- sensitive-research categories
- embargo/IP rules
- pilot disciplines/departments

## Kickoff meeting (60 minutes)
1. Confirm success metrics
2. Map current research-to-communication workflow
3. Identify current bottlenecks
4. Confirm researchers/departments
5. Confirm governance roles
6. Demonstrate one real paper end-to-end
7. Agree weekly feedback cadence

## Week 1 data setup
- Configure institution
- Add departments
- Invite users
- Import first 20 papers by DOI/PDF/ORCID
- Validate researcher ownership
- Review 5 Research Intelligence Records manually
- Record baseline time required by current process

## Weekly operating rhythm
- 30-minute design-partner review
- Review quantitative scorecard
- Discuss 3–5 representative outputs
- Log product corrections
- Resolve workflow blockers
- Select next set of papers

## Incident rule
Any severe scientific misrepresentation, cross-tenant data issue, unauthorized activation or governance bypass is treated as a priority incident. External distribution pauses for the affected workflow until reviewed.

## Mid-pilot review (around Day 45)
- Scientific accuracy sample review
- Adoption vs target
- Researcher review burden
- Communications-team effort
- Approval bottlenecks
- Requested integrations
- Decide whether to expand to remaining pilot seats

## Final review
Aletvia presents:
- outputs processed
- opportunities identified
- asset/pack generation
- fidelity outcomes
- approval throughput
- active users
- review effort
- qualitative feedback
- product gaps
- recommended annual scope and commercial proposal
