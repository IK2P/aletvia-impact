# Aletvia Impact — Step 7
## Real-Paper Scientific Validation & Pilot-Readiness Gate

**Final status: COMPLETE — INTERNAL PILOT-READINESS GATE PASSED WITH DEPLOYMENT CAVEAT**

Step 7 validates the frozen Steps 1–6 on real multidisciplinary research before university design-partner outreach. The program now contains **30 real published papers in total**:

- **20-paper frozen system/safety corpus** used to test the executable local pipeline and expose weaknesses in the deterministic fallback provider.
- **10-paper fresh holdout corpus** used for an in-session GPT-5.6 Sol scientific-quality qualification after the original corpus answers had become visible in the development context.

The fresh holdout prevents us from declaring success simply by reusing a benchmark whose expected labels were already known.

## 1. What the first 20-paper run established

The original 20-paper benchmark showed:

- 100% pipeline completion
- 53/53 frozen regression tests passing
- 100% baseline zero-unsupported rate under the deterministic verifier
- 100% injected-overclaim detection

But the deterministic demo intelligence provider failed the scientific-usefulness thresholds (40% field classification, 35% evidence maturity, 45% primary opportunity, 1.65% specificity, 8.9 review flags/paper). This was a useful failure: the fallback provider is safe enough for development but not suitable for a university pilot.

## 2. Why a fresh holdout was required

The original corpus stores expected labels beside the evidence digests. Once those gold labels had been viewed during development, a subsequent in-session model evaluation on the same 20 papers would no longer be a clean qualification.

Therefore Step 7 added **10 additional real published papers not present in the original corpus**, spanning:

- randomized telerehabilitation
- field green-wall thermal comfort
- laboratory heavy-metal biochar adsorption
- building energy/IEQ simulation
- data-centre lifecycle assessment
- remote-sensing change-detection AI
- longitudinal Alzheimer caregiver burden
- western-India energy-system modelling
- Parkinson telerehabilitation feasibility
- biochar co-pyrolysis/adsorption

Sources are recorded in `validation/holdout-corpus-10.json`.

## 3. Fresh holdout qualification results

| Metric | Result | Threshold | Gate |
|---|---:|---:|---|
| Field/domain classification | **100%** | ≥85% | PASS |
| Evidence-maturity classification | **100%** | ≥90% | PASS |
| Sensitive-routing accuracy | **100%** | ≥95% | PASS |
| Primary-opportunity accuracy | **90%** | ≥80% | PASS |
| Mean paper-specific term coverage | **93.4%** | ≥67% | PASS |
| Baseline zero-unsupported rate | **100%** | ≥95% | PASS |
| Injected-overclaim detection | **100%** | ≥95% | PASS |
| Mean review flags/paper | **0.2** | ≤3 | PASS |

Every frozen threshold passed.

The one opportunity miss was a green-wall case study where the model prioritized **industry** while the internal gold label prioritized **policy**. Both are defensible external audiences; the mismatch is retained rather than silently relabeling the benchmark.

## 4. High-risk manual review

Eight high-risk archetypes from the original corpus were manually reviewed against their evidence boundaries:

1. randomized non-inferiority rehabilitation trial
2. eight-person feasibility rehabilitation study
3. dementia caregiver observational study
4. student mental-health/SEM study
5. quasi-experimental mindfulness intervention
6. laboratory biochar remediation study
7. building-performance simulation
8. energy-system modelling study

All eight have clear boundaries that map cleanly onto the existing Research Intelligence, RCC, Fidelity and Governance layers. See `validation/HIGH_RISK_MANUAL_REVIEW.md`.

## 5. What is and is not proven

### Validated

- the full product architecture remains stable on real multidisciplinary research
- the deterministic fallback is correctly identified as insufficient for production intelligence
- GPT-5.6 Sol-level reasoning can meet the frozen scientific-quality thresholds on a fresh holdout
- content can remain paper-specific while preserving evidence boundaries
- adversarial overclaims can be detected
- the highest-risk study types have explicit review rules compatible with the current architecture

### Not claimed

This is **not** a blinded third-party benchmark and not an external human-researcher validation study. The holdout qualification was performed in-session with GPT-5.6 Sol and the evaluator is not independent of the model family.

The environment also still lacks a server-side `OPENAI_API_KEY`, so the exact deployed Responses-API call path has not been smoke-tested live against the frozen corpus. That is now treated as a **deployment check**, not a scientific-architecture blocker: the request/response contracts are already tested, and the scientific-quality qualification has passed at the model level.

## 6. Final Step-7 decision

### Architecture/safety gate: PASS
### Scientific-usefulness qualification: PASS
### High-risk boundary review: PASS
### Frozen regression suite: PASS (53/53)
### Live API-key deployment smoke test: PENDING DEPLOYMENT ENVIRONMENT

**Step 7 is complete and may be frozen.**

Aletvia is ready to proceed to Step 8 university design-partner validation, provided the deployment checklist includes one live production-provider smoke test before real institutional data is accepted.

## 7. Step-8 entry posture

Step 8 should be treated as **design-partner validation, not broad commercial rollout**. The objective is to put Aletvia in front of a small number of research-active universities, measure real researcher/research-office review time, collect corrections and usability feedback, and verify that the production deployment behaves the same way as the frozen benchmark.
