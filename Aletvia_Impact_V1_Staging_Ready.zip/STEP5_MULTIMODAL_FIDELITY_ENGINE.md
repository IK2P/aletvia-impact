# Step 5 — Multimodal Scientific Fidelity Engine

## Status
Complete and ready to freeze. Steps 1–4 remain the upstream product layers. Step 5 adds independent verification and a final-approval gate; it does not redesign the RCC generation system.

## Purpose
The Multimodal Scientific Fidelity Engine answers one question before an RCC asset can receive final institutional approval:

> Does every meaningful scientific claim in this exact artifact version remain within the evidence provided by the underlying research?

The verifier covers Text, Visual, Motion, and Learning assets. It does not trust the Step-4 generation-time claim ledger as proof of correctness.

## Core invariant
Generation and verification are separate systems.

Research evidence → Step 1 Research Intelligence → Step 4 RCC generation → **Step 5 independent verification** → final institutional approval.

The Step-4 claim ledger can help humans locate generated claims, but Step 5 independently reconstructs candidate claims from the final asset itself.

## 1. Independent multimodal claim extraction
Step 5 reconstructs claims from:

- headline and dek
- prose body sentences
- key messages
- visual layout blocks
- diagram semantics
- voice-over narration
- captions
- storyboard narration and on-screen text
- learning-card answers
- glossary items

Decorative visual/storyboard items are excluded when marked decorative.

Generation-time `basis_type=paper_supported` is deliberately ignored when deciding a verdict.

## 2. Verdicts
Each independently extracted claim receives one of four verdicts:

- **Supported** — directly supported within the available evidence.
- **Supported with context** — core statement is supported, but a qualifier, study condition, population, comparator, evidence stage, or limitation must remain visible.
- **Speculative** — plausible interpretation or external relevance, but not directly demonstrated by the research.
- **Unsupported** — contradicted, numerically unsupported, causally overstated, or beyond the scientific evidence boundary.

Each claim also stores confidence, risk type, rationale, an evidence excerpt/reference, and a suggested revision.

## 3. Source sufficiency
Verification separately records evidence depth:

- `full_text`
- `abstract`
- `intelligence_only`
- `metadata_only`

Metadata-only evidence is never eligible for final approval. Abstract/intelligence-only verification can produce useful preliminary fidelity results, but the UI explicitly communicates the weaker evidence basis.

## 4. Quantitative safeguards
Numbers, percentages, effect sizes, sample counts, durations, and other quantitative assertions must be discoverable in the verification evidence. A new number introduced by an RCC asset is marked Unsupported rather than inferred from surrounding prose.

## 5. Evidence-maturity safeguards
The deterministic verifier contains explicit safeguards against common scientific overstatement patterns. Laboratory, pilot, cross-sectional, simulation, prototype, preclinical, and abstract-stage evidence cannot silently become:

- causal proof
- clinical efficacy
- commercial readiness
- municipal/full-scale effectiveness
- policy certainty
- a proven universal solution

The verifier also respects Step-1 claims-to-avoid, but does not misclassify cautionary statements such as “not established” or “do not generalize” as violations.

## 6. Sensitive-research rule
For sensitive research, speculative claims block final approval until resolved. This gives sensitive clinical, mental-health, abuse, vulnerable-population, and similar content a stricter evidence threshold without changing Step-1 sensitivity classification.

## 7. Exact-version binding and staleness
Every fidelity report is bound to:

- institution
- research object
- RCC asset
- exact RCC asset version ID and version number
- source fingerprint
- generation-context fingerprint
- verification-packet fingerprint
- verifier provider/model/version
- timestamp

A report becomes stale automatically if the RCC asset receives a newer version or its bound generation/source fingerprint changes.

This means:

AI generation v1 → fidelity report v1 → human edit creates RCC v2 → old fidelity report is stale → Step 5 must be re-run.

No manual “invalidate report” action is required.

## 8. Approval gate
Step 5 adds one narrow change to the frozen approval path: an institutional reviewer cannot set an RCC asset to **Approved** unless the latest fidelity state is:

1. present,
2. current (not stale), and
3. `approval_eligible=true`.

Researchers can still submit assets for review before final approval. Step 6 can later expand the workflow UX, reviewer assignment, comments, escalation, and release mechanics; Step 5 only enforces the scientific prerequisite for final approval.

## 9. Persistence
Two new relational structures are added.

### `fidelity_reports`
Stores the version-bound verification record, evidence depth, fingerprints, engine metadata, overall status, approval eligibility, and complete structured report.

### `fidelity_claims`
Stores each independently verified claim with location, modality, verdict, confidence, evidence excerpt, rationale, risk type, and revision recommendation.

Both are institution-scoped.

## 10. Tenant/security model
Fidelity reports inherit Step-2 isolation. Cross-institution access returns no report. Researchers can verify assets only within their research scope. Leadership viewers are read-oriented and cannot run verification. Production SQL includes RLS policies for report and claim access.

## 11. API surface

- `GET /api/fidelity/capabilities`
- `POST /api/fidelity/verify`
- `GET /api/fidelity-reports?asset_id=...`
- `GET /api/fidelity-reports/:id`
- `GET /api/fidelity-status/:asset_id`

The existing final approval endpoint now checks the Step-5 approval gate.

## 12. Local and production verification providers
### Portable/local mode
A deterministic independent verifier runs without external credentials. It supports repeatable development, regression testing, provenance, quantitative checks, maturity-overstatement checks, and full workflow validation.

### Production AI mode
When `OPENAI_API_KEY` is configured, the verifier can use the OpenAI Responses API with strict Structured Outputs, `store:false`, retries, timeout handling, and an independent fidelity prompt. The default production fidelity model is configurable through `OPENAI_FIDELITY_MODEL` and currently defaults to `gpt-5.6-sol` in the implementation.

The OpenAI provider receives the verification evidence packet and independently extracted claims. It is explicitly instructed to treat both uploaded research and RCC content as untrusted data rather than instructions.

## 13. UI
The former Step-4 “claim ledger handoff” page is replaced by an operational Multimodal Scientific Fidelity Engine screen. It shows:

- exact asset version being checked
- overall status
- approval eligibility / blocked / stale state
- evidence sufficiency
- counts by fidelity verdict
- claim-by-claim verdicts
- modality and location
- evidence excerpts
- risk type
- suggested revisions
- a button to run/re-run verification

## 14. Automated tests
The complete suite passes **44/44** tests.

New Step-5 coverage includes:

- independent multimodal claim extraction
- explicit proof that the Step-4 claim ledger is not trusted as a verdict
- invented-number detection
- evidence-maturity overstatement detection
- report persistence
- exact-version binding
- automatic staleness after manual editing
- final approval gating
- tenant isolation
- OpenAI Responses API / Structured Outputs contract
- all prior Step 1–4 regression paths

## 15. End-to-end validation
A real generated sample PDF was used through the connected product flow:

PDF ingestion → Step-1 intelligence → Public Impact Pack → five RCC artifacts → Step-5 verification → final institutional approval.

Verified RCC artifacts:

- Plain-language summary — Text
- Graphical abstract — Visual
- WhatsApp status / wallpaper — Visual
- Carousel — Visual
- Video Abstract — Motion

All five received `Pass with cautions`, were approval-eligible, and contained zero Unsupported claims in the deterministic end-to-end validation run. The chosen text asset was then submitted and institutionally approved successfully after Step 5.

## 16. What Step 5 deliberately does not do
Step 5 does not yet implement:

- reviewer assignment and reviewer comments
- institutional SLA/escalation flows
- release/publish/export actions
- distribution analytics
- final human attestation signatures
- real-pixel verification of rendered image/video output after a third-party renderer transforms the structured production spec

Reviewer/workflow completion belongs to Step 6. Rendered-pixel/audio verification can be added when actual rendering is introduced; the current Step 5 verifies the RCC structured visual/motion content specification, narration, captions, and semantics.

## Acceptance criteria
Step 5 is complete when:

- final claims are independently reconstructed from RCC output ✅
- Text/Visual/Motion/Learning modalities are covered ✅
- claim ledger is not treated as proof ✅
- quantitative hallucinations can be blocked ✅
- evidence-maturity overclaims can be blocked ✅
- source sufficiency is explicit ✅
- reports bind to exact asset versions ✅
- edits invalidate prior verification ✅
- tenant isolation holds ✅
- final approval requires current eligible fidelity ✅
- production RLS migration exists ✅
- production OpenAI structured verification path exists ✅
- regression suite passes 44/44 ✅
- multimodal E2E path passes ✅

**Step 5 is ready to freeze.**
