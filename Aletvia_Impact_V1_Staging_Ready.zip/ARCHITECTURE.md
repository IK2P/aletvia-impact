# Aletvia Impact — Architecture through Step 6

```text
DOI / PDF / ORCID
       ↓
Canonical Research Object
       ↓
Step 1 — Research Intelligence Engine
       ↓
Step 2 — Auth + Multi-tenant Persistence
       ↓
Step 3 — Provenance-aware Research Ingestion
       ↓
Step 4 — Research, Communication & Content Studio
       ↓
Step 5 — Independent Multimodal Scientific Fidelity
       ↓
Step 6 — Institutional Approval & Governance
       ↓
READY FOR ACTIVATION
```

## Step-6 trust chain

```text
Current RCC asset version
  ├─ researcher sign-off (same version)
  ├─ eligible Step-5 fidelity report (same version/fingerprints)
  ├─ Research Office approval if Enhanced (same version)
  ├─ IP clearance if required (same version)
  ├─ Communications approval (same version)
  └─ no active embargo
            ↓
      Ready for Activation
```

Any new asset version invalidates prior version-bound decisions and fidelity.

See `STEP6_APPROVAL_GOVERNANCE_WORKFLOW.md` for full details.
