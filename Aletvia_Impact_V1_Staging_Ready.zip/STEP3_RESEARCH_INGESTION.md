# Step 3 — Real Research Ingestion (FROZEN-CANDIDATE)

## Objective
Bring real research into Aletvia through DOI metadata, PDF full text, and ORCID-linked works, normalize every source into one canonical Research Object, deduplicate it inside the active institution, preserve source provenance, and hand sufficient evidence to the frozen Step-1 Research Intelligence Engine.

## Frozen predecessors
- Step 1: Research Intelligence Engine remains unchanged.
- Step 2: Authentication, persistence, tenant isolation and permissions remain unchanged.

## Canonical ingestion contract
All adapters return the same logical fields before persistence:
- title
- authors
- journal / venue
- DOI (normalized when present)
- publication date/state
- evidence depth: metadata / abstract / full_text
- source text used for scientific analysis
- raw source metadata
- source type + source identifier + source URL

The adapter is never the downstream contract. `Research Object` is the downstream contract.

## Adapter A — DOI
1. Normalize `doi:` and `https://doi.org/` forms.
2. Validate DOI syntax.
3. Retrieve Crossref `/works/{doi}` metadata.
4. Strip JATS/HTML markup from abstracts.
5. Normalize authors, venue and dates.
6. Persist source provenance.
7. Deduplicate DOI within the active institution.
8. Automatically run frozen Step 1 if evidence text is sufficient.

Crossref requests include a product User-Agent and support the `mailto` polite-pool parameter via `CROSSREF_MAILTO`.

## Adapter B — PDF
1. Browser reads PDF bytes and sends base64 in the portable Step-3 runtime.
2. Backend validates `%PDF-` signature and 15 MB maximum.
3. `pdftotext` extracts UTF-8 text without shell interpolation.
4. DOI is conservatively detected from extracted text when present.
5. Title is heuristically proposed and can later be confirmed by the researcher.
6. SHA-256 fingerprints preserve provenance.
7. The original PDF is not retained in the portable runtime.
8. Extracted full text is stored as an ingestion source.
9. Frozen Step 1 runs automatically when extracted text is 80–200,000 characters.

Scanned/image-only PDF behavior: ingestion is rejected as insufficient for Step-1 analysis rather than silently invoking OCR. OCR is explicitly outside Step 3.

Production difference: original PDFs should be stored in a private object-storage bucket; the database stores storage path, extracted text, hash and provenance.

## Adapter C — ORCID
1. Normalize and validate ORCID iD using its checksum.
2. If `ORCID_PUBLIC_TOKEN` is configured, retrieve public works from ORCID API v3.0 and resolve DOI works through Crossref.
3. Without that token, use Crossref's `filter=orcid:{id}` endpoint as a credential-free works discovery fallback.
4. Limit each import to 1–100 works.
5. Each work is normalized independently.
6. DOI-based deduplication means a DOI imported earlier from Crossref or PDF resolves to the same Research Object.

Important: manually entering an ORCID iD for works import is not equivalent to an authenticated researcher-to-ORCID account link. Production profile linking should use ORCID OAuth. Step 3 does not falsely mark manual input as authenticated ownership.

## Deduplication
Order:
1. Exact normalized DOI within active institution.
2. If no DOI exists, exact normalized title key within active institution.
3. Otherwise create a new Research Object.

The title fallback is intentionally conservative. Fuzzy title merging is deferred because false merges are more damaging than duplicate records.

## Provenance
`ingestion_sources` records:
- institution
- research object
- DOI/PDF/ORCID source type
- source identifier + URL
- SHA-256 content fingerprint
- raw metadata
- exact source text used for analysis
- evidence depth
- importing user
- timestamp

`research_intelligence_records` stores the complete frozen Step-1 JSON record with its source fingerprint and engine version.

## Long documents
Step 1 is frozen at 200,000 source characters. Step 3 never silently truncates a long PDF. It ingests the source, sets `ingestion_status=needs_chunking`, and explicitly records why automatic analysis was not run. Chunked long-document synthesis is a later capability.

## Permissions
- Researcher: may import only into their own profile.
- Institution Admin / Research Office Reviewer / Communications Reviewer: may import for a member of the active institution.
- Leadership Viewer: read-only; cannot ingest.
- Every created source remains tenant-scoped.

## API endpoints
- `GET /api/ingestion/capabilities`
- `POST /api/ingest/doi`
- `POST /api/ingest/pdf`
- `POST /api/ingest/orcid`
- `GET /api/research-intelligence/{research_output_id}`

## UI
A new **Import Research** screen provides three tabs:
- DOI
- PDF upload
- ORCID

The screen explains provider/evidence limitations, supports owner assignment for privileged institutional roles, optionally runs Step 1 immediately, and displays whether an import created a new object or matched an existing one.

## Automated acceptance results
Full test suite: 25/25 passing.

Coverage includes:
- frozen Step-1 structured intelligence tests
- frozen Step-2 tenant/auth/security tests
- DOI normalization
- ORCID checksum validation
- Crossref metadata normalization
- ORCID Crossref fallback behavior
- actual PDF text extraction from a generated PDF fixture
- invalid PDF rejection
- DOI-level deduplication across source types
- provenance source count
- Research Intelligence persistence
- researcher ownership enforcement
- PDF → frozen Step-1 automatic handoff
- authenticated HTTP ingestion capability endpoint
- HTTP DOI create + repeat dedupe
- HTTP PDF full-text ingestion

## Network-validation limitation in this execution environment
The container currently has no outbound DNS. Therefore the Crossref and ORCID adapters are validated against deterministic API-shaped fixtures, while live API behavior was checked against current official documentation. Real external HTTP calls must be smoke-tested in the deployment environment with outbound internet access before production release.

## Step 3 completion definition
Step 3 is complete when:
- DOI, PDF and ORCID adapters exist and are reachable from UI/API.
- all three converge to a canonical Research Object.
- provenance is persisted.
- DOI-first deduplication works across adapters.
- tenant/ownership controls from Step 2 remain enforced.
- sufficient evidence automatically invokes frozen Step 1.
- insufficient/too-long evidence is explicit, never silently truncated.
- production Supabase schema extension exists.
- all automated tests pass.
