import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export function hashPassword(password, saltHex = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(password, Buffer.from(saltHex, 'hex'), 210000, 32, 'sha256').toString('hex');
  return { salt: saltHex, hash };
}
export function verifyPassword(password, salt, expected) {
  const got = hashPassword(password, salt).hash;
  return crypto.timingSafeEqual(Buffer.from(got, 'hex'), Buffer.from(expected, 'hex'));
}
export function tokenHash(token){ return crypto.createHash('sha256').update(token).digest('hex'); }

export function openDb(dbPath){
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), {recursive:true});
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
  migrate(db);
  seed(db);
  return db;
}

function migrate(db){
  db.exec(`
  CREATE TABLE IF NOT EXISTS institutions (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, short_code TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS departments (
    id TEXT PRIMARY KEY, institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE, name TEXT NOT NULL,
    UNIQUE(institution_id,name)
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS memberships (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    department_id TEXT REFERENCES departments(id) ON DELETE SET NULL,
    role TEXT NOT NULL CHECK(role IN ('researcher','research_office_reviewer','communications_reviewer','institution_admin','leadership_viewer')),
    active INTEGER NOT NULL DEFAULT 1,
    UNIQUE(user_id,institution_id)
  );
  CREATE TABLE IF NOT EXISTS research_outputs (
    id TEXT PRIMARY KEY, institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    department_id TEXT REFERENCES departments(id) ON DELETE SET NULL,
    title TEXT NOT NULL, authors TEXT NOT NULL, journal TEXT, doi TEXT, publication_date TEXT,
    publication_state TEXT NOT NULL DEFAULT 'Published', evidence_depth TEXT NOT NULL DEFAULT 'Abstract', evidence_maturity TEXT NOT NULL,
    communication_priority TEXT NOT NULL DEFAULT 'B', workflow_state TEXT NOT NULL DEFAULT 'Draft', sensitive INTEGER NOT NULL DEFAULT 0,
    did_text TEXT NOT NULL, found_text TEXT NOT NULL, why_text TEXT NOT NULL, limitations_text TEXT NOT NULL,
    audience_json TEXT NOT NULL DEFAULT '[]', action_text TEXT NOT NULL, visibility_text TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS opportunity_assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT, research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
    dimension TEXT NOT NULL, rating TEXT NOT NULL, confidence TEXT NOT NULL, rationale TEXT NOT NULL,
    UNIQUE(research_output_id,dimension)
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    active_institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, institution_id TEXT NOT NULL, user_id TEXT NOT NULL,
    action TEXT NOT NULL, entity_type TEXT, entity_id TEXT, metadata_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id);
  CREATE INDEX IF NOT EXISTS idx_research_tenant ON research_outputs(institution_id);
  CREATE INDEX IF NOT EXISTS idx_research_owner ON research_outputs(owner_user_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  `);
}

function seed(db){
  const count=db.prepare('SELECT count(*) c FROM institutions').get().c;
  if(count) return;
  const insInst=db.prepare('INSERT INTO institutions(id,name,short_code) VALUES(?,?,?)');
  insInst.run('inst_northstar','Northstar University','NU');
  insInst.run('inst_meridian','Meridian Institute of Science','MIS');
  const insDept=db.prepare('INSERT INTO departments(id,institution_id,name) VALUES(?,?,?)');
  const depts=[
    ['d_env','inst_northstar','Environmental Engineering'],['d_ai','inst_northstar','AI & Geospatial Systems'],['d_clin','inst_northstar','Clinical Sciences'],['d_admin','inst_northstar','Research Office'],
    ['d_mat','inst_meridian','Materials & Energy'],['d_bio','inst_meridian','Biomedical Engineering'],['d_admin2','inst_meridian','Research Office']
  ]; depts.forEach(x=>insDept.run(...x));
  const demoPass='DemoPass!2026';
  const insUser=db.prepare('INSERT INTO users(id,email,display_name,password_hash,password_salt) VALUES(?,?,?,?,?)');
  const users=[
    ['u_n_admin','admin@northstar.edu','Asha Verma'],['u_n_research','researcher@northstar.edu','Dr. Anika Rao'],['u_n_comm','communications@northstar.edu','Maya Kapoor'],
    ['u_m_admin','admin@meridian.edu','Daniel Lee'],['u_m_research','researcher@meridian.edu','Dr. Leena Bose'],['u_multi','multi@aletvia.demo','Alex Morgan']
  ];
  for(const [id,email,name] of users){const {salt,hash}=hashPassword(demoPass);insUser.run(id,email,name,hash,salt)}
  const insMem=db.prepare('INSERT INTO memberships(id,user_id,institution_id,department_id,role) VALUES(?,?,?,?,?)');
  [
    ['m1','u_n_admin','inst_northstar','d_admin','institution_admin'],['m2','u_n_research','inst_northstar','d_env','researcher'],['m3','u_n_comm','inst_northstar','d_admin','communications_reviewer'],
    ['m4','u_m_admin','inst_meridian','d_admin2','institution_admin'],['m5','u_m_research','inst_meridian','d_mat','researcher'],
    ['m6','u_multi','inst_northstar','d_admin','leadership_viewer'],['m7','u_multi','inst_meridian','d_admin2','leadership_viewer']
  ].forEach(x=>insMem.run(...x));
  const insR=db.prepare(`INSERT INTO research_outputs(id,institution_id,owner_user_id,department_id,title,authors,journal,doi,publication_date,publication_state,evidence_depth,evidence_maturity,communication_priority,workflow_state,sensitive,did_text,found_text,why_text,limitations_text,audience_json,action_text,visibility_text)
  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const rows=[
    ['n1','inst_northstar','u_n_research','d_env','Engineered Biochar for Removal of Pharmaceutical Micropollutants from Water','Anika Rao et al.','Journal of Sustainable Water Systems','10.demo/nu.2026.001','2026-09-12','Published','Full text','Laboratory','A','Researcher Review',0,'Developed a modified biochar from invasive biomass and tested adsorption of pharmaceutical contaminants in batch and column systems.','The modified material showed higher adsorption performance than the comparator under the reported laboratory conditions.','Potential relevance to sustainable adsorbents and pharmaceutical wastewater treatment.','Field performance, lifecycle impact, long-term regeneration, commercial economics and regulatory readiness are not established.',JSON.stringify(['Water-treatment companies','Environmental regulators','Advanced-materials manufacturers']),'Create industry brief + institutional research story','Low observed amplification'],
    ['n2','inst_northstar','u_n_research','d_env','Low-Energy Membrane Regeneration for Decentralized Water Treatment','Anika Rao et al.','Water Process Engineering','10.demo/nu.2026.010','2026-08-28','Published','Abstract','Laboratory','B','Draft',0,'Tested a lower-energy membrane regeneration protocol for small water-treatment systems.','The protocol reduced regeneration energy in the reported bench-scale experiments.','May be relevant to decentralized treatment and membrane operations.','Bench-scale evidence only; durability and field economics were not evaluated.',JSON.stringify(['Water-treatment operators','Membrane manufacturers']),'Create technical collaboration summary','Mostly scholarly'],
    ['n3','inst_northstar','u_n_admin','d_ai','Semi-Supervised Change Detection for Rapidly Growing Cities','Kabir Shah et al.','Urban AI & Remote Sensing','10.demo/nu.2026.004','2026-09-18','Published','Full text','Validated algorithm / dataset','A','Institutional Review',0,'Introduced a semi-supervised change-detection framework for satellite imagery.','The method improved performance over study baselines while requiring less labeled data.','Potential relevance to urban planning, infrastructure monitoring and geospatial companies.','Operational deployment and transfer across sensors and cities need separate validation.',JSON.stringify(['Municipal corporations','Geospatial companies','Urban planners']),'Create government/industry brief','Low observed amplification'],
    ['n4','inst_northstar','u_n_admin','d_clin','Caregiver Burden and Bidirectional Harm in Dementia Care','Sara Khan et al.','Geriatric Care Research','10.demo/nu.2026.008','2026-09-02','Published','Full text','Cross-sectional human study','A','Enhanced Review',1,'Examined caregiver burden and potentially harmful behaviors within dementia-care dyads.','The study found associations consistent with bidirectional harm in the sampled caregiving relationships.','Relevant to caregiver support, dementia services and public-health policy.','Cross-sectional regional sample; no universal prevalence or causal claim is supported.',JSON.stringify(['Geriatric clinicians','Caregiver organizations','Public-health teams']),'Create sensitive public-health brief after enhanced review','Low observed amplification'],
    ['m1r','inst_meridian','u_m_research','d_mat','Ceramic Composite Electrolytes for Medium-Temperature Energy Storage','Leena Bose et al.','Advanced Energy Materials Demo','10.demo/mis.2026.101','2026-09-10','Published','Full text','Laboratory','A','Researcher Review',0,'Evaluated ceramic composite electrolytes for medium-temperature electrochemical storage.','The best formulation improved conductivity relative to the study comparator.','Potential relevance to stationary energy-storage materials.','Long-duration cycling, manufacturing yield and cost are not established.',JSON.stringify(['Energy-storage manufacturers','Materials researchers']),'Create industry technical brief','Mostly scholarly'],
    ['m2r','inst_meridian','u_m_research','d_bio','Wearable Motion Sensing for Post-Stroke Home Rehabilitation','Leena Bose et al.','Digital Rehabilitation Systems','10.demo/mis.2026.102','2026-08-22','Published','Abstract','Pilot human study','B','Draft',1,'Piloted wearable motion sensing for remote monitoring of home rehabilitation exercises after stroke.','The study demonstrated feasibility signals in the small pilot sample.','Potential relevance to rehabilitation technology and remote care.','Small pilot; clinical efficacy and generalizability are not established.',JSON.stringify(['Rehabilitation clinics','Digital-health teams']),'Create clinical evidence summary','Mostly scholarly']
  ]; rows.forEach(x=>insR.run(...x));
  const insO=db.prepare('INSERT INTO opportunity_assessments(research_output_id,dimension,rating,confidence,rationale) VALUES(?,?,?,?,?)');
  const dims={
    n1:[['Industry','Very High','High','Direct relevance to water treatment and adsorbent sectors.'],['Policy','High','Medium','Potential relevance to pharmaceutical-residue management.'],['Media','High','High','Accessible problem-to-solution narrative.'],['Public','High','High','Water pollution is broadly understandable.']],
    n3:[['Industry','Very High','High','Direct geospatial and infrastructure-monitoring relevance.'],['Policy','Very High','High','Urban planning and disaster-management use cases.'],['Media','High','Medium','AI plus cities is accessible but utility must not be overstated.']],
    n4:[['Clinical','High','High','Direct caregiver and geriatric-care relevance.'],['Policy','High','Medium','Potential caregiver-support implications.'],['Media','Moderate','Medium','Sensitive topic requires careful framing.']],
    m1r:[['Industry','Very High','High','Potential energy-storage materials relevance.'],['Academic','High','High','Materials-science collaboration relevance.']],
    m2r:[['Clinical','High','Medium','Remote rehabilitation relevance at pilot stage.'],['Industry','Moderate','Medium','Potential digital-health relevance.']]
  };
  for(const [rid,arr] of Object.entries(dims)) for(const d of arr) insO.run(rid,...d);
}

export function sessionFromToken(db, token){
  if(!token) return null;
  const row=db.prepare(`SELECT s.*,u.email,u.display_name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at > datetime('now')`).get(tokenHash(token));
  if(!row) return null;
  const membership=db.prepare(`SELECT m.*,i.name institution_name,i.short_code FROM memberships m JOIN institutions i ON i.id=m.institution_id WHERE m.user_id=? AND m.institution_id=? AND m.active=1`).get(row.user_id,row.active_institution_id);
  if(!membership) return null;
  const institutions=db.prepare(`SELECT i.id,i.name,i.short_code,m.role FROM memberships m JOIN institutions i ON i.id=m.institution_id WHERE m.user_id=? AND m.active=1 ORDER BY i.name`).all(row.user_id);
  return {...row, membership, institutions};
}

export function createSession(db,userId,institutionId){
  const token=crypto.randomBytes(32).toString('base64url');
  const expires=new Date(Date.now()+8*60*60*1000).toISOString().replace('T',' ').replace('Z','');
  db.prepare('INSERT INTO sessions(token_hash,user_id,active_institution_id,expires_at) VALUES(?,?,?,?)').run(tokenHash(token),userId,institutionId,expires);
  return token;
}

export function audit(db,session,action,entityType=null,entityId=null,metadata={}){
  db.prepare('INSERT INTO audit_events(institution_id,user_id,action,entity_type,entity_id,metadata_json) VALUES(?,?,?,?,?,?)').run(session.active_institution_id,session.user_id,action,entityType,entityId,JSON.stringify(metadata));
}
