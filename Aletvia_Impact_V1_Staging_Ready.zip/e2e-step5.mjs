import http from 'node:http';import fs from 'node:fs';import {createAppServer} from './server.js';
function req(port,method,url,body,cookie){return new Promise((resolve,reject)=>{const data=body?JSON.stringify(body):null;const r=http.request({hostname:'127.0.0.1',port,path:url,method,headers:{...(data?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)}:{}),...(cookie?{Cookie:cookie}:{})}},res=>{let raw='';res.setEncoding('utf8');res.on('data',d=>raw+=d);res.on('end',()=>{let json={};try{json=JSON.parse(raw)}catch{}resolve({status:res.statusCode,headers:res.headers,json})})});r.on('error',reject);if(data)r.write(data);r.end()})}
const server=createAppServer(':memory:');await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;try{
 const l=await req(port,'POST','/api/auth/login',{email:'researcher@northstar.edu',password:'DemoPass!2026'});const cookie=String(l.headers['set-cookie'][0]).split(';')[0];
 const adminLogin=await req(port,'POST','/api/auth/login',{email:'admin@northstar.edu',password:'DemoPass!2026'});const admin=String(adminLogin.headers['set-cookie'][0]).split(';')[0];
 const pdf=fs.readFileSync('./fixtures/step3/sample-paper.pdf');
 const ing=await req(port,'POST','/api/ingest/pdf',{filename:'sample-paper.pdf',content_base64:pdf.toString('base64'),analyze:true},cookie);
 const pack=await req(port,'POST','/api/content-packs/generate',{research_output_id:ing.json.research_output_id,pack_name:'Public Impact Pack',branding:{primary_brand:'Northstar University',aletvia_attribution:'Powered by Aletvia',watermark_mode:'subtle'}},cookie);
 const verified=[];for(const a of pack.json.assets){const f=await req(port,'POST','/api/fidelity/verify',{asset_id:a.id},cookie);verified.push({type:a.asset_type,family:a.asset_family,status:f.json.overall_status,eligible:f.json.approval_eligible,claims:f.json.claims?.length,unsupported:f.json.verification?.report?.counts?.unsupported})}
 const chosen=pack.json.assets.find(a=>a.asset_type==='Plain-language summary')||pack.json.assets[0];
 await req(port,'POST',`/api/communication-assets/${encodeURIComponent(chosen.id)}/submit`,{},cookie);
 const approved=await req(port,'PATCH',`/api/communication-assets/${encodeURIComponent(chosen.id)}/status`,{status:'Approved'},admin);
 console.log(JSON.stringify({research_output_id:ing.json.research_output_id,pack:pack.json.pack_name,asset_count:pack.json.assets.length,verified,final_approval_http_status:approved.status,final_asset_status:approved.json.status||null},null,2));
}finally{server.close()}
