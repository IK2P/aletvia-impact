export const audienceEnum=['Public','Industry','Policy','Media','Clinical','Academic'];
export const assetFamilyEnum=['Text','Visual','Motion','Learning'];

export const assetCatalog={
  Text:[
    'Research summary','Plain-language summary','Executive summary','Institutional research story','LinkedIn post','Media pitch','Industry brief','Policy brief','Clinical evidence summary','Collaboration summary','Researcher Q&A'
  ],
  Visual:[
    'Graphical abstract','Scientific diagram','Research poster','Public research poster','WhatsApp share card','WhatsApp status / wallpaper','Social media card','Carousel','Presentation slide'
  ],
  Motion:[
    'Research Flash','Video Abstract','Research Explainer'
  ],
  Learning:[
    'Flashcards','Key takeaways','FAQ','Glossary','Myth vs Evidence','Journal club questions'
  ]
};
export const assetTypeEnum=Object.values(assetCatalog).flat();

const claimLedgerSchema={
  type:'array',items:{
    type:'object',additionalProperties:false,
    properties:{
      claim:{type:'string'},
      basis_type:{type:'string',enum:['paper_supported','aletvia_inferred','mixed']},
      basis_reference:{type:'string'},
      risk_note:{type:'string'}
    },required:['claim','basis_type','basis_reference','risk_note']
  }
};
const visualBlockSchema={type:'object',additionalProperties:false,properties:{role:{type:'string'},label:{type:'string'},text:{type:'string'},evidence_role:{type:'string',enum:['paper_supported','aletvia_inferred','mixed','decorative']}},required:['role','label','text','evidence_role']};
const storyboardSceneSchema={type:'object',additionalProperties:false,properties:{start_seconds:{type:'number'},end_seconds:{type:'number'},visual_direction:{type:'string'},narration:{type:'string'},on_screen_text:{type:'string'},evidence_role:{type:'string',enum:['paper_supported','aletvia_inferred','mixed','decorative']}},required:['start_seconds','end_seconds','visual_direction','narration','on_screen_text','evidence_role']};
const learningCardSchema={type:'object',additionalProperties:false,properties:{front:{type:'string'},back:{type:'string'},evidence_role:{type:'string',enum:['paper_supported','aletvia_inferred','mixed']}},required:['front','back','evidence_role']};

export const communicationAssetSchema={
  type:'object',additionalProperties:false,
  properties:{
    audience:{type:'string',enum:audienceEnum},
    asset_family:{type:'string',enum:assetFamilyEnum},
    asset_type:{type:'string',enum:assetTypeEnum},
    headline:{type:'string'},
    dek:{type:'string'},
    body_markdown:{type:'string'},
    key_messages:{type:'array',items:{type:'string'}},
    evidence_boundary:{type:'string'},
    suggested_call_to_action:{type:'string'},
    channel_targets:{type:'array',items:{type:'string'}},
    format_spec:{
      type:'object',additionalProperties:false,
      properties:{aspect_ratio:{type:'string'},orientation:{type:'string'},recommended_dimensions:{type:'string'},share_context:{type:'string'}},
      required:['aspect_ratio','orientation','recommended_dimensions','share_context']
    },
    branding_spec:{
      type:'object',additionalProperties:false,
      properties:{primary_brand:{type:'string'},department_line:{type:'string'},aletvia_attribution:{type:'string'},logo_placement:{type:'string'},qr_target:{type:'string'},watermark_mode:{type:'string',enum:['visible','subtle','white_label']},asset_id_label:{type:'string'}},
      required:['primary_brand','department_line','aletvia_attribution','logo_placement','qr_target','watermark_mode','asset_id_label']
    },
    visual_spec:{
      type:'object',additionalProperties:false,
      properties:{design_goal:{type:'string'},visual_metaphor:{type:'string'},layout_blocks:{type:'array',items:visualBlockSchema},diagram_semantics:{type:'array',items:{type:'string'}},alt_text:{type:'string'}},
      required:['design_goal','visual_metaphor','layout_blocks','diagram_semantics','alt_text']
    },
    motion_spec:{
      type:'object',additionalProperties:false,
      properties:{duration_seconds:{type:'number'},voiceover_script:{type:'string'},captions:{type:'array',items:{type:'string'}},storyboard:{type:'array',items:storyboardSceneSchema}},
      required:['duration_seconds','voiceover_script','captions','storyboard']
    },
    learning_spec:{
      type:'object',additionalProperties:false,
      properties:{cards:{type:'array',items:learningCardSchema},questions:{type:'array',items:{type:'string'}},glossary_items:{type:'array',items:{type:'string'}}},
      required:['cards','questions','glossary_items']
    },
    claim_ledger:claimLedgerSchema,
    generation_notes:{type:'array',items:{type:'string'}}
  },
  required:['audience','asset_family','asset_type','headline','dek','body_markdown','key_messages','evidence_boundary','suggested_call_to_action','channel_targets','format_spec','branding_spec','visual_spec','motion_spec','learning_spec','claim_ledger','generation_notes']
};

export const packCatalog={
  'Quick Share Pack':[
    {audience:'Public',asset_type:'Research summary'},
    {audience:'Public',asset_type:'WhatsApp share card'},
    {audience:'Public',asset_type:'LinkedIn post'},
    {audience:'Academic',asset_type:'Presentation slide'}
  ],
  'Public Impact Pack':[
    {audience:'Public',asset_type:'Plain-language summary'},
    {audience:'Public',asset_type:'Graphical abstract'},
    {audience:'Public',asset_type:'WhatsApp status / wallpaper'},
    {audience:'Public',asset_type:'Carousel'},
    {audience:'Public',asset_type:'Video Abstract'}
  ],
  'Industry Pack':[
    {audience:'Industry',asset_type:'Executive summary'},
    {audience:'Industry',asset_type:'Industry brief'},
    {audience:'Industry',asset_type:'Scientific diagram'},
    {audience:'Industry',asset_type:'Presentation slide'},
    {audience:'Industry',asset_type:'LinkedIn post'}
  ],
  'Policy Pack':[
    {audience:'Policy',asset_type:'Research summary'},
    {audience:'Policy',asset_type:'Policy brief'},
    {audience:'Policy',asset_type:'Graphical abstract'},
    {audience:'Policy',asset_type:'Presentation slide'}
  ],
  'Academic Pack':[
    {audience:'Academic',asset_type:'Research summary'},
    {audience:'Academic',asset_type:'Graphical abstract'},
    {audience:'Academic',asset_type:'Presentation slide'},
    {audience:'Academic',asset_type:'Flashcards'},
    {audience:'Academic',asset_type:'Collaboration summary'}
  ],
  'Media Pack':[
    {audience:'Media',asset_type:'Institutional research story'},
    {audience:'Media',asset_type:'Media pitch'},
    {audience:'Media',asset_type:'Researcher Q&A'},
    {audience:'Media',asset_type:'Social media card'},
    {audience:'Media',asset_type:'Video Abstract'}
  ]
};
