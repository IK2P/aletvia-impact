import crypto from 'node:crypto';

function ensureColumn(db,table,column,ddl){const cols=db.prepare(`PRAGMA table_info(${table})`).all().map(x=>x.name);if(!cols.includes(column))db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`)}
export function ensureStep4Schema(db){
 db.exec(`
 CREATE TABLE IF NOT EXISTS communication_assets (
   id TEXT PRIMARY KEY,
   institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
   research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
   created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
   audience TEXT NOT NULL,
   asset_family TEXT NOT NULL DEFAULT 'Text',
   asset_type TEXT NOT NULL,
   content_pack_id TEXT,
   status TEXT NOT NULL DEFAULT 'Draft' CHECK(status IN ('Draft','Researcher Approved','Institutional Review','Approved','Revision Requested','Declined')),
   created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
   updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 );
 CREATE TABLE IF NOT EXISTS communication_asset_versions (
   id TEXT PRIMARY KEY,
   asset_id TEXT NOT NULL REFERENCES communication_assets(id) ON DELETE CASCADE,
   version_number INTEGER NOT NULL,
   content_json TEXT NOT NULL,
   body_markdown TEXT NOT NULL,
   generation_mode TEXT NOT NULL,
   provider TEXT NOT NULL,
   model TEXT NOT NULL,
   prompt_version TEXT NOT NULL,
   context_fingerprint_sha256 TEXT NOT NULL,
   source_fingerprint_sha256 TEXT NOT NULL DEFAULT '',
   revision_instruction TEXT NOT NULL DEFAULT '',
   created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
   created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
   UNIQUE(asset_id,version_number)
 );
 CREATE TABLE IF NOT EXISTS content_packs (
   id TEXT PRIMARY KEY,
   institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
   research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
   pack_name TEXT NOT NULL,
   created_by_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
   status TEXT NOT NULL DEFAULT 'Draft',
   created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
   updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 );
 CREATE INDEX IF NOT EXISTS idx_comm_assets_tenant ON communication_assets(institution_id,research_output_id);
 CREATE INDEX IF NOT EXISTS idx_comm_versions_asset ON communication_asset_versions(asset_id,version_number DESC);
 CREATE INDEX IF NOT EXISTS idx_content_packs_tenant ON content_packs(institution_id,research_output_id);
 `);
 ensureColumn(db,'communication_assets','asset_family',"TEXT NOT NULL DEFAULT 'Text'");
 ensureColumn(db,'communication_assets','content_pack_id','TEXT');
}

function latestVersion(db,assetId){return db.prepare(`SELECT * FROM communication_asset_versions WHERE asset_id=? ORDER BY version_number DESC LIMIT 1`).get(assetId)}
function assetRow(db,assetId,institutionId){return db.prepare(`SELECT a.*,r.title research_title,r.owner_user_id,r.sensitive research_sensitive,u.display_name owner_name FROM communication_assets a JOIN research_outputs r ON r.id=a.research_output_id JOIN users u ON u.id=r.owner_user_id WHERE a.id=? AND a.institution_id=?`).get(assetId,institutionId)}
export function serializeAsset(db,row){
 if(!row)return null;const v=latestVersion(db,row.id);let content=null;try{content=v?JSON.parse(v.content_json):null}catch{}
 return {id:row.id,institution_id:row.institution_id,research_output_id:row.research_output_id,research_title:row.research_title,owner_user_id:row.owner_user_id,owner_name:row.owner_name,research_sensitive:!!row.research_sensitive,audience:row.audience,asset_family:row.asset_family||content?.asset_family||'Text',asset_type:row.asset_type,content_pack_id:row.content_pack_id||null,status:row.status,created_at:row.created_at,updated_at:row.updated_at,latest_version:v?{id:v.id,version_number:v.version_number,content,body_markdown:v.body_markdown,generation_mode:v.generation_mode,provider:v.provider,model:v.model,prompt_version:v.prompt_version,context_fingerprint_sha256:v.context_fingerprint_sha256,source_fingerprint_sha256:v.source_fingerprint_sha256,revision_instruction:v.revision_instruction,created_at:v.created_at}:null};
}
export function getAsset(db,institutionId,assetId){return serializeAsset(db,assetRow(db,assetId,institutionId))}
export function listAssets(db,session,{research_output_id,content_pack_id}={}){
 let sql=`SELECT a.*,r.title research_title,r.owner_user_id,r.sensitive research_sensitive,u.display_name owner_name FROM communication_assets a JOIN research_outputs r ON r.id=a.research_output_id JOIN users u ON u.id=r.owner_user_id WHERE a.institution_id=?`;const args=[session.active_institution_id];
 if(session.membership.role==='researcher'){sql+=' AND r.owner_user_id=?';args.push(session.user_id)}
 if(research_output_id){sql+=' AND a.research_output_id=?';args.push(research_output_id)}
 if(content_pack_id){sql+=' AND a.content_pack_id=?';args.push(content_pack_id)}
 sql+=' ORDER BY a.updated_at DESC';return db.prepare(sql).all(...args).map(r=>serializeAsset(db,r));
}
export function createContentPack(db,session,{research_output_id,pack_name}){const id=`cp_${crypto.randomUUID()}`;db.prepare(`INSERT INTO content_packs(id,institution_id,research_output_id,pack_name,created_by_user_id,status) VALUES(?,?,?,?,?,'Draft')`).run(id,session.active_institution_id,research_output_id,pack_name,session.user_id);return id}
export function serializePack(db,row,session){if(!row)return null;return {...row,assets:listAssets(db,session,{content_pack_id:row.id})}}
export function getContentPack(db,session,id){const row=db.prepare(`SELECT * FROM content_packs WHERE id=? AND institution_id=?`).get(id,session.active_institution_id);if(!row)return null;const research=db.prepare(`SELECT owner_user_id FROM research_outputs WHERE id=? AND institution_id=?`).get(row.research_output_id,session.active_institution_id);if(session.membership.role==='researcher'&&research?.owner_user_id!==session.user_id)return null;return serializePack(db,row,session)}
export function listContentPacks(db,session,{research_output_id}={}){let sql=`SELECT p.* FROM content_packs p JOIN research_outputs r ON r.id=p.research_output_id WHERE p.institution_id=?`;const args=[session.active_institution_id];if(session.membership.role==='researcher'){sql+=' AND r.owner_user_id=?';args.push(session.user_id)}if(research_output_id){sql+=' AND p.research_output_id=?';args.push(research_output_id)}sql+=' ORDER BY p.updated_at DESC';return db.prepare(sql).all(...args).map(r=>serializePack(db,r,session))}
export function createGeneratedAsset(db,session,{research_output_id,audience,asset_family,asset_type,generation,revision_instruction='',content_pack_id=null}){
 const id=`ca_${crypto.randomUUID()}`;db.prepare(`INSERT INTO communication_assets(id,institution_id,research_output_id,created_by_user_id,audience,asset_family,asset_type,content_pack_id,status) VALUES(?,?,?,?,?,?,?,?,'Draft')`).run(id,session.active_institution_id,research_output_id,session.user_id,audience,asset_family||generation.asset.asset_family||'Text',asset_type,content_pack_id);
 addVersion(db,session,id,generation,revision_instruction);return getAsset(db,session.active_institution_id,id);
}
export function addVersion(db,session,assetId,generation,revision_instruction=''){
 const a=assetRow(db,assetId,session.active_institution_id);if(!a)throw new Error('Communication/content asset not found.');
 const n=(db.prepare('SELECT coalesce(max(version_number),0)+1 n FROM communication_asset_versions WHERE asset_id=?').get(assetId).n);
 const c=generation.asset;db.prepare(`INSERT INTO communication_asset_versions(id,asset_id,version_number,content_json,body_markdown,generation_mode,provider,model,prompt_version,context_fingerprint_sha256,source_fingerprint_sha256,revision_instruction,created_by_user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(`cv_${crypto.randomUUID()}`,assetId,n,JSON.stringify(c),c.body_markdown,generation.engine.mode,generation.engine.provider,generation.engine.model,generation.engine.prompt_version,generation.provenance.context_fingerprint_sha256,generation.provenance.source_fingerprint_sha256||'',revision_instruction||'',session.user_id);
 db.prepare(`UPDATE communication_assets SET updated_at=CURRENT_TIMESTAMP,status=CASE WHEN status='Approved' THEN 'Draft' ELSE status END WHERE id=?`).run(assetId);if(a.content_pack_id)db.prepare(`UPDATE content_packs SET updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(a.content_pack_id);return getAsset(db,session.active_institution_id,assetId);
}
export function addManualVersion(db,session,assetId,{body_markdown}){
 const a=getAsset(db,session.active_institution_id,assetId);if(!a)throw new Error('Communication/content asset not found.');if(!body_markdown||body_markdown.trim().length<20)throw new Error('Edited content is too short.');
 const prior=structuredClone(a.latest_version.content);prior.body_markdown=body_markdown;prior.generation_notes=[...(prior.generation_notes||[]),'Manually edited after AI generation; Step 5 must re-check changed claims, labels, captions and visual/video semantics before approval.'];
 const fake={asset:prior,engine:{mode:'manual-edit',provider:'human',model:'human',prompt_version:a.latest_version.prompt_version},provenance:{context_fingerprint_sha256:a.latest_version.context_fingerprint_sha256,source_fingerprint_sha256:a.latest_version.source_fingerprint_sha256}};return addVersion(db,session,assetId,fake,'Manual edit');
}
export function setAssetStatus(db,session,assetId,status){const allowed=['Draft','Researcher Approved','Institutional Review','Approved','Revision Requested','Declined'];if(!allowed.includes(status))throw new Error('Invalid communication/content asset status.');const a=assetRow(db,assetId,session.active_institution_id);if(!a)throw new Error('Communication/content asset not found.');db.prepare('UPDATE communication_assets SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,assetId);return getAsset(db,session.active_institution_id,assetId)}
