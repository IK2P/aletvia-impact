import { audienceEnum, assetFamilyEnum, assetTypeEnum, assetCatalog } from './schemas.js';
const basis=['paper_supported','aletvia_inferred','mixed'];
function req(cond,msg){if(!cond)throw new Error(`RCC asset validation failed: ${msg}`)}
export function validateCommunicationAsset(x,{audience,asset_family,asset_type}={}){
 req(x&&typeof x==='object','asset must be object');
 req(audienceEnum.includes(x.audience),'invalid audience');
 req(assetFamilyEnum.includes(x.asset_family),'invalid asset family');
 req(assetTypeEnum.includes(x.asset_type),'invalid asset type');
 req(assetCatalog[x.asset_family]?.includes(x.asset_type),'asset type does not belong to selected family');
 if(audience)req(x.audience===audience,'audience mismatch');if(asset_family)req(x.asset_family===asset_family,'asset family mismatch');if(asset_type)req(x.asset_type===asset_type,'asset type mismatch');
 for(const k of ['headline','dek','body_markdown','evidence_boundary','suggested_call_to_action'])req(typeof x[k]==='string',`${k} missing`);
 req(x.body_markdown.trim().length>=40,'body too short');
 req(Array.isArray(x.key_messages),'key_messages must be array');req(Array.isArray(x.channel_targets),'channel_targets must be array');
 for(const o of ['format_spec','branding_spec','visual_spec','motion_spec','learning_spec'])req(x[o]&&typeof x[o]==='object',`${o} missing`);
 req(Array.isArray(x.visual_spec.layout_blocks),'visual layout_blocks required');req(Array.isArray(x.visual_spec.diagram_semantics),'diagram_semantics required');
 req(Array.isArray(x.motion_spec.storyboard),'motion storyboard required');req(Array.isArray(x.motion_spec.captions),'motion captions required');
 req(Array.isArray(x.learning_spec.cards),'learning cards required');req(Array.isArray(x.learning_spec.questions),'learning questions required');req(Array.isArray(x.learning_spec.glossary_items),'learning glossary required');
 if(x.asset_family==='Visual')req(x.visual_spec.layout_blocks.length>0,'visual asset needs layout blocks');
 if(x.asset_family==='Motion'){req(x.motion_spec.duration_seconds>0,'motion asset needs duration');req(x.motion_spec.storyboard.length>0,'motion asset needs storyboard')}
 if(x.asset_family==='Learning')req(x.learning_spec.cards.length+x.learning_spec.questions.length+x.learning_spec.glossary_items.length>0,'learning asset needs learning content');
 req(Array.isArray(x.claim_ledger)&&x.claim_ledger.length>0,'claim_ledger required');
 for(const c of x.claim_ledger){req(typeof c.claim==='string'&&c.claim.trim(),'claim missing');req(basis.includes(c.basis_type),'invalid claim basis');req(typeof c.basis_reference==='string','basis_reference missing');req(typeof c.risk_note==='string','risk_note missing')}
 req(Array.isArray(x.generation_notes),'generation_notes must be array');return x;
}
