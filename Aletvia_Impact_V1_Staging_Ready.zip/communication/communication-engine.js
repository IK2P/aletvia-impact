import { createHash } from 'node:crypto';
import { generateWithOpenAI } from './openai-provider.js';
import { generateWithLocalDemo } from './local-demo-provider.js';
import { validateCommunicationAsset } from './validate.js';
import { audienceEnum, assetFamilyEnum, assetTypeEnum, assetCatalog, packCatalog } from './schemas.js';

const FAMILY_BY_TYPE=Object.fromEntries(Object.entries(assetCatalog).flatMap(([family,types])=>types.map(t=>[t,family])));
const FORMAT_BY_AUDIENCE={
 Public:['Research summary','Plain-language summary','Institutional research story','LinkedIn post','Graphical abstract','Public research poster','WhatsApp share card','WhatsApp status / wallpaper','Social media card','Carousel','Presentation slide','Research Flash','Video Abstract','Research Explainer','Flashcards','Key takeaways','FAQ','Glossary','Myth vs Evidence'],
 Industry:['Research summary','Executive summary','Industry brief','LinkedIn post','Graphical abstract','Scientific diagram','Research poster','WhatsApp share card','Social media card','Presentation slide','Research Flash','Video Abstract','Key takeaways','FAQ'],
 Policy:['Research summary','Executive summary','Policy brief','Graphical abstract','Scientific diagram','Public research poster','WhatsApp share card','Presentation slide','Video Abstract','Key takeaways','FAQ','Glossary'],
 Media:['Research summary','Institutional research story','Media pitch','Researcher Q&A','Graphical abstract','Public research poster','WhatsApp share card','WhatsApp status / wallpaper','Social media card','Carousel','Presentation slide','Research Flash','Video Abstract','Research Explainer','FAQ'],
 Clinical:['Research summary','Clinical evidence summary','Researcher Q&A','Graphical abstract','Scientific diagram','Research poster','Presentation slide','Video Abstract','Flashcards','Key takeaways','FAQ','Glossary','Journal club questions'],
 Academic:['Research summary','Executive summary','Collaboration summary','LinkedIn post','Graphical abstract','Scientific diagram','Research poster','Presentation slide','Video Abstract','Flashcards','Key takeaways','FAQ','Glossary','Myth vs Evidence','Journal club questions']
};
export function assetFamily(assetType){return FAMILY_BY_TYPE[assetType]||null}
export function allowedAssetTypes(audience){return FORMAT_BY_AUDIENCE[audience]||[]}
export function allowedAssetFamilies(audience){return [...new Set(allowedAssetTypes(audience).map(assetFamily).filter(Boolean))]}
export function contentPacks(){return packCatalog}
export function contextFingerprint({research,intelligence,audience,asset_family,asset_type,branding={}}){return createHash('sha256').update(JSON.stringify({research_id:research.id,title:research.title,intelligence_schema:intelligence?.schema_version||'',intelligence_fingerprint:intelligence?.provenance?.source_fingerprint_sha256||'',audience,asset_family,asset_type,branding})).digest('hex')}
export async function generateCommunicationAsset(ctx,config={}){
 if(!ctx?.research?.id)throw new Error('Research object is required.');
 if(!ctx.intelligence)throw new Error('A Research Intelligence Record is required before communication/content generation.');
 if(!audienceEnum.includes(ctx.audience))throw new Error('Unsupported audience.');
 if(!assetTypeEnum.includes(ctx.asset_type)||!allowedAssetTypes(ctx.audience).includes(ctx.asset_type))throw new Error('Asset type is not valid for the selected audience.');
 const family=ctx.asset_family||assetFamily(ctx.asset_type);if(!assetFamilyEnum.includes(family))throw new Error('Unsupported asset family.');
 if(assetFamily(ctx.asset_type)!==family)throw new Error('Asset family does not match asset type.');
 const normalized={...ctx,asset_family:family};
 const mode=config.mode||process.env.ALETVIA_COMM_MODE||(process.env.OPENAI_API_KEY?'openai':'local-demo');
 const out=mode==='openai'?await generateWithOpenAI(normalized,config):await generateWithLocalDemo(normalized);
 validateCommunicationAsset(out.asset,{audience:normalized.audience,asset_family:family,asset_type:normalized.asset_type});
 return {schema_version:'1.1',generated_at:new Date().toISOString(),engine:{pipeline_version:'rcc-v1',prompt_version:'1.1',provider:out.provider,model:out.model,mode},provenance:{research_output_id:normalized.research.id,research_intelligence_schema_version:normalized.intelligence.schema_version||'',source_fingerprint_sha256:normalized.intelligence?.provenance?.source_fingerprint_sha256||'',context_fingerprint_sha256:contextFingerprint(normalized)},asset:out.asset};
}
export async function generateContentPack(ctx,packName,config={}){
 const defs=packCatalog[packName];if(!defs)throw new Error('Unsupported content pack.');
 const assets=[];for(const def of defs){assets.push(await generateCommunicationAsset({...ctx,...def,asset_family:assetFamily(def.asset_type)},config))}
 return {pack_name:packName,generated_at:new Date().toISOString(),assets};
}
