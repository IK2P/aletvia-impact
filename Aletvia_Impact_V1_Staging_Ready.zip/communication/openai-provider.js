import { communicationAssetSchema } from './schemas.js';
import { COMMUNICATION_SYSTEM_PROMPT, buildCommunicationPrompt } from './prompts.js';

function extractResponseText(json){
 if(typeof json.output_text==='string'&&json.output_text.trim())return json.output_text;
 for(const item of json.output||[])for(const c of item.content||[])if(typeof c.text==='string'&&c.text.trim())return c.text;
 throw new Error('OpenAI response did not contain structured output text.');
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export async function generateWithOpenAI(ctx,config={}){
 const apiKey=config.apiKey||process.env.OPENAI_API_KEY;if(!apiKey)throw new Error('OPENAI_API_KEY is not configured.');
 const model=config.model||process.env.OPENAI_COMM_MODEL||process.env.OPENAI_MODEL||'gpt-5.6-terra';
 let last;
 for(let attempt=1;attempt<=3;attempt++){
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),90000);
  try{
   const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal:controller.signal,headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model,store:false,input:[{role:'system',content:[{type:'input_text',text:COMMUNICATION_SYSTEM_PROMPT}]},{role:'user',content:[{type:'input_text',text:buildCommunicationPrompt(ctx)}]}],text:{format:{type:'json_schema',name:'aletvia_communication_asset',strict:true,schema:communicationAssetSchema}}})});
   const json=await response.json();
   if(!response.ok){const msg=json?.error?.message||`OpenAI request failed with ${response.status}`;if((response.status===429||response.status>=500)&&attempt<3){last=new Error(msg);await sleep(500*attempt);continue}throw new Error(msg)}
   if(json.status==='incomplete')throw new Error(`OpenAI response incomplete: ${json.incomplete_details?.reason||'unknown reason'}`);
   const refusal=(json.output||[]).flatMap(x=>x.content||[]).find(c=>c.type==='refusal');if(refusal)throw new Error(`Model refused generation: ${refusal.refusal||'unspecified'}`);
   return {asset:JSON.parse(extractResponseText(json)),provider:'openai',model};
  }catch(e){last=e?.name==='AbortError'?new Error('OpenAI communication request timed out after 90000 ms.'):e;if(attempt<3&&/fetch|network|timed out/i.test(last.message)){await sleep(500*attempt);continue}throw last}finally{clearTimeout(timer)}
 }
 throw last||new Error('Communication generation failed.');
}
