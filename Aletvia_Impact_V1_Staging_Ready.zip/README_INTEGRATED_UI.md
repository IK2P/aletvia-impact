# Aletvia Impact — Integrated UI + Frozen Step 1–6 Backend

## What this build is
This package wires the polished ten-page university demo UI to the existing frozen Step 1–6 backend contracts.

Real connected flow:

**PDF / DOI / ORCID ingestion → Research Intelligence → RCC Content Pack → Scientific Fidelity → Researcher sign-off → Institutional Governance → Ready for Activation → live tenant dashboard**

The following remain intentionally simulated/deferred because they were outside the frozen pilot scope:
- final pixel rendering of graphical assets;
- final MP4 rendering;
- external publishing / social posting / stakeholder outreach.

## Run locally
Requires Node.js with `node:sqlite` support (Node 22+ recommended).

### Windows
Double-click `START_ALETVIA_WINDOWS.bat`, or run:

```bat
node server.js
```

Then open:

`http://127.0.0.1:8787`

### macOS/Linux

```bash
node server.js
```

Open `http://127.0.0.1:8787`.

The database is created and seeded automatically on first start.

## Demo accounts
Password for all accounts: `DemoPass!2026`

- Institution Admin: `admin@northstar.edu`
- Researcher: `researcher@northstar.edu`
- Communications Reviewer: `communications@northstar.edu`

The integrated UI provides one-click role switching among those demo accounts.

## Recommended live demo
1. **Import Research** → click **Run bundled sample PDF**.
2. **RCC Studio** → click **Generate Public Impact Pack**.
3. **Content Pack** → select the Plain-language Summary.
4. **Fidelity Review** → run Step 5.
5. **Researcher sign-off** → the UI switches to the researcher account and creates the Step-6 case.
6. **Governance Case** → Communications approve.
7. The case reaches **Ready for Activation**.
8. Open **Impact Dashboard** for live tenant metrics.

## Validation performed
- Frozen backend regression suite: **53/53 passing**.
- Fresh-database HTTP acceptance flow: **PASS**.
- Five RCC assets generated in Public Impact Pack.
- Selected asset Step-5 report: **Pass with cautions**, approval eligible, 12 claims.
- Researcher sign-off → **Communications Review**.
- Communications approval → **Ready for Activation**.
- Final blockers: **0**.
- All ten integrated UI routes render in Chromium via injected static-browser QA.
- 390px mobile: no horizontal overflow; navigation drawer opens.

### Environment limitation during QA
The container's Chromium policy blocks direct navigation to `localhost` and `file://` URLs (`ERR_BLOCKED_BY_ADMINISTRATOR`). Therefore:
- live end-to-end behavior was tested through the real HTTP API server; and
- UI browser rendering/navigation/mobile behavior was tested in Chromium by injecting the exact integrated HTML/CSS/JS into the page.

This limitation is specific to the QA container and does not affect normal local use.
