import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { analyzeResearch } from '../engine/research-intelligence-engine.js';

const CROSSREF_BASE='https://api.crossref.org';
const ORCID_BASE='https://pub.orcid.org/v3.0';
const MAX_PDF_BYTES=15*1024*1024;
const MAX_ORCID_WORKS=100;

export function normalizeDoi(input=''){
  let s=String(input).trim();
  s=s.replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').replace(/^doi:\s*/i,'').trim();
  try{s=decodeURIComponent(s)}catch{}
  return s.toLowerCase();
}
export function looksLikeDoi(doi=''){return /^10\.\d{4,9}\/[\S]+$/i.test(normalizeDoi(doi));}
export function normalizeTitleKey(title=''){
  return String(title).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
}
export function sha256(data){return crypto.createHash('sha256').update(data).digest('hex');}
export function normalizeOrcid(input=''){
  const m=String(input).trim().match(/(?:https?:\/\/orcid\.org\/)?(\d{4}-\d{4}-\d{4}-[\dXx]{4})/);
  return m?m[1].toUpperCase():'';
}
export function isValidOrcid(input=''){
  const id=normalizeOrcid(input); if(!id)return false;
  const digits=id.replace(/-/g,''); let total=0;
  for(let i=0;i<15;i++) total=(total+Number(digits[i]))*2;
  const result=(12-(total%11))%11; const check=result===10?'X':String(result);
  return check===digits[15];
}

function first(v){return Array.isArray(v)?(v[0]??''):(v??'')}
function decodeEntities(s=''){return String(s).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&nbsp;/g,' ')}
export function stripMarkup(s=''){return decodeEntities(String(s||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim())}
function dateFromParts(x){const p=x?.['date-parts']?.[0];if(!Array.isArray(p)||!p.length)return null;const [y,m=1,d=1]=p;return `${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`}
function authorName(a={}){return [a.given,a.family].filter(Boolean).join(' ').trim()||a.name||'Unknown author'}
function crossrefSourceText(m){
  const abs=stripMarkup(m.abstract||'');
  if(abs.length>=80)return abs;
  const bits=[first(m.title),abs,first(m['container-title']),m.type?`Work type: ${m.type}`:''].filter(Boolean);
  return bits.join('\n\n');
}
export function crossrefToCanonical(m){
  const title=stripMarkup(first(m.title)||'Untitled research');
  const doi=normalizeDoi(m.DOI||'');
  const authors=(m.author||[]).map(authorName).filter(Boolean);
  const abstract=stripMarkup(m.abstract||'');
  const publication_date=dateFromParts(m['published-print'])||dateFromParts(m['published-online'])||dateFromParts(m.published)||dateFromParts(m.issued)||null;
  const source_text=crossrefSourceText(m);
  return {
    title,
    authors:authors.join(', ')||'Unknown authors',
    journal:stripMarkup(first(m['container-title'])||first(m['short-container-title'])||''),
    doi,
    publication_date,
    publication_state:'Published',
    evidence_depth:abstract.length>=80?'abstract':'metadata',
    source_text,
    raw_metadata:m,
    source_url:doi?`https://doi.org/${doi}`:'',
    source_identifier:doi||title,
    source_type:'doi'
  };
}

async function fetchJson(url,{headers={},fetchFn=globalThis.fetch,timeoutMs=12000}={}){
  const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    const r=await fetchFn(url,{headers,signal:ctrl.signal});
    if(!r.ok){const e=new Error(`Upstream request failed (${r.status})`);e.status=r.status;throw e;}
    return await r.json();
  }finally{clearTimeout(timer)}
}
export async function fetchCrossrefWork(doi,{fetchFn=globalThis.fetch,mailto=process.env.CROSSREF_MAILTO||''}={}){
  const d=normalizeDoi(doi); if(!looksLikeDoi(d))throw new Error('Please enter a valid DOI.');
  const url=`${CROSSREF_BASE}/works/${encodeURIComponent(d)}${mailto?`?mailto=${encodeURIComponent(mailto)}`:''}`;
  const j=await fetchJson(url,{fetchFn,headers:{'User-Agent':`AletviaResearchImpact/0.3${mailto?` (mailto:${mailto})`:''}`}});
  if(!j?.message)throw new Error('Crossref returned no work metadata.');
  return j.message;
}
export async function fetchCrossrefWorksByOrcid(orcid,{fetchFn=globalThis.fetch,mailto=process.env.CROSSREF_MAILTO||'',limit=25}={}){
  const id=normalizeOrcid(orcid); if(!isValidOrcid(id))throw new Error('Please enter a valid ORCID iD.');
  const rows=Math.max(1,Math.min(MAX_ORCID_WORKS,Number(limit)||25));
  const q=new URLSearchParams({filter:`orcid:${id}`,rows:String(rows),select:'DOI,title,author,container-title,short-container-title,published-print,published-online,published,issued,abstract,type'}); if(mailto)q.set('mailto',mailto);
  const j=await fetchJson(`${CROSSREF_BASE}/works?${q}`,{fetchFn,headers:{'User-Agent':`AletviaResearchImpact/0.3${mailto?` (mailto:${mailto})`:''}`}});
  return j?.message?.items||[];
}
export async function fetchOrcidDoiList(orcid,{fetchFn=globalThis.fetch,token=process.env.ORCID_PUBLIC_TOKEN||'',limit=25}={}){
  const id=normalizeOrcid(orcid); if(!isValidOrcid(id))throw new Error('Please enter a valid ORCID iD.');
  if(!token)return null;
  const j=await fetchJson(`${ORCID_BASE}/${id}/works`,{fetchFn,headers:{Accept:'application/vnd.orcid+json',Authorization:`Bearer ${token}`}});
  const dois=[];
  for(const g of j.group||[]){
    for(const s of g['work-summary']||[]){
      for(const x of s['external-ids']?.['external-id']||[]){
        if(String(x['external-id-type']||'').toLowerCase()==='doi'){
          const d=normalizeDoi(x['external-id-value']||''); if(looksLikeDoi(d)&&!dois.includes(d))dois.push(d);
        }
      }
    }
  }
  return dois.slice(0,Math.max(1,Math.min(MAX_ORCID_WORKS,Number(limit)||25)));
}

function runPdftotext(file){return new Promise((resolve,reject)=>{
  const p=spawn('pdftotext',['-layout','-enc','UTF-8',file,'-'],{stdio:['ignore','pipe','pipe']});let out='',err='';
  p.stdout.setEncoding('utf8');p.stderr.setEncoding('utf8');p.stdout.on('data',d=>{out+=d;if(out.length>2_000_000)p.kill('SIGKILL')});p.stderr.on('data',d=>err+=d);
  p.on('error',reject);p.on('close',code=>code===0?resolve(out):reject(new Error(`PDF text extraction failed${err?`: ${err.trim()}`:''}`)));
})}
export async function extractPdfText(buffer){
  if(!Buffer.isBuffer(buffer)||buffer.length<5||buffer.subarray(0,5).toString()!=='%PDF-')throw new Error('Uploaded file is not a valid PDF.');
  if(buffer.length>MAX_PDF_BYTES)throw new Error(`PDF exceeds the ${Math.round(MAX_PDF_BYTES/1024/1024)} MB Step 3 limit.`);
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'aletvia-pdf-')); const file=path.join(dir,'paper.pdf');fs.writeFileSync(file,buffer);
  try{return (await runPdftotext(file)).replace(/\u0000/g,'').trim()}finally{fs.rmSync(dir,{recursive:true,force:true})}
}
function detectDoi(text=''){
  const matches=String(text).match(/10\.\d{4,9}\/[\w.()/:;+-]+/ig)||[];
  for(const m of matches){const d=normalizeDoi(m.replace(/[),.;]+$/,''));if(looksLikeDoi(d))return d;}return '';
}
function guessPdfTitle(text='',filename='paper.pdf'){
  const lines=String(text).split(/\r?\n/).map(x=>x.trim()).filter(x=>x.length>5&&x.length<260);
  const reject=/^(abstract|introduction|keywords?|doi\b|received\b|accepted\b|published\b|copyright\b)/i;
  const candidate=lines.find(x=>!reject.test(x)&&/[A-Za-z]/.test(x)&&x.split(/\s+/).length>=4);
  return candidate||path.basename(filename,path.extname(filename)).replace(/[_-]+/g,' ').trim()||'Uploaded research paper';
}
export function pdfToCanonical(text,filename='paper.pdf'){
  const title=guessPdfTitle(text,filename); const doi=detectDoi(text);
  return {title,authors:'Authors to confirm',journal:'',doi,publication_date:null,publication_state:'Published',evidence_depth:text.length>=80?'full_text':'metadata',source_text:text,raw_metadata:{filename,detected_doi:doi},source_url:'',source_identifier:doi||sha256(Buffer.from(text)).slice(0,24),source_type:'pdf'};
}

export function resolveOwner(db,session,requestedOwnerId){
  const role=session.membership.role;
  if(role==='researcher'){if(requestedOwnerId&&requestedOwnerId!==session.user_id)throw new Error('Researchers may import research only into their own profile.');return session.user_id;}
  if(!['institution_admin','research_office_reviewer','communications_reviewer'].includes(role))throw new Error('This role cannot import research.');
  const owner=requestedOwnerId||session.user_id;
  const mem=db.prepare(`SELECT user_id FROM memberships WHERE user_id=? AND institution_id=? AND active=1`).get(owner,session.active_institution_id);
  if(!mem)throw new Error('Selected research owner is not a member of the active institution.');
  return owner;
}
function ownerDepartment(db,session,owner){return db.prepare('SELECT department_id FROM memberships WHERE user_id=? AND institution_id=? AND active=1').get(owner,session.active_institution_id)?.department_id||null}
function newId(prefix){return `${prefix}_${crypto.randomUUID()}`}

export function ensureStep3Schema(db){
  const cols=new Set(db.prepare('PRAGMA table_info(research_outputs)').all().map(x=>x.name));
  const add=(name,ddl)=>{if(!cols.has(name)){db.exec(`ALTER TABLE research_outputs ADD COLUMN ${name} ${ddl}`);cols.add(name)}};
  add('title_key',"TEXT NOT NULL DEFAULT ''");
  add('ingestion_status',"TEXT NOT NULL DEFAULT 'ready'");
  add('latest_source_type',"TEXT");
  db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_research_doi_tenant ON research_outputs(institution_id, lower(doi)) WHERE doi IS NOT NULL AND trim(doi)<>'';
    CREATE INDEX IF NOT EXISTS idx_research_titlekey_tenant ON research_outputs(institution_id,title_key);
    CREATE TABLE IF NOT EXISTS ingestion_sources (
      id TEXT PRIMARY KEY, institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
      research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
      source_type TEXT NOT NULL CHECK(source_type IN ('doi','pdf','orcid')),
      source_identifier TEXT NOT NULL, source_url TEXT, content_sha256 TEXT,
      raw_metadata_json TEXT NOT NULL DEFAULT '{}', source_text TEXT NOT NULL DEFAULT '', evidence_depth TEXT NOT NULL,
      imported_by_user_id TEXT NOT NULL REFERENCES users(id), imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(institution_id,source_type,source_identifier)
    );
    CREATE TABLE IF NOT EXISTS research_intelligence_records (
      id TEXT PRIMARY KEY, institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
      research_output_id TEXT NOT NULL REFERENCES research_outputs(id) ON DELETE CASCADE,
      schema_version TEXT NOT NULL, engine_pipeline_version TEXT NOT NULL, source_fingerprint_sha256 TEXT NOT NULL,
      record_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(research_output_id,source_fingerprint_sha256)
    );
  `);
  for(const r of db.prepare(`SELECT id,title FROM research_outputs WHERE title_key=''`).all()) db.prepare('UPDATE research_outputs SET title_key=? WHERE id=?').run(normalizeTitleKey(r.title),r.id);
}

function findDuplicate(db,institutionId,c){
  if(c.doi){const r=db.prepare(`SELECT id FROM research_outputs WHERE institution_id=? AND lower(doi)=lower(?) LIMIT 1`).get(institutionId,c.doi);if(r)return {id:r.id,reason:'doi'};}
  const key=normalizeTitleKey(c.title); if(key){const r=db.prepare('SELECT id FROM research_outputs WHERE institution_id=? AND title_key=? LIMIT 1').get(institutionId,key);if(r)return {id:r.id,reason:'exact_title'};}
  return null;
}
function upsertSource(db,session,rid,c,sourceTypeOverride){
  const type=sourceTypeOverride||c.source_type; const ident=String(c.source_identifier||c.doi||sha256(c.source_text||c.title).slice(0,24));
  const id=newId('src'); const h=sha256(Buffer.from(c.source_text||JSON.stringify(c.raw_metadata||{})));
  db.prepare(`INSERT INTO ingestion_sources(id,institution_id,research_output_id,source_type,source_identifier,source_url,content_sha256,raw_metadata_json,source_text,evidence_depth,imported_by_user_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(institution_id,source_type,source_identifier) DO UPDATE SET research_output_id=excluded.research_output_id,source_url=excluded.source_url,content_sha256=excluded.content_sha256,raw_metadata_json=excluded.raw_metadata_json,source_text=excluded.source_text,evidence_depth=excluded.evidence_depth,imported_by_user_id=excluded.imported_by_user_id,imported_at=CURRENT_TIMESTAMP`)
    .run(id,session.active_institution_id,rid,type,ident,c.source_url||'',h,JSON.stringify(c.raw_metadata||{}),c.source_text||'',c.evidence_depth||'metadata',session.user_id);
}
function saveIntelligence(db,session,rid,intel){
  db.prepare(`INSERT OR IGNORE INTO research_intelligence_records(id,institution_id,research_output_id,schema_version,engine_pipeline_version,source_fingerprint_sha256,record_json) VALUES(?,?,?,?,?,?,?)`)
    .run(newId('ri'),session.active_institution_id,rid,intel.schema_version,intel.engine?.pipeline_version||'research-intelligence-v1',intel.provenance?.source_fingerprint_sha256||'',JSON.stringify(intel));
  const e=intel.extraction,o=intel.opportunity;
  const did=e.scientific_core?.methods_summary||e.scientific_core?.objective||'';
  const found=(e.findings||[]).map(x=>x.claim).join(' ');
  const why=[e.significance?.practical,e.significance?.societal].filter(Boolean).join(' ');
  const limits=(e.limitations||[]).join(' ');
  const audiences=(o.stakeholder_categories||[]).map(x=>x.audience).filter(Boolean);
  const actions=(o.recommended_actions||[]).slice(0,3).map(x=>x.action).join(' + ');
  const priority=o.communication_priority?.level||'B'; const sensitive=!!e.sensitive_research?.is_sensitive;
  db.prepare(`UPDATE research_outputs SET evidence_maturity=?,communication_priority=?,workflow_state=?,sensitive=?,did_text=?,found_text=?,why_text=?,limitations_text=?,audience_json=?,action_text=?,ingestion_status='analyzed' WHERE id=? AND institution_id=?`)
    .run(e.evidence_maturity?.level||'Other',priority,sensitive?'Enhanced Review':'Draft',sensitive?1:0,did,found,why,limits,JSON.stringify(audiences),actions,rid,session.active_institution_id);
  db.prepare('DELETE FROM opportunity_assessments WHERE research_output_id=?').run(rid);
  const ins=db.prepare('INSERT INTO opportunity_assessments(research_output_id,dimension,rating,confidence,rationale) VALUES(?,?,?,?,?)');
  for(const [dim,x] of Object.entries(o.opportunity_profile||{}))ins.run(rid,dim.replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase()),x.level,x.confidence,x.rationale);
}
export async function ingestCanonical(db,session,canonical,{owner_user_id,analyze=true,source_type_override}={}){
  ensureStep3Schema(db);
  const owner=resolveOwner(db,session,owner_user_id); const dept=ownerDepartment(db,session,owner);
  canonical.doi=normalizeDoi(canonical.doi||''); canonical.title=String(canonical.title||'Untitled research').trim();
  const duplicate=findDuplicate(db,session.active_institution_id,canonical);
  let rid=duplicate?.id||newId('r');
  if(!duplicate){
    db.prepare(`INSERT INTO research_outputs(id,institution_id,owner_user_id,department_id,title,title_key,authors,journal,doi,publication_date,publication_state,evidence_depth,evidence_maturity,communication_priority,workflow_state,sensitive,did_text,found_text,why_text,limitations_text,audience_json,action_text,visibility_text,ingestion_status,latest_source_type)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(rid,session.active_institution_id,owner,dept,canonical.title,normalizeTitleKey(canonical.title),canonical.authors||'Unknown authors',canonical.journal||'',canonical.doi||null,canonical.publication_date,canonical.publication_state||'Published',canonical.evidence_depth||'metadata','Not yet analyzed','B','Draft',0,'Analysis pending.','Analysis pending.','Analysis pending.','Analysis pending.','[]','Run Research Intelligence Engine.','Not yet assessed','ingested',source_type_override||canonical.source_type);
  }else{
    // Enrich a duplicate but never downgrade evidence depth or erase trusted metadata.
    const existing=db.prepare('SELECT * FROM research_outputs WHERE id=?').get(rid);
    const rank={metadata:0,Abstract:1,abstract:1,'Full text':2,full_text:2}; const incoming=rank[canonical.evidence_depth]??0, current=rank[existing.evidence_depth]??0;
    db.prepare(`UPDATE research_outputs SET authors=CASE WHEN authors IN ('Unknown authors','Authors to confirm') AND ?<>'' THEN ? ELSE authors END,journal=CASE WHEN coalesce(journal,'')='' AND ?<>'' THEN ? ELSE journal END,doi=coalesce(doi,?),publication_date=coalesce(publication_date,?),evidence_depth=?,latest_source_type=? WHERE id=?`)
      .run(canonical.authors||'',canonical.authors||'',canonical.journal||'',canonical.journal||'',canonical.doi||null,canonical.publication_date,incoming>current?canonical.evidence_depth:existing.evidence_depth,source_type_override||canonical.source_type,rid);
  }
  upsertSource(db,session,rid,canonical,source_type_override);
  let intelligence=null,analysis_reason='';
  const source=canonical.source_text||'';
  if(analyze&&source.trim().length>=80&&source.length<=200_000){
    intelligence=await analyzeResearch({title:canonical.title,authors:canonical.authors,venue:canonical.journal,evidence_depth:canonical.evidence_depth,source_text:source}); saveIntelligence(db,session,rid,intelligence);
  }else if(source.length>200_000){analysis_reason='Source ingested, but automatic Step-1 analysis was not run because extracted text exceeds the frozen 200,000-character Step-1 limit.';db.prepare("UPDATE research_outputs SET ingestion_status='needs_chunking' WHERE id=?").run(rid)}
  else{analysis_reason='Source ingested, but there is insufficient research text for Step-1 analysis.';db.prepare("UPDATE research_outputs SET ingestion_status='needs_source_text' WHERE id=?").run(rid)}
  return {research_output_id:rid,created:!duplicate,deduplicated:!!duplicate,deduplication_reason:duplicate?.reason||null,analyzed:!!intelligence,analysis_reason,intelligence};
}

export async function ingestDoi(db,session,doi,opts={}){
  const m=await fetchCrossrefWork(doi,opts); const c=crossrefToCanonical(m); return {...await ingestCanonical(db,session,c,opts),canonical:c};
}
export async function ingestOrcid(db,session,orcid,opts={}){
  const id=normalizeOrcid(orcid);if(!isValidOrcid(id))throw new Error('Please enter a valid ORCID iD.'); const limit=Math.max(1,Math.min(MAX_ORCID_WORKS,Number(opts.limit)||25));
  let works=[],provider='Crossref ORCID filter';
  const doiList=await fetchOrcidDoiList(id,{...opts,limit}).catch(()=>null);
  if(doiList){provider='ORCID Public API + Crossref';for(const doi of doiList){try{works.push(await fetchCrossrefWork(doi,opts))}catch{}}}
  else works=await fetchCrossrefWorksByOrcid(id,{...opts,limit});
  const results=[];for(const m of works.slice(0,limit)){const c=crossrefToCanonical(m);c.source_type='orcid';c.source_identifier=`${id}:${c.doi||normalizeTitleKey(c.title)}`;results.push({...await ingestCanonical(db,session,c,{...opts,source_type_override:'orcid'}),title:c.title,doi:c.doi});}
  return {orcid:id,provider,requested_limit:limit,works_found:works.length,results};
}
export async function ingestPdf(db,session,{filename='paper.pdf',content_base64='',owner_user_id,analyze=true}={}){
  let b;try{b=Buffer.from(content_base64,'base64')}catch{throw new Error('PDF payload is not valid base64.')}if(!b.length)throw new Error('No PDF content received.');
  const text=await extractPdfText(b);const c=pdfToCanonical(text,filename);
  const result=await ingestCanonical(db,session,c,{owner_user_id,analyze,source_type_override:'pdf'});
  return {...result,canonical:{title:c.title,doi:c.doi,evidence_depth:c.evidence_depth,extracted_characters:text.length,content_sha256:sha256(b)}};
}
